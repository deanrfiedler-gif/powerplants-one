---
document_id: PPO-SVC-WO-HTML-CR
title: Work Orders workspace r01 change record
revision: r01
date: 2026-09-15
owner: Dean Fiedler
status: First issue; no predecessor
---

# Work Orders workspace r01 — change record

Sibling record required by the shared UI style specification §7.1, element 6.

| Item | Value |
|---|---|
| Deliverable | `PPO-Work-Orders-Workspace-r01.html` |
| SHA-256 | `cd36f26448a299d622b51d64c03beced91b8b5f68f098a17213fb35517506336` |
| Bytes | 286,397 |
| Predecessor | None — first issue of this module |
| Scope container | `#ppo-work-orders`; 47 r20 tokens declared on the container; local reset of `a`, `button`, `fieldset`, `h1`, `h2`, `h3`, `label`, `main`, `p`, `select` beneath it |
| Declared viewports | 1440×960, 1024×768, 820×800, 390×844 — rendered in Chromium 141.0.7390.37 with no horizontal overflow and no console or page errors |
| Fixtures | `SYN-PPO-WO-000501` to `000504`; requests `SYN-PPO-TKT-000201/203/205/207/208`; visits `SYN-PPO-APT-000603/604/621`; policy `SYN-PPO-POL-READINESS-r01`; Willowbank context copied byte-exact from Customers r03 at `b6066d1` |
| Rendered states | Loading, empty, read failed, partial read, denied, saving, saved, conflict — reachable through the Preview state control |

## What this revision establishes

Keyed to the SV-03 brief and the three suggested review checks in the coverage register r04.

| Register expectation | Where it is met |
|---|---|
| Authorised tasks, equipment, exclusions, limits, coverage, prerequisites, multiple visits and remaining work with controlled revisions | Scope, Coverage & authority, Readiness & authorisation and Visits views; successor rule; execution outcome on `000503` |
| Select the site and affected facilities/growing areas/blocks | Proposed extension on each scope item, labelled; same-site validation |
| Work without a known asset and work spanning several areas | Identification task against an unresolved asset with method and limits (`000501`); multiple areas per item; an item with no asset blocks authorisation (`000504`) |
| Preserve scope on each revision | Approved revisions immutable; revision selector renders every revision; snapshot hash re-verifiable |
| Check 1 — a visit outcome cannot hide unresolved work or imply customer/financial acceptance | `000503`: completed visit, unresolved work panel, closure blocked, coverage Disputed |
| Check 2 — scope, authority, readiness and next action remain visible through return/rework | Successor banner, review-required visit flags, readiness reading Unknown against the successor with revision 1 history retained |
| Check 3 — normal, missing-source and interrupted/returned cases | `000502` normal; `000504` missing source (untriaged request, expired site-controls evidence, no asset); `000503` interrupted/returned |

## Token choices

The three known divergences in the shared token core take the Field Technicians r05 / r20 values, as Cases r02 does: `--surface-hover:#f0f2f5`, `--line-soft:#e9ecf1`, `--success-tint:#f3f7f1`. Job Pack r03 uses `#eff2f5`, `#eef0f3`, `#ebefe9`. No new token name is introduced.

## Deliberately unchanged or absent

- No financial limit, amount or currency field. `ApprovedNonBillable` is absent.
- No appointment confirmation, movement, cancellation or crew reservation.
- No pack, report or Finance command.
- No status change beyond Draft → Authorised; dictionary states are displayed, never assigned.
- No `:root` token block; no application rail, masthead, logo or login.
- The `#location-context`, `#workspace-icons` and `#choice-code` blocks are reused from Cases r02 unchanged.

## Verified

62 model/DOM checks ([evidence](../../../testing/evidence/work-orders-workspace-r01.json), hash-bound); Chromium rendering at four viewports across six views plus the scope editor, authorise dialog, assessment menu and assistant ([rendering evidence](../../../testing/evidence/work-orders-workspace-r01-rendering.json)); foundation, prototype and naming documentation checks; conflict-marker scan; whitespace check.

## Decisions the owner still has to make

1. Confirm or reverse each of the seven r01 decisions recorded in the [design record](../../../decisions/work-orders-workspace-design.md).
2. Whether the proposed affected-area field becomes an API contract, and under which parent.
3. Whether the closure assessment panel remains in the accepted baseline or is deferred to SV-06.
4. Native device review outcome and any r02 polish list.
5. Whether to register the accepted revision in `ui-baselines.json` with a governing route of `/service/work-orders/:id`.
