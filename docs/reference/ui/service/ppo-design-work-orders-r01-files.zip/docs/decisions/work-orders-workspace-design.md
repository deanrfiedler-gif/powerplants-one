---
document_id: PPO-SVC-WO-DES
title: Work Orders workspace design and receiving handover
revision: r01
date: 2026-09-15
owner: Dean Fiedler
status: Requested standalone design delivered for review; native device acceptance and application integration pending
source_commit: 3f347fa5ffabb4bda4c684c7f2edb1c5fe5f5d65
---

# Work Orders workspace r01

**Owner:** Dean Fiedler · **Date:** 15 September 2026 · **Register entry:** SV-03 Work-order register and scope workspace, P1, dedicated refinement · **State:** Requested standalone design delivered for review; native device acceptance and application integration pending.

The [interactive HTML r01](../reference/ui/work-orders/PPO-Work-Orders-Workspace-r01.html) is the authority record of the service chain: authorised tasks, exclusions, diagnostic limit, coverage, authority evidence, readiness by stage, proposed visits and controlled revisions, with every downstream artefact — appointment, job pack, field capture, report and Finance handoff — reading the scope it inherits from here. It uses the r20 theme with only the module's own header, selected-record context and six local views. There is no left navigation rail, corporate masthead, login or global shell.

Dean instructed the build against the r01 build plan recorded in the Claude project on 15 September 2026 (`claude/work-orders-r01-build-plan.md`, outside this repository), with the module-only composition restated. The plan's seven §12 recommendations were taken as adopted for this revision and are listed under *Decisions taken for r01* so that any can be reversed in r02.

## Authority and what governs each element

Every field, state, command and rule in the HTML is one of three things. The HTML labels the second and third kinds where they appear.

| Kind | Meaning | Source |
|---|---|---|
| Contract | In the P04 decision, the P04 API amendment, the data dictionary or BP-07, and implemented in the running application | [ADR-0009](ADR-0009-p04-work-scope-readiness.md); [service API P04 amendment](../contracts/service-api.md#p04-implementation-amendment--current-bounded-contract); [data dictionary](../contracts/service-data-dictionary.md) `WorkOrderState`, `ReadinessState`, `CoverageState`; [BP-07](../blueprints/BP-07-service-operations.md) §3 SC-05, §5, §7, TR-02, TR-15; [`work-order-screens.tsx`](../../src/components/work-order-screens.tsx) |
| Dictionary | A canonical value with no runtime command yet | `InProgress`, `WorkComplete`, `Closed`, `Cancelled` |
| Proposed | A design extension needing Dean's decision | Affected facilities and growing areas per scope item; closure assessment panel; register attention queues |

Contract-exact in the HTML: the two revision pointers (`scope_revision_id`, `authorised_scope_revision_id`); 1–20 same-site linked requests fixed at creation; scope narratives at 4000/4000/4000/2000 characters; 0–20 items each with task kind, description, expected outcome, 1–20 completion requirements (1000 each), 0–20 skill codes (100 each), shutdown and access conditions (2000), 0–20 assets with optional configuration and identification plan (4000 each); content version increment on every draft save with readiness invalidation; the successor rule leaving the original Authorised for its exact prior scope; five coverage positions with two charging routes and the Unknown/Disputed non-intervention limit; ApprovedNonBillable absent; immutable typed text evidence with SHA-256; the published policy's eight criteria, their stages, N/A and exception rules and the two P04-locked criteria; five readiness outcomes; expiry and scope-staleness reading Unknown; the immutable approval snapshot hashed from its canonical JSON text; Proposed visits with dispatch hold and Unknown/Proposed commitment; receipts that replay identical retries and refuse changed payloads; `expected_version` on every write; the four capabilities and their preview roles.

## Decisions taken for r01

| # | Decision | Treatment in r01 | Reverse in r02 by |
|---|---|---|---|
| 1 | Scope container | Every stylesheet rule is scoped beneath `#ppo-work-orders`; the 47 r20 tokens are declared on that container, not `:root`; the `globals.css` elements are re-declared bare beneath it (style specification §7.1). The first r20 standalone module to do so; #195 and #197 declare tokens on `:root`. | Moving the token block to `:root` — not recommended |
| 2 | Post-authorisation states | The lifecycle strip shows In progress, Work complete and Closed as dashed dictionary states. A **Closure assessment** panel lists the TR-15 inputs and names the module that supplies each. Recording the assessment writes the blocker list to history and increments the version; status never changes. No report, attendance or Finance outcome is simulated. | Removing the panel |
| 3 | Affected facilities and growing areas | Each scope item may name site areas from the Customers r03 hierarchy, labelled *Proposed extension — no API field exists*. Same-site validation applies. | Removing the fieldset |
| 4 | Financial limit | Not a field. The workspace shows *Financial limit: not configured — no financial authority in this increment*. The diagnostic limit narrative is the only limit concept. | Adding a field once D-017 defines financial authority |
| 5 | Register presentation | List with six attention queues over one collection. No Board: Draft/Authorised is a two-state space with a review overlay, and a Board would invite drag-to-authorise, which TR-02 forbids. | Adding a Board |
| 6 | Fixtures | Willowbank organisation, two sites, nine areas and the single pump copied byte-exact from the Customers r03 context at `b6066d1`. The Cases r02 users and request identities are reused so the chain from case to order is real: `SYN-PPO-WO-000503` and visit `SYN-PPO-APT-000603` carry the identities Cases r02 already shows. One design-data asset, the Pack Room 01 roller door drive, is added and labelled. | Replacing fixtures |
| 7 | Start condition | Branched from `main` at `3f347fa5` without waiting for the native review of Cases r02; nothing here reads that file. | — |

## Six connected views

1. **Register.** Six queue tiles — drafts without scope items, ready to authorise, authorisation blocked, authorised with no visit, successor in review, readiness stale or expired — plus search, site/owner/status/coverage/readiness filters and attention-first ordering. A filter that hides the selected order clears the selection. Narrow widths present labelled cards behind a collapsed filter toggle.
2. **Workspace.** Reference, derived status, version, fixed company/site/customer, service owner, Google Maps address link, the two revision pointers, linked requests with their triage state and authorisation-blocking flag, the authorisation gate or the authorised summary, the retained execution outcome, affected equipment, same-equipment history, site sources and the handoffs owned by other modules.
3. **Scope.** Revision selector across every revision; read-only rendering of an approved revision; the current draft editable with live contract counts; item cards with kind, outcome, completion requirements, skills, conditions, assets with identity basis and identification plan, and the proposed area extension; successor banner naming the change reason.
4. **Coverage and authority.** Position, route, agreement, dates, assessment, reason and rule conflicts; authority evidence list with hash, source and citation count; add-evidence prefilled from a retained site source.
5. **Readiness and authorisation.** Eight-criterion matrix by stage with effective outcome, staleness or expiry note, recorded reason, cited evidence, source as-at, expiry and reviewer; the authorisation gate; the authorise dialog binding exact revision id, content version and policy version, listing every blocker and requiring the revision number to be typed; on success the frozen snapshot with SHA-256, approver, time and policy, re-hashable on inspection.
6. **Visits, history and closure.** Visits bound to a revision with review-required flags when a successor exists; propose-visit form; closure assessment; revision history with hashes; activity timeline; receipt count.

The demonstration starts on `SYN-PPO-WO-000501`, a Draft raised from the urgent Willowbank pump case with an Identification item, unknown coverage on the Finance review route and three authorisation criteria unassessed. `000502` is authorised with all five criteria passed, a contract-referenced coverage and a proposed visit inside the agreed isolation window. `000503` is authorised with a completed diagnostic visit, unresolved work and a Disputed-coverage successor that cannot be authorised while its item is an Intervention. `000504` is a field-site Draft whose request is not yet triaged, whose only item has no asset and whose site-controls evidence expired on 10 September 2026.

## Local behaviour and boundaries

Service coordinator, Service reviewer, Technician and Observer are local preview roles mirroring `service.work_order.read/edit`, `service.scope.authorise` and `service.readiness.assess`. The technician preview sees only orders with a visit naming that technician and cannot export the workspace. These controls demonstrate the intended workflow; they are not authentication or server security. Real permissions and record scope must be enforced by the domain services during implementation.

Draft and Authorised are the runtime states. In progress, Work complete and Closed are dictionary states shown for the lifecycle only; the closure assessment records blockers and changes nothing. Confirmation, movement, cancellation and crew reservation belong to the planner; pack preparation, checking and issue to Job Pack r03; attendance and capture to Field Technicians r05; entry review and reports to SV-06; handoff and reconciliation to Finance. The HTML names those handoffs and simulates none of them.

Coverage never decides customer charging or supplier liability; all work remains pending Finance review. The approval hash proves byte identity of a synthetic snapshot, not business authenticity. MYOB remains the ERP authority and SharePoint the document authority; the module reads and writes neither.

Contextual assistance is scripted from the selected order and its retained sources: summary, authorisation blockers, missing prerequisites, successor change summary and a pack-preparation brief with inspectable sources. A record change after scripting blocks copying. It performs no inference, diagnosis, delivery or external handover.

This is a single embedded file with no network-loaded fonts or assets. Google Maps opens only an explicitly selected fictional address through a standard search link. The local key is `ppo-work-orders-r01`. Validated JSON backup and restore, explicit reset, stale-write refusal, competing-tab refusal and session-only storage messaging are included. The queue clock is visibly fixed at 15 September 2026, 10:00 AEST; entered times use Australia/Melbourne and history retains recorded instants.

## Verification

**Model and DOM.** [`scripts/check-work-orders-design.mjs`](../../scripts/check-work-orders-design.mjs) records **62 checks** in the hash-bound [evidence file](../testing/evidence/work-orders-workspace-r01.json): starter validation; module-only composition; tokens on the scope container matching the metadata; every rule scoped; embedded Roboto rule text at `a3c83afa45da8ccb05686729f4cfdd2f4694e6771334b025f00207ef381185e9`; location context byte-identical to the declared copy; eight preview states; lifecycle strip; queues, search, compound filters and ordering; narrow-width cards; fixed context and map link; same-equipment history; disabled-action reasons; scope editing with limit, cross-site, unresolved-asset and ReviewRequired refusals; content-version increment and readiness staleness; coverage rules; evidence immutability and hash; reviewer assessment rules including locked criteria, exceptions, Not applicable, expiry and `exception_allowed` rejection; the complete authorisation journey with snapshot re-hashing; immutability after authorisation; visit proposal rules; Booking-stage binding to a real visit; successor creation and review-required flags; closure assessment; receipt replay and changed-payload refusal; stale-version refusal preserving the form; technician and observer boundaries; assistant scoping and stale-copy refusal; new-order creation; reload, competing-tab, backup validation, confirmed restore, reset and storage-failure paths; keyboard tab traversal; Escape cancellation; unique ids; print and reduced-motion rules; choice-menu enhancement; and zero script errors. The check runs with a scratch jsdom 27.0.1 through `PPO_DESIGN_JSDOM_MODULE`; no application dependency is added.

**Chromium rendering.** Unlike #195 and #197, this contribution was rendered natively: Chromium 141.0.7390.37 through Playwright 1.56.0 at 1440×960, 1024×768, 820×800 and 390×844 across all six views, plus the scope editor, authorise dialog, assessment menu and assistant. Zero console errors, zero page errors and no horizontal overflow at any viewport. The [rendering evidence](../testing/evidence/work-orders-workspace-r01-rendering.json) records each viewport and view. Screenshots were reviewed in session and are not committed.

**Documentation.** Foundation, prototype and naming checks passed on this branch; the conflict-marker scan over `docs` is clean; `git diff --check` is clean. Results are recorded in the pull request.

**Not verified here.** Physical devices, zoom, native dialog top-layer behaviour under assistive technology, clipboard and download behaviour, print output, and any application build, backend, security or operational acceptance. Design acceptance is acceptance of presentation; it creates no data contract.

## Sources and provenance

| Source | Identity |
|---|---|
| Repository main | `3f347fa5ffabb4bda4c684c7f2edb1c5fe5f5d65` |
| r20 theme board | SHA-256 `c68a499e857b1705d47bd6598d4b2e89526bf0861a0d234394c3da023f19b617` as declared by Cases r02 |
| Embedded Roboto (three faces, rule text) | SHA-256 `a3c83afa45da8ccb05686729f4cfdd2f4694e6771334b025f00207ef381185e9` |
| Location context | Customers r03 at `b6066d18602b7b544a1883b8beb3a12ed0ecf09c`, copied byte-exact from Cases r02 head `0743566073ed9264e057065aa78841fa5bce3ad5` |
| Choice-menu and icon code | Reused from Cases r02 head `0743566073ed9264e057065aa78841fa5bce3ad5` unchanged |
| Deliverable | `PPO-Work-Orders-Workspace-r01.html`, 286,397 bytes, SHA-256 `cd36f26448a299d622b51d64c03beced91b8b5f68f098a17213fb35517506336` |

SVC-02 provides the primary traceability (D-005/D-007, DAT-05, TR-02, IF-04, AT-06/AT-14/AT-30); SVC-01, SVC-03, SVC-05, SVC-10, SVC-11 and SVC-12 cover the family. The 78 parent requirements and acceptance procedure statuses are intact. This is a design contribution with no application routes, migration, dependency, operational communication or deployment.

## Next step

Native device review by Dean, then the §12 decisions confirmed or reversed for r02. The next module HTML in the chain is **SV-06 Service review and controlled report**, which reviews captured quantities against the authorised scope this module now defines.
