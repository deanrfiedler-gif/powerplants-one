---
document_id: PPO-SVC-SCH-HTML-CR
title: Scheduling & Appointments workspace r01 change record
revision: r01
date: 2026-09-15
owner: Dean Fiedler
status: First issue; no predecessor
---

# Scheduling & Appointments workspace r01 — change record

Sibling record required by the shared UI style specification §7.1, element 6.

| Item | Value |
|---|---|
| Deliverable | `PPO-Scheduling-and-Appointments-Workspace-r01.html` |
| SHA-256 | `def8ebed4adc4f41b41bbfe954f8286e1162a23bf0f734fc3007c9aef78cf6d5` |
| Bytes | 284,316 |
| Predecessor | None — first issue of this module |
| Scope container | `#ppo-scheduling`; 47 r20 tokens declared on the container; local reset of `a`, `button`, `fieldset`, `h1`, `h2`, `h3`, `label`, `main`, `p`, `select` beneath it |
| Declared viewports | 1440×960, 1024×768, 820×800, 390×844 — rendered in Chromium 141.0.7390.37 with no horizontal page overflow and no console or page errors; the planner lanes and week grid scroll within their own bounded region only |
| Fixtures | Appointments `SYN-PPO-APT-000621/604/603/630/631`; orders `SYN-PPO-WO-000502/000503` and design-data `000506`; resources `SYN-PPO-RES-000701` to `000707`; calendars Brisbane and Melbourne; scheduling policy `a0000000-…-0001`; readiness policy `SYN-PPO-POL-READINESS-r01`; Willowbank context copied byte-exact from Customers r03 at `b6066d1` |
| Rendered states | Loading, empty, read failed, partial read, denied, saving, saved, conflict — reachable through the Preview state control |

## What this revision establishes

Keyed to the SV-04, PL-01, PL-04 and PL-02 brief and the suggested review checks in the coverage register r04.

| Register expectation | Where it is met |
|---|---|
| Appointment coordination detail: interval, timezone, requested window, commitment, preparation, dispatch hold, bound scope, crew, readiness, follow-ups, requests, contacts and history (SV-04) | Appointment view in full; the confirmed `000630` carries crew across two calendars, two Pending requests, a Confirmed contact and a PreparationRequired follow-up |
| Service planner and unassigned demand: day/week lanes, busy bands, drag-to-propose, demand from Work Orders (PL-01) | Service planner view; day and week modes; anonymous busy bands with travel; drag and keyboard Move; unassigned demand lane as exactly the Proposed appointments |
| Rescheduling and acknowledgement centre across appointments (PL-04) | Contacts & follow-up view; owned consequences, contact history and the rescheduling and cancellations list; the disconnected-technician rule shown |
| Resource availability and competence, read-only (PL-02) | Resources view: published bundles with calendar, exceptions, blocks and skills with validity; no editor |
| Check 1 — a failed read never implies free capacity | Read-failed and partial preview states show *availability unknown*; the partial outlook page reads unknown, not empty |
| Check 2 — advisory customer work windows do not silently move a booking | Advisory site windows panel, labelled *Proposed*; no booking change follows |
| Check 3 — a change cannot inherit a prior acknowledgement | A move sets commitment Changed, requires a fresh Confirmed contact and owns a contact task; pack acknowledgement is shown as not available here |
| Atomic booking: the whole crew reserves or nothing does | Confirm and move reserve all crew, the interval, the versions and the snapshot together; the check asserts no partial reservation on any refusal |

## Token choices

The three known divergences in the shared token core take the Field Technicians r05 / r20 values, as Work Orders r01 and Cases r02 do: `--surface-hover:#f0f2f5`, `--line-soft:#e9ecf1`, `--success-tint:#f3f7f1`. No new token name is introduced. One structural rule is added to the shared stylesheet: `.table-wrap` is made a positioned containing block so the visually-hidden actions-column label in a wide table is clipped with the table rather than extending the page.

## Deliberately unchanged or absent

- No resource, roster, skill, leave, calendar or scheduling-policy editor — no endpoint exists (ADR-0010).
- No pack acknowledgement, sent message, email, SMS or calendar invitation. Contact outcomes are recorded events only.
- No clearing of the dispatch hold, which remains held throughout.
- No attendance, field labour, parts, findings, photos, report review or Finance handoff.
- No status beyond Proposed, Confirmed and Cancelled; the three attendance states are displayed, never assigned.
- No `:root` token block; no application rail, masthead, logo or login.
- The `#location-context`, `#workspace-icons` and `#choice-code` blocks are reused from the Work Orders r01 build unchanged.

## Verified

60 model/DOM checks ([evidence](../../../testing/evidence/scheduling-workspace-r01.json), hash-bound); Chromium rendering at four viewports across six views ([rendering evidence](../../../testing/evidence/scheduling-workspace-r01-rendering.json)); foundation, prototype and naming documentation checks; conflict-marker scan; whitespace check.

## Decisions the owner still has to make

1. Confirm or reverse each of the ten r01 decisions recorded in the [design record](../../../decisions/scheduling-workspace-design.md).
2. Whether the unassigned demand lane, multi-week outlook, advisory work windows and rescheduling centre become API-backed contracts, and under which parents.
3. The WO-000502 first-visit time alignment (07:00 in Work Orders r01 versus 08:30 here) recorded as the open question in the design record.
4. Native device review outcome and any r02 polish list, including the drag-and-drop pointer paths not exercised under DOM emulation.
5. Whether to register the accepted revision in `ui-baselines.json` with a governing route of `/service/schedule`.
