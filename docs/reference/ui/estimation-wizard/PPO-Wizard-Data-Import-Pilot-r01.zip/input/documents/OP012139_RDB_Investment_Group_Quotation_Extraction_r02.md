---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP012139
registry_project_id: PRJ-OP012139
registry_price_revision_id: REV-OP012139-PRICE
registry_data_file: ../data/projects/OP012139/project.json
field_bindings_file: ../data/projects/OP012139/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# RDB Investment Group — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP012139 |
| Customer | RDB Investment Group |
| Site | 140 Browns Road, Halfway Creek, NSW 2460 |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Main schedule and wireless schedule priced separately; combined selection unresolved |
| Base / main schedule ex GST | 86,511.10 |
| Optional schedule ex GST | 12,840.00 |
| Separate schedule ex GST | 20,550.00 |
| Costed reference total ex GST | Not combined / unresolved |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP012139-PRICE-004 | Priva NutriOne 600 Systems | Base | 43,430.00 | DOC-OP012139-XLSM · 'Pricing'!A4:H4 |
| PKG-OP012139-PRICE-005 | Priva Compact CC | Base | 32,371.10 | DOC-OP012139-XLSM · 'Pricing'!A5:H5 |
| PKG-OP012139-PRICE-006 | Linear Light Sensor | Base | 930.00 | DOC-OP012139-XLSM · 'Pricing'!A6:H6 |
| PKG-OP012139-PRICE-007 | Commissioning | Base | 9,780.00 | DOC-OP012139-XLSM · 'Pricing'!A7:H7 |
| PKG-OP012139-PRICE-014 | Wireless Irrigation System | Base | 17,860.00 | DOC-OP012139-XLSM · 'Pricing'!A14:H14 |
| PKG-OP012139-PRICE-015 | Commissioning | Base | 2,690.00 | DOC-OP012139-XLSM · 'Pricing'!A15:H15 |
| PKG-OP012139-PRICE-022 | Weather Station - WSC11 | Option | 9,000.00 | DOC-OP012139-XLSM · 'Pricing'!A22:H22 |
| PKG-OP012139-PRICE-023 | PC | Option | 2,250.00 | DOC-OP012139-XLSM · 'Pricing'!A23:H23 |
| PKG-OP012139-PRICE-024 | Alarm Dialler | Option | 1,130.00 | DOC-OP012139-XLSM · 'Pricing'!A24:H24 |
| PKG-OP012139-PRICE-025 | UPS | Option | 460.00 | DOC-OP012139-XLSM · 'Pricing'!A25:H25 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012139-0001 | Priva NutriOne 600 Systems: Qty 2.0, extended price $43,430.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 3; PDF p.14 |
| REQ-OP012139-0002 | Priva Compact CC: Qty 1.0, extended price $32,371.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 4; PDF p.14 |
| REQ-OP012139-0003 | Linear Light Sensor: Qty 1.0, extended price $930.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 5; PDF p.14 |
| REQ-OP012139-0004 | Commissioning: Qty 1.0, extended price $9,780.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 6; PDF p.14 |
| REQ-OP012139-0005 | Wireless Irrigation System: Qty 2.0, extended price $17,860.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 13; PDF p.14 |
| REQ-OP012139-0006 | Commissioning: Qty 1.0, extended price $2,690.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 14; PDF p.14 |
| REQ-OP012139-0011 | Wall mounted cabinet 800x800 standard with Gateway \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 2; PDF p.7 |
| REQ-OP012139-0012 | Basic materials for Process Controller (CPC2.1) \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 3; PDF p.7 |
| REQ-OP012139-0013 | I/O module AI16/DO32 (AC) \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 4; PDF p.7 |
| REQ-OP012139-0014 | I/O module DO64 (AC) \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 5; PDF p.7 |
| REQ-OP012139-0015 | Priva Office Direct for Priva for Compact CC \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 7; PDF p.7 |
| REQ-OP012139-0016 | Compact CC Water system \| 2 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 8; PDF p.7 |
| REQ-OP012139-0017 | Compact CC Dosing channel \| 10 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 9; PDF p.7 |
| REQ-OP012139-0018 | Compact CC Starting program \| 6 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 10; PDF p.7 |
| REQ-OP012139-0019 | Compact CC Valve group \| 6 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 11; PDF p.7 |
| REQ-OP012139-0020 | Compact CC Irrigation valve control \| 25 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 1, row 12; PDF p.7 |
| REQ-OP012139-0021 | Linear Light Sensor \| Linear light sensor 5VDC at 160klux with photo rectifier, black aluminium housing and glass dome, suited for: Measuring range: 0-160klux at wavelength 525- 1,100nm Maximum output signal: 5VDC at 160klux Suited for connecting with: Universal input of MX34 input/output module in Compass Analog input of Compri HX base module in NutriFit HX unit \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 2, row 2; PDF p.7 |
| REQ-OP012139-0026 | Unit \| NutriOne 600 \| NutriOne 600 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 2; PDF p.10 |
| REQ-OP012139-0027 | Unit \| NutriOne 600 \| NutriOne 600 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 2; PDF p.10 |
| REQ-OP012139-0028 | Controller \| Priva – Compact CC \| Priva – Compact CC | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 3; PDF p.10 |
| REQ-OP012139-0029 | Controller \| Priva – Compact CC \| Priva – Compact CC | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 3; PDF p.10 |
| REQ-OP012139-0030 | Required flow through dosing system \| 7.06 m3/hr \| 7.06 m3/hr | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 4; PDF p.10 |
| REQ-OP012139-0031 | Required flow through dosing system \| 7.06 m3/hr \| 7.06 m3/hr | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 4; PDF p.10 |
| REQ-OP012139-0032 | Mainline flow rate \| 85 m3/hr \| 85 m3/hr | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 5; PDF p.10 |
| REQ-OP012139-0033 | Mainline flow rate \| 85 m3/hr \| 85 m3/hr | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 5; PDF p.10 |
| REQ-OP012139-0034 | Dosing ratio \| 1:100 \| 1:100 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 6; PDF p.10 |
| REQ-OP012139-0035 | Dosing ratio \| 1:100 \| 1:100 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 6; PDF p.10 |
| REQ-OP012139-0036 | Mainline target pressure \| 5 bar \| 5 bar | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 7; PDF p.10 |
| REQ-OP012139-0037 | Mainline target pressure \| 5 bar \| 5 bar | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 7; PDF p.10 |
| REQ-OP012139-0038 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0039 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0040 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0041 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0042 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0043 | EC Dosing channel flow rate \| 4x 600 LPH \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 8; PDF p.10 |
| REQ-OP012139-0044 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0045 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0046 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0047 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0048 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0049 | pH Dosing channel flow rate \| 1x 100 LPH \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012139-0052 | EC/PH Sensor interfaces \| EC, pH & Dosing channel driver \| EC, pH & Dosing channel driver | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 11; PDF p.10 |
| REQ-OP012139-0053 | EC/PH Sensor interfaces \| EC, pH & Dosing channel driver \| EC, pH & Dosing channel driver | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 11; PDF p.10 |
| REQ-OP012139-0062 | Budget Parallel Transmitter \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 2; PDF p.12 |
| REQ-OP012139-0063 | Post Mounting Bracket \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 3; PDF p.12 |
| REQ-OP012139-0064 | Omni Directional Aerial G8ROMNI \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 4; PDF p.12 |
| REQ-OP012139-0065 | Outdoor Data Cable 10m. \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 5; PDF p.12 |
| REQ-OP012139-0066 | 16 Station AC Master Module \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 6; PDF p.12 |
| REQ-OP012139-0067 | 16 Station AC Expansion Module \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 7; PDF p.12 |
| REQ-OP012139-0068 | 2 Station Receiver - 1 x 3 Way DC Coil \| 1 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 8; PDF p.12 |
| REQ-OP012139-0069 | 4 Station Receiver - 4 x 3 Way DC Coils \| 6 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 5, row 9; PDF p.12 |
| REQ-OP012139-0101 | Dosing system count: 2 | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.10, project-specific section |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012139-0072 | Installation is not included in this quotation (positioning unit, plumbing & powering). | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 1 |
| REQ-OP012139-0073 | Irrigation valves, tanks, drippers pipework and other irrigation equipment. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 2 |
| REQ-OP012139-0074 | Stock tank and stirrers are not included in this quote. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 3 |
| REQ-OP012139-0075 | Plumbing works | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 4 |
| REQ-OP012139-0076 | Electrical works | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 5 |
| REQ-OP012139-0077 | The following irrigation equipment: | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 6 |
| REQ-OP012139-0078 | Water meter | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 8 |
| REQ-OP012139-0079 | Irrigation valve cable | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 10 |
| REQ-OP012139-0080 | Internet connection | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 11 |
| REQ-OP012139-0081 | Activated sim card for alarm dialler. Please note that this quote is a budget estimate only, based on the specifications and details provided in this specific quote. Upon receipt of complete and supplementary information, Powerplants can issue a detailed final quotation. Powerplants reserves the right to make any necessary technical changes, with corresponding adjustments to the pricing, upon receipt and review of the complete project details. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 12 |
| REQ-OP012139-0082 | Unpack the units and place in position within the irrigation shed. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 13 |
| REQ-OP012139-0083 | Install all wireless irrigation control components inside the irrigation shed, near the Compact CC controller, and outside the irrigation shed, at the location of valves. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 14 |
| REQ-OP012139-0084 | Run cables between the wireless irrigation components (including the receivers and the valves). | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 15 |
| REQ-OP012139-0085 | Installation and connection of stock tanks to dosing channels. This should be carried out using the supplied tank installation kits. If these are not used, an isolation valve and check valve must be installed at the stock solution tank to prevent back-flow. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 16 |
| REQ-OP012139-0086 | Run and terminate required electrical power into control cabinets. This should be carried out by a licensed electrician and comply to AS3000. Circuit breakers and electrical isolator should be installed for the system. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 17 |
| REQ-OP012139-0102 | Wireless site survey: A site survey would be ideally completed after the order to ensure that there is no outside interference. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.12, project-specific section |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012139-0050 | EC & pH sensors \| Included \| Included | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 10; PDF p.10 |
| REQ-OP012139-0051 | EC & pH sensors \| Included \| Included | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 10; PDF p.10 |
| REQ-OP012139-0054 | Fertilizer and Acid Tank connection kits \| Included \| Included | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 12; PDF p.10 |
| REQ-OP012139-0055 | Fertilizer and Acid Tank connection kits \| Included \| Included | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 12; PDF p.10 |
| REQ-OP012139-0056 | Irrigation Pump \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 13; PDF p.10 |
| REQ-OP012139-0057 | Irrigation Pump \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 13; PDF p.10 |
| REQ-OP012139-0058 | Irrigation Filter \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 14; PDF p.10 |
| REQ-OP012139-0059 | Irrigation Filter \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 14; PDF p.10 |
| REQ-OP012139-0060 | Irrigation Flow meter \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 15; PDF p.10 |
| REQ-OP012139-0061 | Irrigation Flow meter \| Excluded \| Excluded | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 4, row 15; PDF p.10 |
| REQ-OP012139-0087 | Load software onto the controller | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 18 |
| REQ-OP012139-0088 | Program, test and configure Compact CC & Fertigation units. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 19 |
| REQ-OP012139-0089 | Set dosing channels to operate at the correct flow rate. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 20 |
| REQ-OP012139-0090 | Running and testing of all units | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 21 |
| REQ-OP012139-0091 | Irrigation settings on consultation with customer | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 22 |
| REQ-OP012139-0092 | Training of operator Please note that the commissioning of the wireless irrigation system is included and will be carried out at the same time as the commissioning of the other items during a single site visit. | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.13, responsibilities / commissioning bullet 23 |
| REQ-OP012139-0094 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, installation |
| REQ-OP012139-0095 | Commissioning scope: Commissioning included | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, commissioning |
| REQ-OP012139-0097 | Freight scope: International sea freight & local freight are included. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, project-specific section |
| REQ-OP012139-0098 | Import duty: Import duty and costs are included in the price. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, project-specific section |
| REQ-OP012139-0100 | Wireless commissioning: Commissioning of the wireless irrigation system at the same time as other items during a single site visit. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012139-0093 | Quotation exchange rate: 0.61 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.14, validity and exchange rate |
| REQ-OP012139-0096 | Lead time: 20–24 weeks from deposit | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, project-specific section |
| REQ-OP012139-0099 | Quote basis: Budget estimate only; final quotation subject to complete project details. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.13, project-specific section |
| REQ-OP012139-0104 | 40% Deposit upon order | Unreviewed; Wording located in source text | DOC-OP012139-PDF · p.14, payment schedule |
| REQ-OP012139-0105 | 30% Prior to dispatch from Europe | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.14, payment schedule |
| REQ-OP012139-0106 | 20% Prior to dispatch from Powerplants | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.14, payment schedule |
| REQ-OP012139-0107 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.14, payment schedule |
| REQ-OP012139-0108 | GST \| $8,651 | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 8; PDF p.14 |
| REQ-OP012139-0109 | Total including GST \| $95,162 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 6, row 9; PDF p.14 |
| REQ-OP012139-0110 | GST \| $2,055 | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 16; PDF p.14 |
| REQ-OP012139-0111 | Total including GST \| $22,605 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 6, row 17; PDF p.14 |
| REQ-OP012139-0112 | GST \| $1,284 | Unreviewed; Source reread; wording requires review | DOC-OP012139-DOCX · DOCX table 6, row 26; PDF p.14 |
| REQ-OP012139-0113 | Total including GST \| $14,124 | Unreviewed; Wording located in source text | DOC-OP012139-DOCX · DOCX table 6, row 27; PDF p.14 |

## Assumptions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012139-0103 | Wireless compatibility: Bermad coils can have issues with this system, as the ohms are too high. Lower ohms are required. | Unreviewed; Source reread; wording requires review | DOC-OP012139-PDF · p.12, project-specific section |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |
| selected_fertigation_model | NutriOne | Explicit user confirmation; NutriJet in filenames is not authoritative. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP012139/project.json) · [Field bindings](../data/projects/OP012139/quotation-bindings.json)
