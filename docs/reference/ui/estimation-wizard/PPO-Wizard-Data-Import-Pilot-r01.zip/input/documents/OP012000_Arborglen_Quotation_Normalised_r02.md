---
schema: ppo.mapped-historical-quotation.r02
normalisation_revision: r02
project_id: OP012000
quotation_id: PQ004843
customer: Arborglen
source_date: 2026-08-10
source_pdf_revision: V4
source_word_revision: V3
selected_configuration: two_Compass_4s
purchase_status: user_confirmed_purchased
accepted_quotation_revision: null
acceptance_date: null
currency: AUD
price_authority: SRC-WB
configuration_authority: SRC-USER_and_SRC-WB
current_selected_total_ex_gst: 60570.00
current_selected_gst: 6057.00
current_selected_total_including_gst: 66627.00
issued_alternative_base_ex_gst: 70690.00
issued_optional_accessory_subtotal_one_each_ex_gst: 3410.00
source_document: SRC-PDF
companion_workbook: OP012000_Arborglen_Estimation_Normalised_r02.xlsm
refresh_batch_id: REFRESH-20260913-R01
registry_project_id: PRJ-OP012000
registry_price_revision_id: REV-OP012000-N16e1132815eb-PRICE
registry_data_file: ../data/projects/OP012000/project.json
field_bindings_file: ../data/projects/OP012000/quotation-bindings.json
normalised_workbook_sha256: 8e4ed6af4ae17d1427050edfd356f9a45424076b52c523a4f93e75099c4c6127
current_prices_approved: false
native_excel_verified: false
---

# Arborglen — normalised quotation

Internal extraction copy for **OP012000 / PQ004843**. The selected configuration is **two separate Compass 4s controllers, two PCs, two alarm diallers and two UPS units**, as confirmed by the user and costed in the workbook. Current selected pricing is **AUD 60,570 ex GST**.

The supplied Word V3 and PDF V4 describe a **Compact CC alternative**. They are retained as historical scope and commercial evidence, not represented as an updated or accepted Compass quotation. The user confirms a purchase of two units; the accepted document revision and acceptance date have not been supplied. This document is a static extraction snapshot, not a customer-issued offer.

## 1. Quote and customer details

| Field | Value |
| --- | --- |
| Opportunity | OP012000 |
| Quotation | PQ004843 |
| Customer | Arborglen |
| Contact | Roberto Boada |
| Billing / site / delivery address | 35 Boronia Road, Glenorie, NSW 2157 |
| Account manager | Andrew McIlwain, NSW Regional Account Manager |
| Supplier | Powerplants Australia Pty Ltd, 27 Technology Circuit, Hallam, Victoria 3803 |
| Source quotation date | 10 August 2026 |
| Source revisions | PDF V4; Word V3, from filenames |
| Selected controllers | Two separate Priva Compass 4s |
| Purchase outcome | User confirmed purchased; accepted revision/date not supplied |

Sources: SRC-PDF pp.1–2,10; SRC-WORD corresponding sections; SRC-USER. Project Info in the original workbook still has OP01XXXX/PQ00XXXX placeholders: canonical identifiers are populated in PPO Estimate without replacing historical source metadata.

## 2. Current selected pricing

Amounts are **AUD excluding GST**. These are extended package prices, not prices to multiply again by the physical unit quantity.

| Package ID | Selected package | Physical primary units | Extended sell AUD | Workbook source |
| --- | --- | --- | --- | --- |
| ARB-P01 | Two Compass 4s — control package | 2 | 53,750.00 | Pricing!F4 |
| ARB-P02 | PC packages — two units | 2 | 3,620.00 | Pricing!F18 |
| ARB-P03 | Alarm dialler packages — two units | 2 | 2,500.00 | Pricing!F19 |
| ARB-P04 | UPS — two units | 2 | 700.00 | Pricing!F20 |

| Total | AUD |
| --- | --- |
| Selected total ex GST | 60,570.00 |
| GST at 10% | 6,057.00 |
| Selected total including GST | 66,627.00 |

Pricing!B4 has bundle quantity **1**, while Control!M23 has **2** physical Compass 4s units. Pricing!B18:B20 says “Each”, but workbook F18:F20 contains amounts already extended for two units. Do not double either group. Accessories were labelled optional in the proposal; the user confirms both sets were purchased.

The original Pricing!G25 formula `53750+3410*2` returns the correct saved total but would remain fixed after a price edit. In the normalised copy it is replaced by `SUM(F4,F18:F20)`. Its current result remains $60,570; the original GST formulas are retained. Both the original formula and change are documented in PPO Checks.

### Issued alternative pricing — separate historical basis

Source: SRC-PDF p.9 section 6.1; SRC-WORD Investment Summary.

| Item | Issued quantity basis | Issued sell ex GST |
| --- | --- | --- |
| Compact CC alternative | One project bundle | 70,690.00 |
| PC option | Each | 1,810.00 |
| Alarm dialler option | Each | 1,250.00 |
| UPS option | Each | 350.00 |
| Accessory subtotal as printed | One of each | 3,410.00 |

The printed Compact CC base is $77,759 including GST; the printed one-each accessory subtotal is $3,751 including GST. There is no printed combined selected Compass total in V4. The $70,690 alternative and $60,570 selected configuration have different scope, so their difference is not treated as a like-for-like pricing error. The workbook retains the alternative on Control (2).

## 3. Selected equipment, licences and I/O

Source: SRC-WB Control, with quantities authoritative under SRC-USER. Item IDs are trimmed only; original casing and source descriptions remain traceable.

| Item ID | Workbook description | Quantity | Source row |
| --- | --- | --- | --- |
| PRI.3772101 | Compass 4s | 2 | Control!23 |
| pri.3779016 | Soil/pot temperature sensor with cable 6m | 3 | Control!24 |
| pri.3779013 | Water temperature sensor, length=80mm | 2 | Control!25 |
| pri.3771026 | Priva Weather station WSC11 with connection cable | 2 | Control!26 |
| pri.3779205 | Linear light sensor in aluminium housing | 1 | Control!27 |
| pri.3779242 | Mounting bracket Priva Weather station WSC11 | 2 | Control!28 |
| pri.5215001 | Priva Blue ID C-Line DOR6 Relay output module | 4 | Control!29 |
| pri.3779207 | Radiation sensor CM3-P in aluminium housing | 1 | Control!30 |
| pri.32210 | Compass Climate Advanced | 4 | Control!31 |
| pri.32100 | Compass Irrigation Basic | 2 | Control!32 |
| pri.32140 | Compass Water room Basic | 1 | Control!33 |
| BOM.ECS.CLI.000.000.005.0 | Climasense Complete Set Priva Systems (Integro / Connext / Compass / Maximiser) | 4 | Control!42 |
| ICT.COM.000.000.000.012.0 | Desktop PC Lenovo ThinkCentre M70Q G3 i5-12400T | 2 | Control!72 |
| ICT.HDM.SCR.000.000.003.0 | HDMI Cable Screened DisplayPort to HDMI 3m Length Black | 2 | Control!75 |
| ICT.ADA.USC.ETH.000.000.0 | USB Type C to Ethernet Network Adaptor Black | 2 | Control!76 |
| ICT.COM.000.000.000.009.0 | USB Stick 64GB USB 3.1 | 2 | Control!77 |
| ICT.COM.000.000.000.013.0 | Monitor 27in FHD,16:9, 250N, 1920x1080, 1000:1,5MS, HA, VGA, DP, HDMI, 3YR WA | 2 | Control!78 |
| ICT.COM.000.000.000.023.0 | Alarm Dialler SMS 4G/LTE 4 x Contact Input 2 x Relay Output 1 x 10/100 Mbps RJ45 | 2 | Control!79 |
| ICT.COM.000.000.000.024.0 | Mounting Bracket For Antenna Model AA-101 or AA-102 | 2 | Control!80 |
| ICT.COM.000.000.000.019.0 | Antenna GSM Vertical 2m Cable SMA Male Connector Adesys | 2 | Control!81 |
| UPS.40A.40A.12C.01P.000.0 | UPS 240VAC to 240VAC 720W 1200VA 1Phase Stand Alone With Lead Cable | 2 | Control!82 |

The licence quantities are **4 Compass Climate Advanced, 2 Compass Irrigation Basic and 1 Compass Water room Basic**. There are **4 Blue ID C-Line DOR6 relay output modules**. The five Priva Office Direct basis-program placeholder rows M34:M38 are zero and are not included. This list does not infer licence allocation or available I/O capacity per controller.

The selected costing also includes wiring, glands, cable ties, mounting chain, labels, contingency, freight, labour and travel allowances. PPO Lines contains every mapped item row, including zeros and alternatives. Group totals in AY/AZ are not additional parts. Selected internal allowances include 50 hours senior controls technician labour, 11 hours travel, 8 hours project coordination and 8 hours engineering (Control!M61:M64); these are costing quantities, not a promised customer service duration.

### Specification differences retained for review

- **Weather stations:** workbook costs two WSC11 stations and two mounting brackets, plus one separate CM3-P radiation sensor. The quotation describes one WSC11 with radiation and a 15 m cable. Keep the workbook quantities and clarify final specification/placement before issuing a selected-system quote.
- **PC:** workbook selects Lenovo ThinkCentre M70Q G3 i5-12400T and 27-inch monitors. Quotation text describes 11th Gen i5, 8 GB RAM, 256 GB SSD, Windows 10 Pro and 24-inch-or-larger monitor. Do not transfer the quoted memory, storage or OS to the selected SKU without evidence. Wireless keyboard/mouse row Control!M74 is zero.
- **UPS:** workbook selects 1,200 VA / 720 W; the quotation states 1,000 VA and mentions a Compact 530 controller. That copied controller reference is not the selected model.

## 4. Quoted site requirements

Source: SRC-PDF p.3, section 1. The source matrix was checked visually. A dash below means the source cell is blank, **not a confirmed zero**. Site demand is kept separate from software licence counts.

| Function / measurement | Comp.01 | Comp.02 | Comp.03 | Orchids |
| --- | --- | --- | --- | --- |
| Climate compartment | 1 | 1 | 1 | 1 |
| T/RH measurement | 1 | 1 | 1 | 1 |
| Linear light measurement | — | — | — | 1 |
| Soil temperature measurement | 1 | 2 | — | — |
| Screen zone control | 1 | 1 | 1 | 1 |
| Screen motor (time with control box) | 1 | 1 | 1 | 1 |
| Vent zone control (windward/leeward) | — | 1 | — | — |
| Vent motor (time with control box) | — | 2 | — | — |
| Circulation fan control (with control box) | — | — | — | 1 |
| Heat mixing valve control | 1 | 1 | — | — |
| Heat circulation pump on/off (with control box) | 1 | 1 | — | — |
| Heating on/off control | — | — | 1 | 1 |
| Pad wall pump on/off | — | 1 | 1 | 1 |
| Pad wall inlet wall open/close | — | — | 1 | — |
| Pad wall fan control steps | — | 2 | 1 | 2 |
| Start programs | 1 | 1 | — | — |
| Irrigation valves | 4 | 8 | — | — |

The WSC11 row has **one shared quantity across the four areas**, covering outside temperature, humidity, wind speed/direction and rain detection. The current workbook costs two WSC11 units. The annotated site image identifies the orchid greenhouse and compartments 1–3. It is retained in the original PDF; its image is omitted here. It does not establish an approved final two-Compass network layout.

## 5. Quoted sensor specifications

Source: SRC-PDF pp.6–7, section 2.4. These are historical quoted descriptions, not independently verified current manufacturer specifications. Selected item IDs and quantities are governed by the workbook.

| Sensor | Parameter | Quoted specification |
| --- | --- | --- |
| WSC11 | Quoted cable length | 15 m |
| WSC11 | Quoted functions | Outside temperature, humidity, wind velocity/direction, rain detection, radiation |
| Linear light sensor | Quoted measuring level | 150 klux |
| ClimaSense | Quoted quantity | 4 each |
| Warm water sensor | Quoted quantity | 2 each |
| Warm water sensor | Nominal length | 80 mm |
| Warm water sensor | Immersion sleeve / protection tube | 65 mm |
| Warm water sensor | Process connection | G½ |
| Warm water sensor | Minimum operating temperature | 10 °C |
| Warm water sensor | Maximum operating temperature | 120 °C |
| Warm water sensor | Process pressure minimum | 0 bar |
| Warm water sensor | Process pressure maximum | 20 bar |
| Warm water sensor | Restriction | Non-condensing only; do not use in cold water loops |
| Warm water sensor | Resistance at 25 °C | 3000 ohm |
| Soil/slab sensor | Quoted quantity | 3 each |
| Soil/slab sensor | Cable length | 6 m |
| Soil/slab sensor | Minimum operating temperature | 0 °C |
| Soil/slab sensor | Maximum operating temperature | 50 °C |
| Soil/slab sensor | Resistance at 25 °C | 3000 ohm |
| Soil/slab sensor | Protection tube | Stainless steel AISI 304, Ø10 × 100 mm |
| Soil/slab sensor | Connection cable | 2 × 0.5 mm² |

## 6. Installation, customer responsibilities and exclusions

Installation and commissioning are included in the source proposal, with removal of existing controllers, installation of new cabinets, termination of cables in the new cabinets, software setup and training. Training duration and a detailed commissioning test protocol are not specified. Source: SRC-PDF p.8, section 4.

Customer responsibilities from p.8 section 3, with the SIM detail from p.7:

| Area | Customer responsibility |
| --- | --- |
| Existing equipment | All control boxes and equipment to be in working order. |
| Existing cables | All cables to be in working order. |
| Existing cable identification | Label and test all cables connected to the existing controllers. |
| New cables | Supply and installation of all new cables. |
| Network | Provide network connection. |
| Alarm dialler SIM | Provide SIM card for alarm dialler(s); activated suitable plan on an Australian provider operating on the Telstra network, as historically quoted. |

The quote assigns **new cable supply and installation** to the customer, while the workbook includes cable materials and Powerplants cabinet terminations. These may concern different work boundaries; the exact split is not invented. Retain both records and confirm the boundary before reusing the wording.

**Conditional alternative only:** fibre cable supply, running and termination between the main cabinet and distributed I/O cabinet is a customer responsibility expressly marked “Compact CC option only”. It must not automatically populate the confirmed two-Compass scope. No blanket exclusion of all cabling or networking work is inferred.

## 7. Freight and delivery

Source: SRC-PDF p.8, section 5. **International sea freight, duty and local freight are included.** Standard-option lead time is **14–18 weeks from deposit**, with final schedule to be confirmed on placement of deposit. These are historical proposal terms, not current delivery assurances.

The selected workbook includes a $525 international sea freight cost line at Control!AW54, driven by the original freight allocation schedule. Preserve the existing landed-cost treatment and avoid adding the schedule or quoted freight inclusion again to the detail costs or selling price.

## 8. Payment, validity and currency

Source: SRC-PDF p.9, sections 6.2–6.3. Payment is in AUD.

| Milestone | Percentage |
| --- | --- |
| Deposit on order | 40% |
| Prior to dispatch from overseas | 30% |
| Prior to dispatch from Powerplants | 20% |
| Completion of commissioning | 10% |

The source proposal states **30 days** validity while exchange rate remains within **2%** of the quoted **0.61 EUR per AUD**, with requoting outside those bounds. The workbook costing rate is **0.59 EUR per AUD** at Project Info!B19. These are distinct historical fields; the workbook remains the estimating price authority. No inference is made that V4 commercial wording was accepted unchanged for the selected Compass configuration.

## 9. Compact CC alternative — reference only

The quotation describes one central control location, with the main cabinet in the northeast corner of Zone 1 and distributed I/O in the southeast corner of the orchid greenhouse. Its hardware schedule lists an 800 × 800 mm main cabinet, 500 × 600 mm orchid cabinet, process controller materials, transrouters, fibre switches, internal terminators, Smart Bridge and 16/32 I/O cards “as needed”. Source: SRC-PDF p.6 section 2.3. This architecture must not be copied as the confirmed two-Compass design.

The alternative workbook explicitly costs **three 16-analog-in / 32-digital-out I/O modules** at Control (2)!M22. Its licence rows M34:M45 differ from the quoted schedule. For example, workbook start programs = 3, valve groups = 12, irrigation-valve licences = 3; the quoted schedule shows 2, 2 and 12 respectively. These are retained as workbook-authoritative alternative quantities, without swapping numbers to make the proposal match. They are not selected Compass requirements. Full alternative lines are in PPO Lines with scope classification Alternative.

The p.9 **AirFibre clause** allows Arborglen to instruct removal of the distributed I/O box if a viable link between the Compact CC main box and orchid-house cabinet cannot be found. This applies to that alternative only. No deduction value is specified and none is invented.

## 10. Outcome and original terms

The user states that Arborglen purchased two separate Compass 4s units. Record **user-confirmed purchased**, with **accepted quotation revision and acceptance date unknown**. The supplied PDF p.10 acceptance fields are blank and describe Compact CC. It cannot establish the accepted Compass scope document.

Original Terms and Conditions remain in SRC-PDF **pp.11–16, section 8**, and the corresponding Word file. The V3 Word acceptance paragraph refers to pp.15–20; the V4 PDF correctly points to pp.11–16. The PDF page reference is used here. Boilerplate, marketing, contents, images and signature form layout are omitted from this extraction copy; their omission does not change the original documents.

## 11. Reconciliation and reuse notes

| ID | Subject | Evidence | Treatment |
| --- | --- | --- | --- |
| RESOLVED-01 | Selected controller | User confirms two Compass 4s; Control!M23=2. V3/V4 describe Compact CC. | Use selected Compass costing. Keep Compact alternative separately; do not present the supplied V4 as the accepted Compass quotation. |
| RESOLVED-02 | Accessory quantity / price basis | Control M72/M79/M82=2; price schedule F18:F20 totals $6,820. PDF gives each prices $1,810/$1,250/$350. | Do not multiply the workbook extended accessories by two again. The issued one-each subtotal is $3,410. |
| REFINED-01 | Responsive grand total | Original Pricing!G25 is 53750+3410*2, which cannot track costing edits. | Normalised copy uses SUM(F4,F18:F20), preserving baseline $60,570. G26/G27 retain original formulas. |
| REVIEW-01 | Weather sensor schedule | Selected workbook has two WSC11 stations and brackets, plus one separate CM3-P radiation sensor; PDF describes one WSC11 with radiation. | Keep workbook quantities. Confirm final placement and specification wording before issuing a selected-system quotation; no invented sensor integration rule. |
| REVIEW-02 | PC / UPS specifications | Workbook: Lenovo i5-12400T, 27-inch monitors, 1,200 VA / 720 W UPS. PDF: 11th Gen i5, 24-inch-or-larger, 1,000 VA and Compact 530 boilerplate. | Use workbook item IDs and quantities. Do not infer unlisted memory, storage or OS of the selected PC from the earlier generic description. |
| REVIEW-03 | Area / licence / I/O allocation | Selected Compass: four Climate Advanced, two Irrigation Basic, one Water room Basic and four DOR6 modules. Compact alternative has different modules and licence counts. | Preserve both evidence sets by configuration. No automatic conversion of site valves to licences or inference of per-controller capacity. |
| REVIEW-04 | Accepted document and terms | Purchase is user-confirmed; supplied V4 signature fields are blank and describe the alternative. | Accepted Compass quote revision/date and any revised commercial terms are not supplied. Retain historical payment/delivery wording with source attribution. |
| REVIEW-05 | Customer cable boundary | Quote assigns new cable supply/installation to customer while selected costing includes cable materials. | Retain both facts. Clarify material/termination boundary for reuse rather than treating all cable materials as excluded. |
| REVIEW-06 | Existing workbook dependencies | Original templates/report lookups contain saved errors; legacy VBA references an Upload sheet not present in source. | All original components remain. Native Excel recalculation, buttons and external refresh still require a desktop check. |
| REVIEW-07 | Historical rates / delivery | Workbook EUR/AUD 0.59, quote 0.61. Quote lead time 14–18 weeks and validity 30 days. | Keep price authority with workbook; do not treat historical rate or lead time as a new supplier commitment. |

## 12. Sources and extraction use

| Source ID | Original filename / evidence | Role | Revision / date | Authority | SHA-256 |
| --- | --- | --- | --- | --- | --- |
| SRC-WB | OVERALL-OP012000-ARBORGLEN-V1.xlsm | Original costing workbook | V1 in filename; costing date not established | Authority for current prices, selected components, licences and I/O | c208df150856c4109c0c39fa7e1cf8452b281b55212e3246d8b0e37dcdd84be1 |
| SRC-PDF | OP012000 Arborglen Control V4 PQ004843.pdf | Customer-facing proposal | V4 in filename; 10 August 2026 | Quoted scope and terms; Compact CC alternative, not selected Compass configuration | 3d8af7256230867e5a18e649cb70b79775c27b5fae5dc71c49c3d6f525fc138e |
| SRC-WORD | OP012000 Arborglen Control V3.docx | Earlier editable quotation | V3 in filename; 10 August 2026 | Earlier wording; not a second project or proof of accepted revision | aead47b1e2d78e244744d958ea197eec28d106940953029e30e8651803008340 |
| SRC-USER | User confirmation in this conversation | Configuration and source authority | Confirmation date not supplied | Two Compass 4s purchased; two PCs, two diallers, two UPS; workbook governs prices/licences/I/O | Not a file |

The workbook tables use project ID `OP012000`, package IDs `ARB-P…` (selected), `ARB-A…` (alternative), `ARB-T…` (inactive templates), line IDs, requirement IDs and source IDs. Filter **PPO Lines Export state = Selected** for the selected detail export. Use PPO Packages for rounded selling totals; never add package and line totals together. Zero-quantity template items, alternative products and optional historical wording are not mandatory wizard dependencies.

This normalised workbook retains the original estimator and all supporting sheets. Do not delete them. New or inserted items require extending the extraction mapping and reviewing source locators. The Markdown is static and must be regenerated or reviewed when scope or prices change.

## Register field links and refresh status

This is an internal historical extraction document. Its customer-facing sections are reference content, not a newly issued quotation. The linked JSON holds the complete revision, package, component, specification and source IDs. Historical prices and clauses require review before reuse.

| Content | Registry field / record |
| --- | --- |
| Customer | Projects.Customer · PRJ-OP012000 |
| Pricing revision | Revisions.RevisionID · REV-OP012000-N16e1132815eb-PRICE |
| Equipment and amounts | Packages.PackageID / SourceSellTotal · see pricing_packages |
| Component quantities and costs | Estimate_Lines.LineID / Quantity / SourceLineCost · see components |
| Specifications and responsibilities | Requirements.RequirementID / SourceEvidenceStatus · see requirements |
| Original files | Documents.DocumentID / SHA256 · see source_documents |

[Project data](../data/projects/OP012000/project.json) · [Field bindings](../data/projects/OP012000/quotation-bindings.json) · [Workbook](../workbooks/OP012000_Arborglen_Estimation_Normalised_r02.xlsm)
