---
schema: ppo.mapped-historical-quotation.r02
normalisation_revision: r02
project_id: OP011896
quotation_id: PQ004817
customer: Bush to Bowl
source_date: 2026-06-22
source_revision: null
acceptance_status: not_evidenced
acceptance_date: null
currency: AUD
price_authority: SRC-WB
current_workbook_total_ex_gst: 50160.00
issued_quotation_total_ex_gst: 50140.00
scope_authority: "Issued quotation, with Dean Fiedler's explicit corrections"
source_document: SRC-PDF
companion_workbook: OP011896_Bush_to_Bowl_Estimation_Normalised_r02.xlsm
refresh_batch_id: REFRESH-20260913-R01
registry_project_id: PRJ-OP011896
registry_price_revision_id: REV-OP011896-N51195b4e1460-PRICE
registry_data_file: ../data/projects/OP011896/project.json
field_bindings_file: ../data/projects/OP011896/quotation-bindings.json
normalised_workbook_sha256: 69211107aeb608e57b85eba9ee0d72d77645d21fbf5bacf83db4e09d703c0dd7
current_prices_approved: false
native_excel_verified: false
---

# Bush to Bowl — normalised quotation

This is an internal extraction copy for opportunity **OP011896**, quotation **PQ004817**. Current workbook prices are separated from the issued quotation. Dean confirms **AUD 50,160 ex GST** is correct, the turntable is to be disregarded, and drills and the infeed conveyor are optional accessories. Customer acceptance is not established by the supplied documents.

The source documents remain the historical originals. This Markdown is a snapshot, not an automatically synchronised quotation or evidence that an updated customer quotation has been issued.

## 1. Quote and customer details

| Field | Value |
| --- | --- |
| Opportunity | OP011896 |
| Quotation | PQ004817 |
| Title | Javo Ecobasic for Bush to Bowl |
| Date | 22 June 2026 |
| Revision | Not stated |
| Customer | Bush to Bowl |
| Contact | Adam; surname not stated |
| Billing and delivery address | 12 Wilga St, Ingleside, NSW 2101 |
| Account manager | Andrew Mcllawin, Account Manager (NSW), as written in source |
| Supplier | Powerplants Australia Pty Ltd |
| Supplier address | 27 Technology Circuit, Hallam, Victoria 3803 |
| Customer phone/email/ABN | Not stated in the relevant quotation fields |

Sources: SRC-PDF pp.1–2,10; SRC-WORD matching sections. The Word and PDF represent the same opportunity and are not separate project records.

## 2. Project requirements

The customer seeks more efficient potting, even soil filling and accurate drilled holes, with appropriate occupational health and safety arrangements. The proposed solution is one Javo Ecobasic potting machine with installation and commissioning. Crop, annual production target, confirmed pot sizes and a site-specific layout are not established. Source: SRC-PDF pp.3–5.

## 3. Current workbook pricing and scope

All amounts are AUD excluding GST. Package amounts are already extended selling prices. **Do not multiply the drills package price by the displayed quantity of two again.** “Selected” below means included in the current workbook calculation; it does not mean accepted by the customer.

| Package ID | Package | Price schedule quantity | Workbook amount | Classification | Source |
| --- | --- | --- | --- | --- | --- |
| B2B-P01 | Javo Ecobasic package | 1 | 42,840.00 | Base package; costed in current configuration | Pricing!F4 |
| B2B-P02 | Drills and drillplates | 2 | 730.00 | Optional accessory; costed in current configuration | Pricing!F5 |
| B2B-P03 | Infeed conveyor package | 1 | 6,590.00 | Optional accessory; costed in current configuration | Pricing!F6 |

| Measure | AUD |
| --- | --- |
| Base Ecobasic package | 42,840.00 |
| Optional accessories costed in this configuration | 7,320.00 |
| Current total ex GST | 50,160.00 |
| GST at 10% | 5,016.00 |
| Current total including GST | 55,176.00 |

The $50,160 total contains both optional accessory packages. The base Ecobasic package alone is $42,840. Removing an accessory selection changes the selected extraction total; it does not turn the confirmed $50,160 configuration into a base-machine-only price. Local freight is excluded. The turntable is disregarded.

### Issued quotation pricing — historical reference

Source: SRC-PDF p.6 section 5.1 and SRC-WORD Investment Summary.

| Item | Issued amount ex GST |
| --- | --- |
| Javo Ecobasic | 42,820.00 |
| Drills and drillplates | 730.00 |
| Infeed conveyor | 6,590.00 |
| Issued total ex GST | 50,140.00 |
| Issued GST | 5,014.00 |
| Issued total including GST | 55,154.00 |

The difference is $20 in the Ecobasic package. Dean confirms the workbook amount is correct; the exact reason or timing of the original price difference is not inferred. The issued optional turntable price of $10,520 ex GST is retained here solely as discarded source evidence and is excluded from current scope and totals.

## 4. Equipment and performance specifications

Source: SRC-PDF pp.3–4 sections 1.2–1.4. These are quoted historical specifications, not a current manufacturer datasheet or a throughput guarantee.

| Parameter | Quoted specification |
| --- | --- |
| Suitable pots | Round; square pots are optional |
| Minimum pot size | 80 mm |
| Maximum pot size | 210 mm |
| Optional minimum pot size | 55 mm |
| Minimum stated capacity | 1320 pots/hr |
| Maximum stated capacity | 2700 pots/hr |
| Capacity basis | Depends on machine configuration, pot and soil |
| Quoted soil bin capacity | 1300 L |
| Quoted machine weight | 690 kg |
| Power supply voltage | 400 V |
| Supply frequency | 50 Hz |
| Supply configuration | 3 phases + neutral + protective earth |
| Rated power | 2.3 kW |
| Pot positions | 8 each |
| Pot track speed adjustment | Mechanical |
| Pot dispenser | Mechanical; pot infeed conveyor separate |
| Pot take-off | Mechanical; left, right or front arrangement |
| Outfeed conveyor length | 3 m |
| Outfeed conveyor width | 150 mm |
| Outfeed conveyor equipment | Mechanical variable speed, support and end switch |
| Reverse elevator switch | Included |
| Mobility | Four wheels, including two swivel wheels with brakes |
| Soil return | Soil return system described |
| Pot-size adjustment | Central adjustment |

### Soil-bin configuration

The workbook selects one `JVO.00001.JECO-MA-A` machine with a **700 L** soil bin and one `JVO.00004.JECO-GB-OPZ` **600 L** extension. Together these explain the quoted **1,300 L** capacity. Do not treat 1,300 L as the universal capacity of an unconfigured base machine. Sources: SRC-WB A&L!H22:M23; SRC-PDF p.4.

### Included outfeed and optional infeed

The included outfeed conveyor is **3 m × 150 mm**, with variable speed, support and end switch. The optional infeed is **2 m × 150 mm** with support. These are different components. The workbook’s infeed package includes an electrical pot brake (`JVO.00006.JECO-POME-REM`) and pot supply conveyor (`JVO.00008.JECO-POME-TB15`), one of each. Sources: SRC-WB A&L!H51:M52; SRC-PDF pp.3–4; SRC-USER accessory clarification.

### Optional drills and drillplates

The workbook costs **two 2.5 cm drills** (`JVO.01044.201-430-025`) and **two 2.5 cm drillplates** (`JVO.01336.201-421-025`), with $100 internal air freight cost. The quotation asks the customer to specify sizes. Record **25 mm as the costed size**, with final required sizes still to be confirmed. These are optional accessories despite the issued specification table using the word “Included”. Sources: SRC-WB A&L!H63:AX65; SRC-PDF p.4; SRC-USER.

### Other costed package components

The Ecobasic costing also selects a reverse elevator switch, an extra switched power plug, packaging/handling, a 10 m extension cable, a 5-pin 20 A plug, and two adjustable conveyor plates. These are workbook configuration records, not additional separately quoted package charges. The complete item IDs and quantities are retained in PPO Lines. Source: SRC-WB A&L!H24:M29.

## 5. Layout and interfaces

The source describes mechanical pot take-off to the left, right or front of the pot track. The p.5 figure shows alternative outfeed arrangements with approximate dimensions; no final customer layout is identified. Retain the original figure for spatial review. Its image is omitted from this extraction copy, and its approximate geometry has not been turned into approved site dimensions. Source: SRC-PDF pp.3,5.

## 6. Installation and commissioning

**Installation and commissioning are included.** Supply, installation and commissioning are ticked for all three priced packages on p.6. The project-specific scope excludes customer electrical and civil works. A commissioning procedure, acceptance test, training duration and number of visits are not stated. Sources: SRC-PDF p.5 sections 2–3; p.6 section 5.1.

Internal estimating allowances include 13 hours of senior installer labour, 15 hours of senior installer travel and 20 hours of project coordination, plus travel-related expenses. These are costed allowances and must not be interpreted as separately promised customer service durations. Source: SRC-WB A&L!M30:M37.

## 7. Customer responsibilities and exclusions

The following are customer responsibilities, to be arranged before installation. Source: SRC-PDF p.5 section 2.

| Area | Responsibility |
| --- | --- |
| Electrical works | Customer supplies electrical works before installation. |
| Civil works | Customer supplies civil works before installation. |
| Unloading | Purchaser is responsible for unloading. |
| Security | Purchaser is responsible for security of materials on site. |
| Insurance | Purchaser is responsible for insurance of materials on site. |
| Electrical supply | Customer provides a three-phase 400 V supply before installation. |

Local freight is also excluded from the price (p.5 section 4). The workbook’s local freight row has quantity zero; its $2,500 unit-cost input is an unselected allowance, not an included charge or evidence of free delivery. The turntable is disregarded by explicit user instruction.

## 8. Freight and delivery

| Item | Basis |
| --- | --- |
| International sea freight and duty | Included in quotation price. |
| Local freight | Excluded. |
| Availability at quotation date | Ecobasic stated to be in stock at Hallam on 22 June 2026. |
| Historical stock reservation | Stated hold until 1 August 2026. This is not a current stock commitment. |
| Final delivery | To be confirmed on placement of deposit. |
| Drill accessory freight | Workbook includes $100 air freight cost in the drill package; not a separate customer surcharge. |

Sources: SRC-PDF p.5 section 4; SRC-WB A&L!U65:AX65. The costing uses an explicit $4,500 freight allocation on the main machine line. Do not add the entire separate $15,400 container schedule to the landed line costs. Sources: SRC-WB A&L!AR22:AT22 and I14:K14.

## 9. Payment terms, validity and grant wording

Source: SRC-PDF p.6 sections 5.3–5.4.

| Milestone | Percentage |
| --- | --- |
| Deposit on order | 50% |
| Prior to dispatch from Powerplants | 40% |
| Completion of commissioning | 10% |

Payment is in AUD. The project-specific validity is **31 days**. Standard terms p.11 clause 2(b) state 30 days; the discrepancy is retained for clarification before reissuing. No legal priority between those passages is inferred. No explicit quotation exchange rate is stated; the separate costing input is **0.57 EUR per AUD** at Project Info!B19.

“Sign pending grant approval” appears with an unmarked checkbox. Grant approval and any conditional acceptance are not established.

## 10. Acceptance and source terms

The supplied acceptance form is uncompleted. Acceptance status is **not evidenced**, and acceptance date is unknown. This does not establish that the opportunity was lost or that no separate acceptance exists. Source: SRC-PDF p.10.

The original Terms and Conditions remain in SRC-PDF pp.11–16, section 8, and the corresponding Word document. Their boilerplate is omitted here, as requested. The original source pages remain the reference; omission does not remove those terms from the original quotation. No separate terms version identifier is supplied.

## 11. Clarifications and reuse checks

| ID | Subject | Evidence | Treatment |
| --- | --- | --- | --- |
| RESOLVED-01 | Pricing correction | Workbook Pricing!B7 is $50,160 versus $50,140 in Word/PDF. Difference is $20 in the Ecobasic package. | Use workbook price per Dean; retain issued values separately. |
| RESOLVED-02 | Optional accessory classification | Drills and infeed conveyor appear in the issued investment total but are optional accessories per Dean. | Keep costed selection and optional classification separate; no customer acceptance is implied. |
| RESOLVED-03 | Disregarded turntable | PDF optional turntable $10,520; workbook quantities M80:M82 and current extended price are zero. | Disregard per Dean. Preserve evidence without including it in current totals or selected export. |
| OPEN-01 | Final drill sizes | Workbook costs 2.5 cm drills and drillplates; quote asks customer to specify size. | Retain 25 mm as costed specification; confirm final sizes before a new commitment. |
| OPEN-02 | Validity wording | Project-specific section 5.4 says 31 days; standard terms clause 2(b) says 30 days. | Keep 31 days as quoted project field and retain discrepancy; clarify before reissuing. |
| OPEN-03 | Outcome and grant condition | No completed acceptance form; grant-related checkbox is unmarked. | Keep acceptance and grant approval unconfirmed. Do not infer from supplied filenames. |
| OPEN-04 | Delivery and arrangement | Availability/hold statement is historical; delivery and outfeed arrangement not finalised in supplied documents. | Confirm availability, delivery and site layout for any updated quotation. |
| OPEN-05 | Original calculation dependencies | Existing lookup/report errors, macros, embedded MYOB data and external link remain in the source workbook. | Retain original sheets. Test native Excel recalculation and the buttons/refresh functions actually used. |
| OPEN-06 | Freight allocation | A&L freight schedule has a $15,400 container cost, but the machine line uses an explicit $4,500 allocation. Drills include $100 air freight. | Preserve the source allocation; do not add the whole container schedule to extracted landed costs. |

## 12. Source manifest and extraction use

| Source ID | Original file / evidence | Role | Revision / date | Authority | SHA-256 |
| --- | --- | --- | --- | --- | --- |
| SRC-WB | OVERALL - OP011896-Bush to Bowl-Javo-Ecobasic.xlsm | Estimation workbook | Revision not stated | Authority for current estimating prices and item selections | 933ab8322cb2fbf1ec0f91c7ba8193127c1541e630b6321f5d00e32760337f6c |
| SRC-PDF | OP011896-Bush to Bowl-Javo-Ecobasic-PQ004817.pdf | Issued quotation | 22 June 2026; revision not stated | Issued scope and commercial wording; prices retained separately | d56a9e4865377085a59717c3cf67b1545365d064cc6758383633592717cabccd |
| SRC-WORD | OP011896-Bush to Bowl-Javo-Ecobasic.docx | Quotation working document | 22 June 2026; revision not stated | Corroborates PDF pricing, scope and terms; not a separate opportunity | 969cc67a87cf48c9bcf25a1ffa3bfd1c07bef48860c16377f2a8fa157823588c |
| SRC-USER | Dean Fiedler confirmations in this conversation | User clarification | Prior confirmation; date not inferred | $50,160 correct; disregard turntable; drills and infeed conveyor are optional accessories | Not stated |

Use `project_id`, package IDs, source IDs and requirement IDs to join the Markdown and workbook records. Import the current workbook prices as estimating authority; retain issued values in separate historical fields. Do not count Word and PDF as two projects, add package prices to detailed line prices, or infer mandatory equipment dependencies from one costed example.

Coverage: identity/customer fields (pp.1–2,10), requirements and equipment (pp.3–4), layout context and scope/delivery (p.5), pricing/payments/validity (p.6), and acceptance/terms references (pp.10–16). Marketing sections, contents page, decorative imagery, repeated headers/footers and signature form layout are omitted. The original technical layout remains available in the PDF.

## Register field links and refresh status

This is an internal historical extraction document. Its customer-facing sections are reference content, not a newly issued quotation. The linked JSON holds the complete revision, package, component, specification and source IDs. Historical prices and clauses require review before reuse.

| Content | Registry field / record |
| --- | --- |
| Customer | Projects.Customer · PRJ-OP011896 |
| Pricing revision | Revisions.RevisionID · REV-OP011896-N51195b4e1460-PRICE |
| Equipment and amounts | Packages.PackageID / SourceSellTotal · see pricing_packages |
| Component quantities and costs | Estimate_Lines.LineID / Quantity / SourceLineCost · see components |
| Specifications and responsibilities | Requirements.RequirementID / SourceEvidenceStatus · see requirements |
| Original files | Documents.DocumentID / SHA256 · see source_documents |

[Project data](../data/projects/OP011896/project.json) · [Field bindings](../data/projects/OP011896/quotation-bindings.json) · [Workbook](../workbooks/OP011896_Bush_to_Bowl_Estimation_Normalised_r02.xlsm)
