---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP012146
registry_project_id: PRJ-PB
registry_price_revision_id: REV-PB-PRICE
registry_data_file: ../data/projects/OP012146/project.json
field_bindings_file: ../data/projects/OP012146/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# Perfection Berries — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP012146 |
| Customer | Perfection Berries |
| Site | Caboolture |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 111,940.00 |
| Optional schedule ex GST | 0.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 111,940.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-PB-PRICE-004 | Priva Compact CC | Base | 28,560.00 | DOC-PB-XLSM · 'Pricing'!A4:H4 |
| PKG-PB-PRICE-005 | Priva NutriJet 600 Bypass | Base | 54,680.00 | DOC-PB-XLSM · 'Pricing'!A5:H5 |
| PKG-PB-PRICE-006 | Priva Wireless GroScale | Base | 28,700.00 | DOC-PB-XLSM · 'Pricing'!A6:H6 |
| PKG-PB-PRICE-013 | Priva Wired GroScale | Alternative | 23,970.00 | DOC-PB-XLSM · 'Pricing'!A13:H13 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-PB-0001 | Wall mounted cabinet 800x800 standard with Gateway: 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 2 |
| REQ-PB-0002 | I/O module AI16/DO32 (AC): 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 3 |
| REQ-PB-0003 | Basic materials for Process Controller (CPC2.1): 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 4 |
| REQ-PB-0004 | Priva Office Direct for Priva for Compact CC: 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 6 |
| REQ-PB-0005 | Compact CC Water system: 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 7 |
| REQ-PB-0006 | Compact CC Dosing channel: 5 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 8 |
| REQ-PB-0007 | Compact CC Starting program: 5 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 9 |
| REQ-PB-0008 | Compact CC Valve group: 5 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 10 |
| REQ-PB-0009 | Compact CC Irrigation valve control: 5 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.6; DOCX table 1 row 11 |
| REQ-PB-0010 | Unit: NutriJet 600 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 1 |
| REQ-PB-0011 | Unit controller: Compact CC Substation | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 2 |
| REQ-PB-0012 | Application type: Bypass | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 3 |
| REQ-PB-0013 | Mainline flow rate: 90m3/h at 5 bar | Verified; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 4 |
| REQ-PB-0014 | Mainline pressure: 4 bar | Verified; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 5 |
| REQ-PB-0015 | No. of EC dosing channels: 4 (1000 LPH) | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 6 |
| REQ-PB-0016 | No. of acid dosing channels: 1 (50 LPH) | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 7 |
| REQ-PB-0017 | Pump: Lowara 33SV3N | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 8 |
| REQ-PB-0018 | Inlet diameter: 3” glue | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 9 |
| REQ-PB-0019 | Outlet diameter: 3” glue | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 10 |
| REQ-PB-0020 | Mixing chambers: 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 11 |
| REQ-PB-0021 | Mains power: 3x400V, 50Hz, CE | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 12 |
| REQ-PB-0022 | Electrical power: 7.5kW/14.3A | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 13 |
| REQ-PB-0027 | Base station and aerial with 12VDC power supply (Needs a GPO within 2m, includes aerial bracket & 10m cable, requires CAT5 cable to be run to base station from existing Controller network switch): 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 3 row 2 |
| REQ-PB-0028 | Data settings (Up to 5 scales): 1 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 3 row 4 |
| REQ-PB-0029 | Alarm input: 1 | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.11; DOCX table 3 row 5 |
| REQ-PB-0030 | Scale Weighing platform – 100kg: 4 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 2 |
| REQ-PB-0031 | Sensor module (915 MHz) for scale (rugged) V2 (915Mhz): 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 3 |
| REQ-PB-0032 | Drain water system DSS set for wireless (915MHz): 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 4 |
| REQ-PB-0033 | EX Drain Tray Stainless - 360mm wide: 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 5 |
| REQ-PB-0034 | Grow Scale Kit 100kg: 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 6 |
| REQ-PB-0035 | Priva Wireless Value Connector: 4 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 8 |
| REQ-PB-0036 | Drain measurement: 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 9 |
| REQ-PB-0037 | Moisture Balance Module: 2 | Unreviewed; Wording located in source text | DOC-PB-PDF · p.11; DOCX table 4 row 10 |
| REQ-PB-0044 | Base station to be within 300m of scales with clean line of sight. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |
| REQ-PB-0045 | Drain trays require base-station signal coverage or a range extender. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-PB-0078 | Customer is responsible for in field set up of drain trays. This requires locating the load cells in a suitable location and attaching a drain box and re-plumbing drain. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0081 | Unpack the units and place in position within the irrigation shed. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 7. Installation & Commissioning |
| REQ-PB-0082 | Installation and connection of stock tanks to dosing channels. This should be carried out using the supplied tank installation kits. If these are not used, an isolation valve and check valve must be installed at the stock solution tank to prevent back-flow. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 7. Installation & Commissioning |
| REQ-PB-0083 | Supply and run irrigation cables from your irrigation valves to the location of the control system with at least 1m spare cable for terminations. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 7. Installation & Commissioning |
| REQ-PB-0084 | Supply and run control cables from the equipment to the location of the control system with at least 1m spare cable for terminations. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 7. Installation & Commissioning |
| REQ-PB-0085 | Supply cables, run and terminate required electrical power into control cabinets. This should be carried out by a licensed electrician and comply to AS3000. Circuit breakers and electrical isolator should be installed for the system. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 7. Installation & Commissioning |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-PB-0023 | Thermal protection pump: Not included | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 14 |
| REQ-PB-0024 | Fertilizer tank connection kits: Included | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 15 |
| REQ-PB-0025 | Water Meter: Not included | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 16 |
| REQ-PB-0026 | Filter: Not included | Unreviewed; Wording located in source text | DOC-PB-PDF · p.9; DOCX table 2 row 17 |
| REQ-PB-0038 | Installation is not included; customer to position, plumb and power the units. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |
| REQ-PB-0039 | Commissioning includes controller software, configuration, dosing setup, testing and operator training. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |
| REQ-PB-0040 | International freight is not included; airfreight charged separately before dispatch from Holland. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |
| REQ-PB-0041 | Local freight is included. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12 |
| REQ-PB-0042 | Import duty and costs are included in the price. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12 |
| REQ-PB-0046 | Customer provides flat stable mounting platform before commissioning. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.11 |
| REQ-PB-0072 | Irrigation valves, tanks, drippers, filters, water meters, pipework and other irrigation equipment. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0073 | Stock tank and stirrers are not included in this quote. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0074 | Plumbing works | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0075 | Electrical works | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0076 | The following irrigation equipment: Filter; Water meter; Pump | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0077 | Field installation of drain trays is not included. Drawings for installation will be provided when ordered. | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0079 | Irrigation valve cable | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |
| REQ-PB-0080 | Internet connection | Unreviewed; Wording located in source text | DOC-PB-PDF · p.12; 6. Customer Responsibilities & Exclusions |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-PB-0043 | 10–12 weeks from receipt of deposit for standard options; EXW Holland. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.12 |
| REQ-PB-0047 | 0.61 Euro per $1 AUD; proposal valid 30 days while rate is within 2%. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.13 |
| REQ-PB-0049 | 40% order; 30% before dispatch Europe; 20% before dispatch Powerplants; 10% completion of commissioning. | Unreviewed; Source reread; wording requires review | DOC-PB-PDF · p.13 |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |
| mainline_flow | 90 | User confirms 90 m3/h at 5 bar. |
| mainline_pressure | 5 | User confirms 90 m3/h at 5 bar; old 4 bar wording preserved. |
| pump_scope_boundary | NutriJet-mounted bypass pump included; mainline irrigation pumps excluded | Explicit user clarification. |
| weather_station_selected | No | User confirms weather station was not intended; zero template rows remain unused. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP012146/project.json) · [Field bindings](../data/projects/OP012146/quotation-bindings.json)
