---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP010778
registry_project_id: PRJ-OP010778
registry_price_revision_id: REV-OP010778-PRICE
registry_data_file: ../data/projects/OP010778/project.json
field_bindings_file: ../data/projects/OP010778/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# MS & JK Tiwana — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP010778 |
| Customer | MS & JK Tiwana |
| Site | 1985 Solitary Islands Way, Woolgoolga, NSW 2456 |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 59,930.00 |
| Optional schedule ex GST | 0.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 59,930.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP010778-PRICE-004 | NutriFit | Base | 27,080.00 | DOC-OP010778-XLSM · 'Pricing'!A4:H4 |
| PKG-OP010778-PRICE-005 | Compass 2X | Base | 8,220.00 | DOC-OP010778-XLSM · 'Pricing'!A5:H5 |
| PKG-OP010778-PRICE-006 | Extension Frame | Base | 7,180.00 | DOC-OP010778-XLSM · 'Pricing'!A6:H6 |
| PKG-OP010778-PRICE-007 | AirFreight & Local Freight | Base | 7,800.00 | DOC-OP010778-XLSM · 'Pricing'!A7:H7 |
| PKG-OP010778-PRICE-008 | Commissioning | Base | 9,650.00 | DOC-OP010778-XLSM · 'Pricing'!A8:H8 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP010778-0001 | Priva NutriFit: Qty 1, extended price $27,080.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · PDF p.1, investment row 1 |
| REQ-OP010778-0002 | Priva Compass 2X: Qty 1, extended price $8,220.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · PDF p.1, investment row 2 |
| REQ-OP010778-0003 | NutriFit Extension Unit: Qty 1, extended price $7,180.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · PDF p.1, investment row 3 |
| REQ-OP010778-0004 | International Airfreight & Local Freight: Qty 1, extended price $7,800.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · PDF p.1, investment row 4 |
| REQ-OP010778-0005 | Commissioning: Qty 1, extended price $9,650.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · PDF p.1, investment row 5 |
| REQ-OP010778-0006 | Irrigation start strategies: 1 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0007 | Irrigation valves: 2 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0008 | Water supply control: 1 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0009 | Fertilizer dosing based on EC/pH: 1 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0010 | Dosing channel controls: 5 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0011 | Controller hardware: Priva Compass 2X Universal edition in industrial cabinet (500x500x210) | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0012 | Priva Blue ID C-Line DOR6 Relay output module: 3 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0013 | Irrigation Advanced: 1 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0014 | Water Room Advanced: 1 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.3, specification table |
| REQ-OP010778-0015 | Fertigation model: NutriFit 300 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0016 | Unit Controller: Compass 4S | Needs clarification; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0017 | EC dosing channels: 4 x 300l/h | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0018 | Acid dosing channels: 1 x 50l/h | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0019 | Pump: Grundfos CM25-3 | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0020 | Mainline flow and pressure: 11 m3/h @ 5 bar | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0021 | Mainline flow rate: 11 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0022 | Mainline pressure: 5 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0023 | Inlet diameter: 2 inch Imperial for glue | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0024 | Outlet diameter: 2 inch Imperial for glue | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0025 | Electrical power and current: 5.5kW/11.00A | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0026 | Power supply: 3-phase power supply | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0028 | EC/pH sensors: 2x EC / 2x pH Sensors | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0029 | Water meter: Inlcluded - 2 inch Sensus | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0030 | Filter: Inlcluded - 2 inch T Filter 130 micron | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.6, specification table |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP010778-0040 | All installation works are complete and compliant | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 10 |
| REQ-OP010778-0041 | Electrical power and communications are available and functional | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 11 |
| REQ-OP010778-0042 | All Client responsibilities under Section 8 have been satisfied | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 12 |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP010778-0027 | Fertiliser tank connection kits: Included | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.6, specification table |
| REQ-OP010778-0031 | Loading software onto the controller | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 1 |
| REQ-OP010778-0032 | Programming, configuration, and functional testing of the system | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 2 |
| REQ-OP010778-0033 | Setting dosing channels to operate at specified flow rates | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 3 |
| REQ-OP010778-0034 | Running and functional testing of the unit | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 4 |
| REQ-OP010778-0035 | Configuration of irrigation settings in consultation with the Client | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 5 |
| REQ-OP010778-0036 | Training of one (1) operator in normal system operation | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 6 |
| REQ-OP010778-0037 | Verification of installation works performed by the Client or third parties | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 7 |
| REQ-OP010778-0038 | Rectification of installation defects | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 8 |
| REQ-OP010778-0039 | Ongoing operational optimisation or agronomic advice | Unreviewed; Wording located in source text | DOC-OP010778-PDF · p.7, responsibilities / commissioning bullet 9 |
| REQ-OP010778-0044 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.7, installation |
| REQ-OP010778-0045 | Commissioning scope: Commissioning included | Needs clarification; Source reread; wording requires review | DOC-OP010778-PDF · p.7, commissioning |
| REQ-OP010778-0048 | Operator training quantity: 1 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.7, project-specific section |
| REQ-OP010778-0051 | Commissioning exclusion: Section 6.2 excludes commissioning and system integration, while section 5 includes commissioning. | Needs clarification; Source reread; wording requires review | DOC-OP010778-PDF · p.8, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP010778-0043 | Quotation exchange rate: 0.6 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, validity and exchange rate |
| REQ-OP010778-0046 | Lead time: 10–12 weeks from deposit via airfreight | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.9, project-specific section |
| REQ-OP010778-0047 | Commissioning scheduling: Additional 1 to 2 weeks following equipment delivery and installation. | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.9, project-specific section |
| REQ-OP010778-0049 | Freight allowance: Freight is an estimate and may be revised and re-quoted at shipment. | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.1, project-specific section |
| REQ-OP010778-0052 | Quote expiry: 16/05/2026 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, project-specific section |
| REQ-OP010778-0053 | 40% Upon placing order | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, payment schedule |
| REQ-OP010778-0054 | 30% Prior to shipping from overseas | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, payment schedule |
| REQ-OP010778-0055 | 20% Prior to dispatch from Powerplants | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, payment schedule |
| REQ-OP010778-0056 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.10, payment schedule |
| REQ-OP010778-0057 | GST: 5993 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.1, investment totals |
| REQ-OP010778-0058 | Total including GST: 65923 | Unreviewed; Source reread; wording requires review | DOC-OP010778-PDF · p.1, investment totals |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP010778/project.json) · [Field bindings](../data/projects/OP010778/quotation-bindings.json)
