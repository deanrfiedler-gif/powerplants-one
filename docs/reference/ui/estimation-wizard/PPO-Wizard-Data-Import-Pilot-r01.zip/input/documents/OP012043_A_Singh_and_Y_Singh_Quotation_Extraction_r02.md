---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP012043
registry_project_id: PRJ-OP012043
registry_price_revision_id: REV-OP012043-PRICE
registry_data_file: ../data/projects/OP012043/project.json
field_bindings_file: ../data/projects/OP012043/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# A Singh and Y Singh — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP012043 |
| Customer | A Singh and Y Singh |
| Site | Bundaberg, QLD 4670 (TBC) |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 42,730.00 |
| Optional schedule ex GST | 0.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 42,730.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP012043-PRICE-004 | Priva NutriOne 600 - Compact Substation | Base | 19,960.00 | DOC-OP012043-XLSM · 'Pricing'!A4:H4 |
| PKG-OP012043-PRICE-005 | Additional Software & Hardware for the Existing Compact CC | Base | 8,000.00 | DOC-OP012043-XLSM · 'Pricing'!A5:H5 |
| PKG-OP012043-PRICE-006 | Additional Dosing Channel (600l/h) for the Existing NutriOne | Base | 3,970.00 | DOC-OP012043-XLSM · 'Pricing'!A6:H6 |
| PKG-OP012043-PRICE-007 | Commissioning | Base | 7,240.00 | DOC-OP012043-XLSM · 'Pricing'!A7:H7 |
| PKG-OP012043-PRICE-008 | International Airfreight & Local Freight | Base | 3,560.00 | DOC-OP012043-XLSM · 'Pricing'!A8:H8 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012043-0001 | Priva NutriOne 600 - Compact Substation: Qty 1.0, extended price $19,960.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 3; PDF p.10 |
| REQ-OP012043-0002 | Additional Software & Hardware for the Existing Compact CC: Qty 1.0, extended price $8,000.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 4; PDF p.10 |
| REQ-OP012043-0003 | Additional Dosing Channel (600l/h) for the Existing NutriOne: Qty 4.0, extended price $3,970.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 5; PDF p.10 |
| REQ-OP012043-0004 | Commissioning: Qty 1.0, extended price $7,240.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 6; PDF p.10 |
| REQ-OP012043-0005 | International Airfreight & Local Freight: Qty 1.0, extended price $3,560.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 7; PDF p.10 |
| REQ-OP012043-0006 | Site \| Site 1 & 2 | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 1, row 1; PDF p.7 |
| REQ-OP012043-0007 | Unit \| NutriOne 600 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 2; PDF p.7 |
| REQ-OP012043-0008 | Controller \| Priva – Compact CC (Existing)* | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 3; PDF p.7 |
| REQ-OP012043-0009 | Required flow through dosing system \| 7.06 m3/hr | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 4; PDF p.7 |
| REQ-OP012043-0010 | Mainline flow rate \| 60 m3/hr | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 5; PDF p.7 |
| REQ-OP012043-0011 | Dosing ratio \| 1:100 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 6; PDF p.7 |
| REQ-OP012043-0012 | Mainline target pressure \| 5 bar | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 7; PDF p.7 |
| REQ-OP012043-0013 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 8; PDF p.7 |
| REQ-OP012043-0014 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 8; PDF p.7 |
| REQ-OP012043-0015 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 8; PDF p.7 |
| REQ-OP012043-0016 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 9; PDF p.7 |
| REQ-OP012043-0017 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 9; PDF p.7 |
| REQ-OP012043-0018 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 9; PDF p.7 |
| REQ-OP012043-0020 | EC/PH Sensor interfaces \| EC, pH & Dosing channel driver | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 11; PDF p.7 |
| REQ-OP012043-0025 | NutriOne Fertilizer dosing channel single 600l/h 50Hz (To replace the 300l/h dosing channels on the existing NutriOne for System 3) \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 2, row 2; PDF p.7 |
| REQ-OP012043-0026 | I/O module DO64 (AC)* \| 1 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 2; PDF p.8 |
| REQ-OP012043-0027 | Priva Office Direct \| 1 \| 1 \| 0 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 5; PDF p.8 |
| REQ-OP012043-0028 | Priva Office Direct \| 1 \| 1 \| 0 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 5; PDF p.8 |
| REQ-OP012043-0029 | Priva Office Direct \| 1 \| 1 \| 0 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 5; PDF p.8 |
| REQ-OP012043-0030 | Water system \| 1 \| 1 \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 6; PDF p.8 |
| REQ-OP012043-0031 | Water system \| 1 \| 1 \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 6; PDF p.8 |
| REQ-OP012043-0032 | Water system \| 1 \| 1 \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 6; PDF p.8 |
| REQ-OP012043-0033 | Water system \| 1 \| 1 \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 6; PDF p.8 |
| REQ-OP012043-0034 | Dosing channel \| 5 \| 5 \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 7; PDF p.8 |
| REQ-OP012043-0035 | Dosing channel \| 5 \| 5 \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 7; PDF p.8 |
| REQ-OP012043-0036 | Dosing channel \| 5 \| 5 \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 7; PDF p.8 |
| REQ-OP012043-0037 | Dosing channel \| 5 \| 5 \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 7; PDF p.8 |
| REQ-OP012043-0038 | Starting program \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 8; PDF p.8 |
| REQ-OP012043-0039 | Starting program \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 8; PDF p.8 |
| REQ-OP012043-0040 | Starting program \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 8; PDF p.8 |
| REQ-OP012043-0041 | Starting program \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 8; PDF p.8 |
| REQ-OP012043-0042 | Valve group \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 9; PDF p.8 |
| REQ-OP012043-0043 | Valve group \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 9; PDF p.8 |
| REQ-OP012043-0044 | Valve group \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 9; PDF p.8 |
| REQ-OP012043-0045 | Valve group \| 4 \| 2 \| 2 \| 4 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 9; PDF p.8 |
| REQ-OP012043-0046 | Irrigation valve control \| 25 \| 11 \| 34 \| 2 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 10; PDF p.8 |
| REQ-OP012043-0047 | Irrigation valve control \| 25 \| 11 \| 34 \| 2 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 10; PDF p.8 |
| REQ-OP012043-0048 | Irrigation valve control \| 25 \| 11 \| 34 \| 2 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 10; PDF p.8 |
| REQ-OP012043-0049 | Irrigation valve control \| 25 \| 11 \| 34 \| 2 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 3, row 10; PDF p.8 |
| REQ-OP012043-0083 | Dosing system count: 1 | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.7, project-specific section |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012043-0050 | Installation is not included in this quotation (positioning unit, plumbing & powering). | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 1 |
| REQ-OP012043-0051 | Irrigation valves, tanks, drippers pipework and other irrigation equipment. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 2 |
| REQ-OP012043-0052 | Stock tank and stirrers are not included in this quote. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 3 |
| REQ-OP012043-0053 | Plumbing works | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 4 |
| REQ-OP012043-0054 | Electrical works | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 5 |
| REQ-OP012043-0055 | The following irrigation equipment: | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 6 |
| REQ-OP012043-0056 | Water meter | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 8 |
| REQ-OP012043-0057 | All cables, including irrigation valve cables, power cables, and control cables (50m. control cable for the new NutriOne systems has been included). | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 10 |
| REQ-OP012043-0058 | Compact CC controller (Serial No. 85912) and all existing software must be available on site, fully operational, and in a usable condition. The existing software must be installed, licensed, and ready for use. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 11 |
| REQ-OP012043-0059 | Internet connection | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 12 |
| REQ-OP012043-0060 | Activated sim card for alarm dialler. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 13 |
| REQ-OP012043-0061 | Unpack the unit and place it in position within the irrigation shed. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 14 |
| REQ-OP012043-0062 | Installation and connection of stock tanks to dosing channels. This should be carried out using the supplied tank installation kits. If these are not used, an isolation valve and check valve must be installed at the stock solution tank to prevent back-flow. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 15 |
| REQ-OP012043-0063 | Plumb water supply to inlet and outlet of the unit . | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 16 |
| REQ-OP012043-0064 | Run and terminate required electrical power into the control cabinet. This should be carried out by a licensed electrician and comply to AS3000. Circuit breakers and electrical isolator should be installed for the system. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 17 |
| REQ-OP012043-0065 | Irrigation cables should be run from your irrigation valves to the location of the control system with at least 1m spare cable for terminations. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 18 |
| REQ-OP012043-0079 | Existing controller serial: 85912 | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.8, project-specific section |
| REQ-OP012043-0080 | Existing controller readiness: Existing Compact CC and existing software must be available on site, fully operational, installed and ready for use. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.8, project-specific section |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012043-0019 | EC & pH sensors \| Included | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 10; PDF p.7 |
| REQ-OP012043-0021 | Fertilizer and Acid Tank connection kits \| Included | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 12; PDF p.7 |
| REQ-OP012043-0022 | Irrigation Pump \| Excluded | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 13; PDF p.7 |
| REQ-OP012043-0023 | Irrigation Filter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 14; PDF p.7 |
| REQ-OP012043-0024 | Irrigation Flow meter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 1, row 15; PDF p.7 |
| REQ-OP012043-0066 | Connect the NutriOne system to the Priva control network. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 19 |
| REQ-OP012043-0067 | Replace the dossing channels on the existing unit. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 20 |
| REQ-OP012043-0068 | Program, test and configure the fertigation unit. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 21 |
| REQ-OP012043-0069 | Set dosing channels to operate at the correct flow rate. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 22 |
| REQ-OP012043-0070 | Running and testing of the unit. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 23 |
| REQ-OP012043-0071 | Irrigation settings on consultation with customer. | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 24 |
| REQ-OP012043-0072 | Training of operators | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.9, responsibilities / commissioning bullet 25 |
| REQ-OP012043-0074 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, installation |
| REQ-OP012043-0075 | Commissioning scope: Commissioning included | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, commissioning |
| REQ-OP012043-0078 | Freight scope: International air freight & local freight are included. Import duty is included in the price. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, project-specific section |
| REQ-OP012043-0081 | Additional IO placement: Existing Compact CC panel lacks space; additional IO module to be installed in an irrigation system panel by Powerplants technicians. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.8, project-specific section |
| REQ-OP012043-0082 | Included control cable: 50m control cable for the new NutriOne systems is included. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012043-0073 | Quotation exchange rate: 0.59 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.10, validity and exchange rate |
| REQ-OP012043-0076 | Lead time: 6–8 weeks from deposit | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, project-specific section |
| REQ-OP012043-0077 | Commissioning scheduling: 2–3 weeks after customer installation and cabling, depending on technician availability. | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.9, project-specific section |
| REQ-OP012043-0084 | 50% Deposit on order | Unreviewed; Wording located in source text | DOC-OP012043-PDF · p.10, payment schedule |
| REQ-OP012043-0085 | 40% Prior to dispatch from Europe | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.10, payment schedule |
| REQ-OP012043-0086 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP012043-PDF · p.10, payment schedule |
| REQ-OP012043-0087 | GST \| $4,273 | Unreviewed; Source reread; wording requires review | DOC-OP012043-DOCX · DOCX table 4, row 9; PDF p.10 |
| REQ-OP012043-0088 | Total including GST \| $47,003 | Unreviewed; Wording located in source text | DOC-OP012043-DOCX · DOCX table 4, row 10; PDF p.10 |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP012043/project.json) · [Field bindings](../data/projects/OP012043/quotation-bindings.json)
