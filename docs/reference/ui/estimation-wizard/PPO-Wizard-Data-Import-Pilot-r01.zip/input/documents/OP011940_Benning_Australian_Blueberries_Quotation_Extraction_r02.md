---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP011940
registry_project_id: PRJ-OP011940
registry_price_revision_id: REV-OP011940-PRICE
registry_data_file: ../data/projects/OP011940/project.json
field_bindings_file: ../data/projects/OP011940/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# Benning Australian Blueberries — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP011940 |
| Customer | Benning Australian Blueberries |
| Site | 10 Bosworth Road, Woolgoolga, NSW 2456 |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 35,630.00 |
| Optional schedule ex GST | 0.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 35,630.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP011940-PRICE-004 | NutriOne SA 300 | Base | 27,930.00 | DOC-OP011940-XLSM · 'Pricing'!A4:H4 |
| PKG-OP011940-PRICE-005 | Commissioning | Base | 6,120.00 | DOC-OP011940-XLSM · 'Pricing'!A5:H5 |
| PKG-OP011940-PRICE-006 | Intl Sea Freight & Local Freight | Base | 1,580.00 | DOC-OP011940-XLSM · 'Pricing'!A6:H6 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP011940-0001 | Priva NutriOne 300 w/Compass Controller Standalone Version with 3x DOR6: Qty 1, extended price $27,930.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · PDF p.2, investment row 1 |
| REQ-OP011940-0002 | Commissioning: Qty 1, extended price $6,120.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · PDF p.2, investment row 2 |
| REQ-OP011940-0003 | International Sea Freight & Local Freight: Qty 1, extended price $1,580.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · PDF p.2, investment row 3 |
| REQ-OP011940-0004 | Fertigation model: Priva NutriOne 300 (Standalone) with 3x additional Priva Blue ID C-Line DOR6 relay output modules | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0005 | System controller: Priva Compass | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0007 | Flow through dosing system: 7.1 m3/h | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0009 | Dosing ratio: 1:100 | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0012 | EC sensors: 2 | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0013 | pH sensors: 2 | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0014 | Included interfaces: EC / pH & Dosing Channel Driver | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0019 | Irrigation Advanced: 1 | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0020 | Water Room Advanced: 1 | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0021 | Controller cabinet: Priva Compass 2S Cabinet (500 x 500 x 210mm) | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0024 | Water Supply Control: 1 | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0025 | Fertiliser Dosing Based on EC/pH: 1 | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP011940-0027 | Unpack and position the dosing skid within the irrigation shed with adequate clearances. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 1 |
| REQ-OP011940-0028 | Install and connect stock tanks to dosing channels using the supplied kits. If alternative fittings are used, isolation and check valves must be installed at each stock tank to prevent backflow. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 2 |
| REQ-OP011940-0029 | Run and terminate required electrical power into control cabinets. This must be carried out by a licensed electrician and comply with AS3000. Circuit breakers and an electrical isolator must be installed for the system. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 3 |
| REQ-OP011940-0030 | Provide a clean water supply at required pressure. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 4 |
| REQ-OP011940-0031 | Ensure plumbing to mainline and irrigation pumps is completed before commissioning. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 5 |
| REQ-OP011940-0043 | Provide safe and accessible workspace. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 17 |
| REQ-OP011940-0044 | Supply filtered water of consistent quality within required limits. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 18 |
| REQ-OP011940-0045 | Ensure local electrical and plumbing works comply with applicable regulations and are carried out prior to commissioning. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 19 |
| REQ-OP011940-0046 | Coordinate site access, inductions, and work permits as required. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 20 |
| REQ-OP011940-0047 | Provide Safety Data Sheets (SDS) for all chemicals used on site. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 21 |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP011940-0015 | Tank connection kits: INCLUDED | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0016 | Irrigation pump: EXCLUDED | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0017 | Irrigation filter: EXCLUDED | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0018 | Irrigation flow meter: EXCLUDED | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0032 | Connect NutriOne to Priva control network. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 6 |
| REQ-OP011940-0033 | Software installation on Priva Compass. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 7 |
| REQ-OP011940-0034 | System programming, calibration, and wet testing. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 8 |
| REQ-OP011940-0035 | Verification of dosing channel flow and EC/pH response. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 9 |
| REQ-OP011940-0036 | On-site operator training and handover documentation. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 10 |
| REQ-OP011940-0037 | Commissioning covers system integration, calibration, functional testing, and operator training. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 11 |
| REQ-OP011940-0038 | All plumbing and electrical installation labour and materials. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 12 |
| REQ-OP011940-0039 | Irrigation pumps, filters, drippers, field valves, pipework, and other irrigation equipment. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 13 |
| REQ-OP011940-0040 | Any additional Priva controller hardware or software that may be required. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 14 |
| REQ-OP011940-0041 | Civil works, concrete bases, or structures. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 15 |
| REQ-OP011940-0042 | Chemical storage tanks and stirrers unless separately quoted. | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.7, responsibilities / commissioning bullet 16 |
| REQ-OP011940-0049 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.7, installation |
| REQ-OP011940-0050 | Commissioning scope: Commissioning included | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.7, commissioning |
| REQ-OP011940-0055 | Commissioning deliverables: Software configuration, testing, calibration, system setup, operator training and handover documentation. | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.8, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP011940-0048 | Quotation exchange rate: 0.61 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.9, validity and exchange rate |
| REQ-OP011940-0051 | Lead time: 22–24 weeks from deposit | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.8, project-specific section |
| REQ-OP011940-0052 | Commissioning scheduling: Additional 1 week following equipment delivery and installation. | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.8, project-specific section |
| REQ-OP011940-0053 | Freight allowance: Freight is an estimate and may be revised and re-quoted at shipment. | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.2, project-specific section |
| REQ-OP011940-0054 | Quote expiry: 25-06-2026 | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.9, project-specific section |
| REQ-OP011940-0056 | 10% Upon order confirmation | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.9, payment schedule |
| REQ-OP011940-0057 | 40% Prior to shipping from overseas supplier | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.9, payment schedule |
| REQ-OP011940-0058 | 40% Prior to dispatch from Powerplants | Unreviewed; Wording located in source text | DOC-OP011940-PDF · p.9, payment schedule |
| REQ-OP011940-0059 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.9, payment schedule |
| REQ-OP011940-0060 | GST: 3563 | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.2, investment totals |
| REQ-OP011940-0061 | Total including GST: 39193 | Unreviewed; Source reread; wording requires review | DOC-OP011940-PDF · p.2, investment totals |

## Assumptions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP011940-0006 | Mainline flow rate: 30 m3/h (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0008 | Mainline target pressure: 5 bar (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0010 | EC dosing channels: 4 x 300 L/h (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0011 | Acid dosing channels: 1 x 100 L/h (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.4, specification table |
| REQ-OP011940-0022 | Irrigation Start Strategies: 10 (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0023 | Irrigation Valves: 10 (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |
| REQ-OP011940-0026 | Dosing Channel Controls: 5 (TBC) | Needs clarification; Wording located in source text | DOC-OP011940-PDF · p.6, specification table |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP011940/project.json) · [Field bindings](../data/projects/OP011940/quotation-bindings.json)
