---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP012107
registry_project_id: PRJ-OP012107
registry_price_revision_id: REV-OP012107-PRICE
registry_data_file: ../data/projects/OP012107/project.json
field_bindings_file: ../data/projects/OP012107/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# JS & NK Ghuman — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP012107 |
| Customer | JS & NK Ghuman |
| Site | 7 Jabiru Way, Corindi |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 64,170.00 |
| Optional schedule ex GST | 7,490.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 64,170.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP012107-PRICE-004 | Priva Compass 4S | Base | 19,860.00 | DOC-OP012107-XLSM · 'Pricing'!A4:H4 |
| PKG-OP012107-PRICE-005 | NutriOne 300 | Base | 40,020.00 | DOC-OP012107-XLSM · 'Pricing'!A5:H5 |
| PKG-OP012107-PRICE-006 | AirFreight | Base | 4,290.00 | DOC-OP012107-XLSM · 'Pricing'!A6:H6 |
| PKG-OP012107-PRICE-013 | WSC11 Weather station | Option | 3,470.00 | DOC-OP012107-XLSM · 'Pricing'!A13:H13 |
| PKG-OP012107-PRICE-014 | Linear light sensor | Option | 840.00 | DOC-OP012107-XLSM · 'Pricing'!A14:H14 |
| PKG-OP012107-PRICE-015 | PC | Option | 1,690.00 | DOC-OP012107-XLSM · 'Pricing'!A15:H15 |
| PKG-OP012107-PRICE-016 | Alarm Dialler | Option | 1,160.00 | DOC-OP012107-XLSM · 'Pricing'!A16:H16 |
| PKG-OP012107-PRICE-017 | UPS | Option | 330.00 | DOC-OP012107-XLSM · 'Pricing'!A17:H17 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012107-0001 | Priva Compass 4S: Qty 1.0, extended price $19,860.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012107-DOCX · DOCX table 6, row 3; PDF p.10 |
| REQ-OP012107-0002 | NutriOne 300: Qty 2.0, extended price $40,020.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012107-DOCX · DOCX table 6, row 4; PDF p.10 |
| REQ-OP012107-0003 | AirFreight: Qty 1.0, extended price $4,290.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012107-DOCX · DOCX table 6, row 5; PDF p.10 |
| REQ-OP012107-0009 | Irrigation Start Strategies \| 10 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 3; PDF p.5 |
| REQ-OP012107-0010 | Irrigation Valves \| 20 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 4; PDF p.5 |
| REQ-OP012107-0011 | Water supply control \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 6; PDF p.5 |
| REQ-OP012107-0012 | Water supply control \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 6; PDF p.5 |
| REQ-OP012107-0013 | Flow measurement \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 7; PDF p.5 |
| REQ-OP012107-0014 | Flow measurement \| 1 \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 7; PDF p.5 |
| REQ-OP012107-0015 | EC measurement \| 2 \| 2 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 8; PDF p.5 |
| REQ-OP012107-0016 | EC measurement \| 2 \| 2 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 8; PDF p.5 |
| REQ-OP012107-0017 | pH measurement \| 2 \| 2 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 9; PDF p.5 |
| REQ-OP012107-0018 | pH measurement \| 2 \| 2 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 9; PDF p.5 |
| REQ-OP012107-0019 | Dosing Channel Controls \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 10; PDF p.5 |
| REQ-OP012107-0020 | Dosing Channel Controls \| 5 \| 5 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 1, row 10; PDF p.5 |
| REQ-OP012107-0021 | Priva Compass 4S Universal edition in industrial cabinet (600x600x210) including(16 universal inputs, 24 digital inputs, 12 analogue outputs, 16 digital outputs) Priva Blue ID C4 -MX34 controller Priva Blue ID MX34 IO module Priva Gateway including Priva Operator Priva WiFi-dongle to make the Compass a local WiFi hotspot \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 2, row 2; PDF p.5 |
| REQ-OP012107-0022 | Priva Blue ID C-Line DOR6 Relay output module \| 3 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 2, row 3; PDF p.5 |
| REQ-OP012107-0023 | Irrigation Basic \| 1 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 2, row 5; PDF p.5 |
| REQ-OP012107-0024 | Water Room Advanced \| 2 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 2, row 6; PDF p.5 |
| REQ-OP012107-0030 | Unit \| NutriOne 300 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 1; PDF p.8 |
| REQ-OP012107-0031 | Controller \| Priva – Compass | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 2; PDF p.8 |
| REQ-OP012107-0032 | Required flow through dosing system \| 3.60 m3/hr | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 3; PDF p.8 |
| REQ-OP012107-0033 | Mainline flow rate \| 30 m3/hr | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 4; PDF p.8 |
| REQ-OP012107-0034 | Dosing ratio \| 1:100 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 5; PDF p.8 |
| REQ-OP012107-0035 | Mainline target pressure \| 5 bar | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 6; PDF p.8 |
| REQ-OP012107-0036 | EC Dosing channel flow rate \| 4x 300 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 7; PDF p.8 |
| REQ-OP012107-0037 | EC Dosing channel flow rate \| 4x 300 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 7; PDF p.8 |
| REQ-OP012107-0038 | EC Dosing channel flow rate \| 4x 300 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 7; PDF p.8 |
| REQ-OP012107-0039 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 8; PDF p.8 |
| REQ-OP012107-0040 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 8; PDF p.8 |
| REQ-OP012107-0041 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 8; PDF p.8 |
| REQ-OP012107-0043 | EC/PH Sensor interfaces \| EC, pH & Dosing channel driver | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 10; PDF p.8 |
| REQ-OP012107-0069 | Dosing system count in specific system paragraph: 1 | Needs clarification; Source reread; wording requires review | DOC-OP012107-PDF · p.8, project-specific section |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012107-0048 | Installation is not included in this quotation (positioning unit, plumbing & powering). | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 1 |
| REQ-OP012107-0049 | Irrigation valves, tanks, drippers pipework and other irrigation equipment. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 2 |
| REQ-OP012107-0050 | Stock tank and stirrers are not included in this quote. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 3 |
| REQ-OP012107-0051 | Plumbing works | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 4 |
| REQ-OP012107-0052 | Electrical works | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 5 |
| REQ-OP012107-0053 | The following irrigation equipment: | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 6 |
| REQ-OP012107-0054 | Water meter | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 8 |
| REQ-OP012107-0055 | Irrigation valve cable | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 10 |
| REQ-OP012107-0056 | Unpack the unit and place in position within the irrigation shed. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 11 |
| REQ-OP012107-0057 | Installation and connection of stock tanks to dosing channels. This should be carried out using the supplied tank installation kits. If these are not used, an isolation valve and check valve must be installed at the stock solution tank to prevent back-flow. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 12 |
| REQ-OP012107-0058 | Run and terminate required electrical power into control cabinets. This should be carried out by a licensed electrician and comply to AS3000. Circuit breakers and electrical isolator should be installed for the system. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 13 |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012107-0042 | EC & pH sensors \| Included | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 9; PDF p.8 |
| REQ-OP012107-0044 | Fertilizer and Acid Tank connection kits \| Included | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 11; PDF p.8 |
| REQ-OP012107-0045 | Irrigation Pump \| Excluded | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 12; PDF p.8 |
| REQ-OP012107-0046 | Irrigation Filter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 13; PDF p.8 |
| REQ-OP012107-0047 | Irrigation Flow meter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 5, row 14; PDF p.8 |
| REQ-OP012107-0059 | Load software onto Compass | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 14 |
| REQ-OP012107-0060 | Connect NutriOne to the Priva control network. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 15 |
| REQ-OP012107-0061 | Program, test and configure Compass & Fertigation unit. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 16 |
| REQ-OP012107-0062 | Set dosing channels to operate at the correct flow rate. | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 17 |
| REQ-OP012107-0063 | Running and testing of unit | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 18 |
| REQ-OP012107-0064 | Irrigation settings on consultation | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 19 |
| REQ-OP012107-0065 | Training of operator | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.9, responsibilities / commissioning bullet 20 |
| REQ-OP012107-0067 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.9, installation |
| REQ-OP012107-0068 | Commissioning scope: Commissioning included | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.9, commissioning |
| REQ-OP012107-0071 | Freight scope: International AIR freight and duty is included in the price. Local freight is included in the price. | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.9, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012107-0066 | Quotation exchange rate: 0.61 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.10, validity and exchange rate |
| REQ-OP012107-0070 | Lead time: 6–10 weeks from deposit | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.9, project-specific section |
| REQ-OP012107-0072 | 70% Deposit on order | Unreviewed; Wording located in source text | DOC-OP012107-PDF · p.10, payment schedule |
| REQ-OP012107-0073 | 20% Prior to dispatch from Powerplants | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.10, payment schedule |
| REQ-OP012107-0074 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP012107-PDF · p.10, payment schedule |
| REQ-OP012107-0075 | GST \| $6,417 | Unreviewed; Source reread; wording requires review | DOC-OP012107-DOCX · DOCX table 6, row 7; PDF p.10 |
| REQ-OP012107-0076 | Total including GST \| $70,587 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 6, row 8; PDF p.10 |
| REQ-OP012107-0077 | GST \| $749 | Unreviewed; Source reread; wording requires review | DOC-OP012107-DOCX · DOCX table 6, row 18; PDF p.10 |
| REQ-OP012107-0078 | Total including GST \| $8,239 | Unreviewed; Wording located in source text | DOC-OP012107-DOCX · DOCX table 6, row 19; PDF p.10 |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |
| nutrione_300_quantity | NutriOne 300 | Explicit user confirmation of intended system count. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP012107/project.json) · [Field bindings](../data/projects/OP012107/quotation-bindings.json)
