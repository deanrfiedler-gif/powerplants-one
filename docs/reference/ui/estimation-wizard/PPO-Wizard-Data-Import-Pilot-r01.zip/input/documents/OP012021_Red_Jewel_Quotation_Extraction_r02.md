---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP012021
registry_project_id: PRJ-OP012021
registry_price_revision_id: REV-OP012021-PRICE
registry_data_file: ../data/projects/OP012021/project.json
field_bindings_file: ../data/projects/OP012021/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# Red Jewel — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP012021 |
| Customer | Red Jewel |
| Site | 947 Castledoyle Road, Armidale, NSW 2350 |
| Primary category | CAT-WATER (review classification) |
| Scope basis | Base scope; options separate |
| Base / main schedule ex GST | 66,470.00 |
| Optional schedule ex GST | 3,410.00 |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | 66,470.00 |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-OP012021-PRICE-004 | Priva NutriOne 600 | Base | 21,190.00 | DOC-OP012021-XLSM · 'Pricing'!A4:H4 |
| PKG-OP012021-PRICE-005 | Priva Compact CC | Base | 28,030.00 | DOC-OP012021-XLSM · 'Pricing'!A5:H5 |
| PKG-OP012021-PRICE-006 | Weather Station WSC11 | Base | 8,760.00 | DOC-OP012021-XLSM · 'Pricing'!A6:H6 |
| PKG-OP012021-PRICE-007 | Commissioning | Base | 8,490.00 | DOC-OP012021-XLSM · 'Pricing'!A7:H7 |
| PKG-OP012021-PRICE-014 | PC | Option | 1,810.00 | DOC-OP012021-XLSM · 'Pricing'!A14:H14 |
| PKG-OP012021-PRICE-015 | Alarm Dialler | Option | 1,250.00 | DOC-OP012021-XLSM · 'Pricing'!A15:H15 |
| PKG-OP012021-PRICE-016 | UPS | Option | 350.00 | DOC-OP012021-XLSM · 'Pricing'!A16:H16 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012021-0001 | Priva NutriOne 600: Qty 1.0, extended price $21,190.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 3; PDF p.13 |
| REQ-OP012021-0002 | Priva Compact CC: Qty 1.0, extended price $28,030.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 4; PDF p.13 |
| REQ-OP012021-0003 | Weather Station WSC11: Qty 1.0, extended price $8,760.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 5; PDF p.13 |
| REQ-OP012021-0004 | Commissioning: Qty 1.0, extended price $8,490.00 ex GST | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 6; PDF p.13 |
| REQ-OP012021-0008 | Wall mounted cabinet 800x800 standard with Gateway \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 2; PDF p.8 |
| REQ-OP012021-0009 | Basic materials for Process Controller (CPC2.1) \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 3; PDF p.8 |
| REQ-OP012021-0010 | I/O module DO64 (AC) \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 4; PDF p.8 |
| REQ-OP012021-0011 | Priva Office Direct \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 6; PDF p.8 |
| REQ-OP012021-0012 | Starting program \| 12 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 7; PDF p.8 |
| REQ-OP012021-0013 | Valve group \| 12 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 8; PDF p.8 |
| REQ-OP012021-0014 | Irrigation valve control \| 24 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 9; PDF p.8 |
| REQ-OP012021-0015 | Water system \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 10; PDF p.8 |
| REQ-OP012021-0016 | Dosing channel \| 5 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 1, row 11; PDF p.8 |
| REQ-OP012021-0017 | Weather Station \| Weather station WSC11 for connecting with a Compass system. Consisting of: Outside temperature sensor Outside humidity sensor Wind velocity sensor Wind direction sensor Rain detection sensor Radiation sensor 15m cable \| 1 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 2, row 2; PDF p.8 |
| REQ-OP012021-0018 | PC \| PC 24” LED or larger Monitor Windows 10 Pro OS 100/1000 Mbps Network Keyboard/Mouse \| 1 | Needs clarification; Wording located in source text | DOC-OP012021-DOCX · DOCX table 3, row 2; PDF p.8 |
| REQ-OP012021-0019 | UPS \| Uninterruptable Power Supply 1000VA. Provides power back-up and filtering to protect the Priva Compact 530 controller and PC. \| 1 | Needs clarification; Wording located in source text | DOC-OP012021-DOCX · DOCX table 3, row 3; PDF p.8 |
| REQ-OP012021-0020 | Alarm Dialler \| Alarm Dialler – SMS. This dialler will alert the grower/manager of any alarms through SMS or email to a number of pre-set mobile numbers. Note: Client to provide a standard sized SIM card on Telstra plan. \| 1 | Needs clarification; Wording located in source text | DOC-OP012021-DOCX · DOCX table 3, row 4; PDF p.8 |
| REQ-OP012021-0021 | Unit \| NutriOne 600 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 1; PDF p.11 |
| REQ-OP012021-0022 | Controller \| Priva – Compact CC | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 2; PDF p.11 |
| REQ-OP012021-0023 | Required flow through dosing system \| 7.06 m3/hr | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 3; PDF p.11 |
| REQ-OP012021-0024 | Mainline flow rate \| 45 m3/hr | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 4; PDF p.11 |
| REQ-OP012021-0025 | Dosing ratio \| 1:100 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 5; PDF p.11 |
| REQ-OP012021-0026 | Mainline target pressure \| 3 bar | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 6; PDF p.11 |
| REQ-OP012021-0028 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 8; PDF p.11 |
| REQ-OP012021-0029 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 8; PDF p.11 |
| REQ-OP012021-0030 | EC Dosing channel flow rate \| 4x 600 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 8; PDF p.11 |
| REQ-OP012021-0031 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 9; PDF p.11 |
| REQ-OP012021-0032 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 9; PDF p.11 |
| REQ-OP012021-0033 | pH Dosing channel flow rate \| 1x 100 LPH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 9; PDF p.11 |
| REQ-OP012021-0034 | Number of EC & pH sensors \| 2x EC - 2x pH | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 10; PDF p.11 |
| REQ-OP012021-0035 | EC/PH Sensor interfaces \| EC, pH & Dosing channel driver | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 11; PDF p.11 |
| REQ-OP012021-0068 | Dosing system count: 1 | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.11, project-specific section |

## Project requirements and responsibilities

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012021-0040 | Installation is not included in this quotation (positioning units, components, and sensors, plumbing, cabling & powering). | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 1 |
| REQ-OP012021-0041 | Irrigation items such as freshwater tanks, fertilizer tanks, stock tanks, level/float sensors, PVC/PE pipes, irrigation valves, mainline valves, etc. including any plumbing & connecting are not included. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 2 |
| REQ-OP012021-0042 | Electrical items such as power cables, Irrigation valve cable, etc. including any powering or connecting are not included. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 3 |
| REQ-OP012021-0043 | 50m. of control cable for NutriOne and 50m. for Compact CC are only included. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 4 |
| REQ-OP012021-0044 | Stock tank and stirrers are not included in this quote. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 5 |
| REQ-OP012021-0045 | Plumbing work | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 6 |
| REQ-OP012021-0046 | Electrical works | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 7 |
| REQ-OP012021-0047 | Mounting board (marine ply of similar) for mounting of control panel. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 8 |
| REQ-OP012021-0048 | Irrigation valve cable | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 9 |
| REQ-OP012021-0049 | Unpack the unit and sensors and place in position. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 10 |
| REQ-OP012021-0050 | Install and connect stock tanks to dosing channels. This should be carried out using the supplied tank installation kits. If these are not used, an isolation valve and check valve must be installed at the stock solution tank to prevent back-flow. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 11 |
| REQ-OP012021-0051 | Plumb water supply to inlet and outlet of the unit | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 12 |
| REQ-OP012021-0052 | Run and terminate required electrical power into control cabinets. This should be carried out by a licensed electrician and comply to AS3000. Circuit breakers and electrical isolator should be installed for the system. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 13 |
| REQ-OP012021-0053 | Run control cable to required locations | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 14 |
| REQ-OP012021-0054 | Irrigation cables should be run from your irrigation valves to the location of the control system with at least 1m spare cable for terminations. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 15 |
| REQ-OP012021-0055 | Provision of a suitable mast/pole for mounting of weather station. Access is required to the top of pole so it should be able to be lowered, or safe access must be provided for installation and maintenance of sensors. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 16 |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012021-0027 | Bypass pump \| Excluded | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 7; PDF p.11 |
| REQ-OP012021-0036 | Fertilizer and Acid Tank connection kits \| Included | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 12; PDF p.11 |
| REQ-OP012021-0037 | Irrigation Pump \| Excluded | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 13; PDF p.11 |
| REQ-OP012021-0038 | Irrigation Filter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 14; PDF p.11 |
| REQ-OP012021-0039 | Irrigation Flow meter \| Excluded | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 4, row 15; PDF p.11 |
| REQ-OP012021-0056 | Load software onto Compact CC | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 17 |
| REQ-OP012021-0057 | Program, test and configure Compact CC & NutriOne. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 18 |
| REQ-OP012021-0058 | Set dosing channels to operate at the correct flow rate. | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 19 |
| REQ-OP012021-0059 | Running and testing of unit | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 20 |
| REQ-OP012021-0060 | Irrigation settings on consultation with customer | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 21 |
| REQ-OP012021-0061 | Training of operator | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.12, responsibilities / commissioning bullet 22 |
| REQ-OP012021-0063 | Installation responsibility: Installation excluded; customer or nominated contractor | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.12, installation |
| REQ-OP012021-0064 | Commissioning scope: Commissioning included | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.12, commissioning |
| REQ-OP012021-0066 | Freight scope: International sea freight & local freight are included. Import duty is included in the price. | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.12, project-specific section |
| REQ-OP012021-0067 | Included control cable: 50m for NutriOne and 50m for Compact CC are included. | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.12, project-specific section |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-OP012021-0062 | Quotation exchange rate: 0.61 Euro per 1 AUD. | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.13, validity and exchange rate |
| REQ-OP012021-0065 | Lead time: 22–24 weeks from deposit | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.12, project-specific section |
| REQ-OP012021-0069 | 50% Deposit on order | Unreviewed; Wording located in source text | DOC-OP012021-PDF · p.13, payment schedule |
| REQ-OP012021-0070 | 40% Prior to dispatch from Powerplants | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.13, payment schedule |
| REQ-OP012021-0071 | 10% Completion of commissioning | Unreviewed; Source reread; wording requires review | DOC-OP012021-PDF · p.13, payment schedule |
| REQ-OP012021-0072 | GST \| $6,647 | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 8; PDF p.13 |
| REQ-OP012021-0073 | Total including GST \| $73,117 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 5, row 9; PDF p.13 |
| REQ-OP012021-0074 | GST \| $341 | Unreviewed; Source reread; wording requires review | DOC-OP012021-DOCX · DOCX table 5, row 17; PDF p.13 |
| REQ-OP012021-0075 | Total including GST \| $3,751 | Unreviewed; Wording located in source text | DOC-OP012021-DOCX · DOCX table 5, row 18; PDF p.13 |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP012021/project.json) · [Field bindings](../data/projects/OP012021/quotation-bindings.json)
