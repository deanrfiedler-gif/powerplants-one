---
schema: ppo.mapped-historical-quotation.r02
normalisation_revision: r02
project_id: OP012109
quotation_id: PQ004879
customer: Rumbalara Nursery
source_date: 2026-08-14
source_revision: null
acceptance_status: not_evidenced
acceptance_date: null
currency: AUD
price_authority: SRC-WB
equipment_identity_authority: SRC-USER_and_SRC-WB
selected_item_id: DAR.00085.RC7-TR5CN-M
selected_hopper_capacity_l: 650
gross_price_ex_gst: 57680.00
discount_ex_gst: -5770.00
current_workbook_total_ex_gst: 51910.00
issued_quotation_total_ex_gst: 51910.00
gst: 5191.00
total_including_gst: 57101.00
source_document: SRC-PDF
companion_workbook: OP012109_Rumbalara_Estimation_Normalised_r02.xlsm
refresh_batch_id: REFRESH-20260913-R01
registry_project_id: PRJ-OP012109
registry_price_revision_id: REV-OP012109-N095aa2c54be4-PRICE
registry_data_file: ../data/projects/OP012109/project.json
field_bindings_file: ../data/projects/OP012109/quotation-bindings.json
normalised_workbook_sha256: ee61ff9a3dbe611fcfb377054bd82071c80bdc1dbc8e5ab2015fb67e191da7d2
current_prices_approved: false
native_excel_verified: false
---

# Rumbalara Nursery — normalised quotation

Internal extraction copy for **OP012109 / PQ004879**. The selected machine is **DAR.00085.RC7-TR5CN-M with a 650 L hopper**, confirmed by the user and already present in the estimation workbook. The package includes a **3 m roller conveyor**. The workbook and formal quotation agree at **AUD 51,910 ex GST**, after discount.

The formal quotation's technical page has a superseded model heading and hopper capacity. Those statements are separated below from the corrected configuration. This Markdown is a static internal extraction copy, not a newly issued customer quotation or evidence of customer acceptance.

## 1. Quote and customer details

| Field | Value |
| --- | --- |
| Opportunity | OP012109 |
| Quotation | PQ004879 |
| Customer | Rumbalara Nursery |
| Contact | Alexander; surname not stated |
| Billing / delivery / site address | 3 Crittenden Road, Glass House Mountain, QLD 4518 (source wording) |
| Account manager | Dean Fiedler, Account Manager (QLD) |
| Source quote date | 14 August 2026 |
| Source revision | Not stated in filenames or relevant quote fields |
| Supplier | Powerplants Australia Pty Ltd, 27 Technology Circuit, Hallam, Victoria 3803 |
| Acceptance | Not evidenced; acceptance date unknown |

Sources: SRC-PDF pp.1–2,7; SRC-WORD matching sections. Both documents represent the same opportunity. Original workbook Project Info!B7/B8 contains inherited identifiers OP010561/PQ004005; the normalised copy corrects those two fields to OP012109/PQ004879 and retains the original values in its audit evidence. The inherited workbook date 2025-04-09 is retained as source metadata and does not replace the quotation date.

## 2. Price and discount

All amounts are AUD. Package selling amounts are extended amounts excluding GST. The first two rows include supply, installation and commissioning in the quotation.

| Package ID | Description | Quantity basis | Workbook sell ex GST | Issued sell ex GST | Source |
| --- | --- | --- | --- | --- | --- |
| RUM-P01 | Da Ros RC7-TR5CN-M tray filler package | 1 package | 53,810.00 | 53,810.00 | Pricing!F4 |
| RUM-P02 | 3 m roller conveyor package | 1 package | 3,870.00 | 3,870.00 | Pricing!F5 |
| RUM-D01 | Project discount | 1 project adjustment | -5,770.00 | -5,770.00 | Pricing!F6 |

| Measure | AUD |
| --- | --- |
| Gross package prices before discount | 57,680.00 |
| Customer discount | -5,770.00 |
| Net project price ex GST | 51,910.00 |
| GST at 10% | 5,191.00 |
| Total including GST | 57,101.00 |

Sources: SRC-WB Pricing!F4:F6, B7:B9; SRC-PDF p.4 section 5.1.

The original discount formula is `-(ROUNDUP(SUM(F4:F5)*10%,-1))`: 10% of $57,680 is $5,768, rounded **up in magnitude to $5,770** and then subtracted. The effective discount is therefore slightly above exactly 10%. The formula remains live in the normalised workbook. Preserve the discount as a separate signed commercial adjustment; do not distribute it across item costs or include it as a physical part.

The selected machine’s internal quoted purchase-price input is separately calculated as **EUR 17,635 × 0.8 = EUR 14,108** at A&L!U22. This supplier reduction is distinct from the customer discount. The costing exchange rate is **0.57 EUR per AUD** at Project Info!B19; the formal quotation does not state an exchange rate.

## 3. Corrected machine and costed equipment

**Canonical machine:** `DAR.00085.RC7-TR5CN-M`.

**Confirmed description:** Tray filler with vibrator, mill at the exit of the chain and cleaning brush for polystyrene or thermoformed trays, pots and packs completely inside the shuttle tray, soil hopper 650 L, peat recovery belt at the exit, peat recovery belt on the bottom.

Sources: SRC-USER and SRC-WB A&L!H22:J22. Whitespace is normalised; technical meaning is retained.

| Item ID | Description from workbook | Quantity | Source |
| --- | --- | --- | --- |
| DAR.00085.RC7-TR5CN-M | Tray filler with vibrator, mill at the exit of the chain and cleaning brush for polystyrene or thermoformed trays, pots and packs completely inside the shuttle tray, soil hopper 650 L, peat recovery belt at the exit, peat recovery belt on the bottom | 1 | A&L!H22:M22 |
| DAR.00091.SF-RC | Air blow for cleaning trays for RC7 tray filler | 1 | A&L!H23:M23 |
| DAR.01085.RC-GUID | Inlet guide kit and photocell for tray detection. Compulsory option when destacker is not installed on board the trayfiller | 1 | A&L!H24:M24 |
| DAR.01086 | Single Phase conversaion | 1 | A&L!H25:M25 |
| DAR.01087 | Opening sides onlt on RC7-TR5 | 1 | A&L!H26:M26 |
| DAR.00099.PALETTE RC7 | Surcharge for stainless steel elevator padles for RC7 tray filler | 1 | A&L!H27:M27 |
| PLU.5PI.000.20A.500.000.0 | Plug 5Pin 20A 500V Cable Mount | 1 | A&L!H28:M28 |
| POC.HAW.04E.2P5.PVC.ORA.0 | Power Cable Hard Wire 4C+E 2.5sqmm PVC Unscreened Orange | 10 | A&L!H29:M29 |
| DAR.00257.RI3 | Unloading roller belt 3 m stainless steel, including limit switch | 1 | A&L!H46:M46 |

The source descriptions include spelling errors such as “conversaion”, “onlt” and “padles”; these are retained in the row-level evidence. The 3 m conveyor is an unloading stainless steel roller belt including a limit switch. It is included in the costed project; the supplied documents do not label it as an optional accessory.

Two zero-valued contingency rows are retained as allowances, not additional equipment. The complete export contains all 25 item/allowance rows plus one signed discount record. Labour, travel, labels and other package costs remain traceable in PPO Lines.

### Conditional configuration relationship

The description of `DAR.01085.RC-GUID` says the inlet guide and tray-detection photocell are compulsory **when a destacker is not installed onboard the tray filler**. The workbook costs one kit. This is a useful **candidate wizard rule**, with evidence at A&L!J24. Confirm supplier applicability and actual destacker configuration before approving an automated rule. No separately identified destacker line does not, by itself, establish that none is present.

## 4. Quoted specifications and their status

Source: SRC-PDF p.3 sections 1.1–1.1.2 and SRC-WORD matching sections. The source page is headed **RC7-TR31N-M**, so its ratings must not automatically be treated as validated specifications for the corrected model.

| Parameter | Quoted value | Normalised treatment |
| --- | --- | --- |
| Model heading | RC7-TR31N-M | Superseded by RC7-TR5CN-M |
| Hopper | 1,200 L | Superseded by confirmed 650 L |
| Capacity | Up to 800 trays/hour | Quoted only; verify for corrected model |
| Maximum tray dimensions | 600 × 400 × 130 mm | Quoted only; verify for corrected model |
| Power | 2.7 kW | Quoted only; verify for corrected model |
| Air consumption | 100–150 L/min | Quoted only; verify for corrected model |
| Electrical supply | 230 V AC, single phase, 50 Hz | 230 V single phase also appears in customer responsibilities; frequency remains quoted |
| Weight | 630 kg | Quoted only; verify for corrected model |

The source composition lists a hopper, mill at the unloading outlet, tray transport belt, vibrator, filling head, rotating brush and excess-peat recovery belt. The corrected description above governs the selected machine. The product image and generic product copy are omitted; the original remains available for reference.

The workbook includes a single-phase conversion, but also a **5-pin 20 A 500 V plug** and **4C+E cable**. These entries are preserved as costed. Technical staff should confirm the intended connection arrangement; component voltage ratings and conductor counts alone do not establish the machine operating supply. Compressed-air pressure is not stated and is left unknown.

## 5. Installation and commissioning

**Installation and commissioning are included** for the tray filler and conveyor. Sources: SRC-PDF p.4 sections 3 and 5.1. Training duration, commissioning procedure and specific acceptance tests are not stated.

Internal workbook allowances comprise **24 hours senior installer labour, 6 hours senior installer travel, 15 hours project coordination and 5 hours engineering** across both packages (A&L!M35:M38 and M47:M49), plus travel expenses. These are estimating inputs, not separately promised customer service durations.

## 6. Customer responsibilities and exclusions

Source: SRC-PDF p.4 section 2.

| Area | Responsibility |
| --- | --- |
| Electrical works | Customer responsibility; excluded from Powerplants project scope. |
| Plumbing works | Customer responsibility; excluded from Powerplants project scope. |
| Civil works | Customer responsibility; excluded from Powerplants project scope. |
| Unloading | Purchaser responsible for unloading. |
| Site security | Purchaser responsible for security of materials on site. |
| Site insurance | Purchaser responsible for insurance of materials on site. |
| Compressed air | Customer to supply clean, dry air. |
| Electrical supply | Customer to supply single-phase 230 V AC power. |

Local freight is also excluded. Included commissioning does not remove the customer obligations above. The presence of costed plug/cable components does not establish that all customer electrical works are included; confirm the connection boundary when preparing a new quotation.

## 7. Freight and delivery

Source: SRC-PDF p.4 section 4.

| Item | Quoted basis |
| --- | --- |
| International duty | Included in price |
| International sea freight | Included in price |
| Local freight | Excluded; separate quotation can be supplied near dispatch |
| Collection alternative | Purchaser may arrange collection from Powerplants Australia |
| Availability | In stock as stated on 14 August 2026; not a current stock confirmation |
| Final delivery schedule | Confirm on placement of deposit |

The workbook allocates **$9,240 freight cost** to the tray filler: 60% of a $15,400 container schedule (A&L!H14:I14, AR22). That allocation is already included in the machine landed unit cost. Do not add the whole container schedule or the allocation again to the extracted costs. The original local-freight schedule quantity is zero; its stored $600 unit allowance is not an included charge or a current freight quotation.

## 8. Payment terms and validity

Source: SRC-PDF p.4 sections 5.2–5.3. Payment is in AUD.

| Milestone | Percentage |
| --- | --- |
| Deposit on order | 50% |
| Prior to dispatch from Powerplants | 30% |
| Completion of commissioning | 20% |

The quotation is valid for **30 days**. There is no stated quotation exchange rate or explicit exchange-rate validity band in section 5.3. Preserve the separate workbook costing rate without inserting a new commercial condition.

## 9. Acceptance and original terms

The supplied acceptance form has blank name, signature and date fields. Record **acceptance not evidenced**, rather than accepted, rejected or lost. Source: SRC-PDF p.7.

Terms and Conditions remain in SRC-PDF **pp.8–13, section 8**, and the corresponding Word document. Boilerplate, contents, marketing, images, repeated headers and the signature layout are omitted from this extraction copy. Omission does not change the original terms. No separate terms revision identifier is supplied.

## 10. Reconciliation and review items

| ID | Subject | Evidence | Treatment |
| --- | --- | --- | --- |
| RESOLVED-01 | Model and hopper | User and workbook agree DAR.00085.RC7-TR5CN-M, 650 L. PDF/Word p.3 says RC7-TR31N-M and 1,200 L. | Use corrected identity/description; retain superseded statements as evidence only. |
| CORRECTED-01 | Inherited project identifiers | Original Project Info!B7/B8 contains OP010561 / PQ004005. Filename and both quote copies identify OP012109 / PQ004879. | Normalised original Project Info cells now use OP012109 / PQ004879. Source originals and old identifier evidence are retained. |
| CONFIRMED-01 | Price and signed discount | Workbook and quote agree $53,810 + $3,870 - $5,770 = $51,910 ex GST. | Preserve the source rounded 10% discount formula and negative adjustment. Do not treat discount as inventory or subtract it from estimated costs. |
| REVIEW-01 | Remaining technical ratings | Throughput, tray size, power, air consumption, frequency and weight came from the page with the superseded model. | Retain as quoted but unverified for RC7-TR5CN-M. Confirm before using as standard equipment specifications. |
| REVIEW-02 | Electrical accessories | Quote requires 230 V single phase and workbook costs single-phase conversion, a 5-pin 20 A 500 V plug and 4C+E cable. | Keep costed parts; have technical staff confirm suitability. Component ratings alone do not establish operating voltage or phase. |
| REVIEW-03 | Conditional inlet guide | Workbook J24 says kit is compulsory when no onboard destacker is installed. | Record a candidate conditional rule; verify actual destacker configuration and supplier applicability before automating. |
| REVIEW-04 | Supply boundaries and delivery | Customer electrical/plumbing/civil works; installation included; local freight excluded; stock statement historical. | Confirm utility connections, local freight or collection and final delivery for any new quotation. Do not infer compressed-air pressure. |
| REVIEW-05 | Outcome and legacy calculations | No completed acceptance. Original workbook contains saved errors and legacy VBA referring to an absent Upload sheet. | Keep acceptance unconfirmed; native Excel recalculation and the existing macros/refresh functions need a desktop check. |
| REFERENCE-01 | Unlabelled scratch calculation | Pricing!H13:J13 contains 50,617, a $1,293 difference and $646.50 half-difference with no description. | Retain untouched in original sheet. Do not interpret as price, approved discount, commission or a second quote total. |

## 11. Source manifest and extraction use

| Source ID | Original filename / evidence | Role | Revision / date | Authority | SHA-256 |
| --- | --- | --- | --- | --- | --- |
| SRC-WB | OP012109-Rumbalara Nursery-Da Ros-Tray Filler.xlsm | Original estimation workbook | Revision not stated; original date field is inherited | Authority for prices, selected item IDs and costed quantities | 574aec2dc4cfbf64c2cb8de8c5f71bb5b750916b677100164753069be4c7d705 |
| SRC-PDF | OP012109-Rumbalara Nursery-Da Ros-Tray Filler-PQ004879.pdf | Customer-facing quotation | 14 August 2026; revision not stated | Quoted scope and commercial terms; technical model/hopper superseded by user correction | 3002443c628b9ca2dd01ad2c6c26ff484fedd10cfafcaf86a371b6d0763731ae |
| SRC-WORD | OP012109-Rumbalara Nursery-Da Ros-Tray Filler.docx | Editable quotation | 14 August 2026; revision not stated | Matches principal pricing/scope in PDF; not a separate project | ec91fb2194335b1fed865770700ba5a6f278975fbc6c13d61f94a5f2ba23e2f7 |
| SRC-USER | User confirmation in this conversation | Machine identity and description | Confirmation date not supplied | DAR.00085.RC7-TR5CN-M; corrected description includes 650 L hopper. Workbooks govern pricing. | Not a file |

Use project `OP012109`, package IDs `RUM-P01`, `RUM-P02` and `RUM-D01`, requirement IDs and source IDs to join records. Read `PPO_Lines` for item-level detail and the separate discount adjustment; read `PPO_Packages` for rounded package selling amounts. Never add package and detail totals together. For physical-product pattern analysis, exclude records classified as commercial adjustments, labour, travel and allowances.

The PPO sheets depend on the original workbook sheets. Continue estimating in the original A&L and Pricing tabs. Extend mappings when adding or inserting records. This Markdown remains a snapshot and needs review or regeneration after scope, price or commercial changes.

## Register field links and refresh status

This is an internal historical extraction document. Its customer-facing sections are reference content, not a newly issued quotation. The linked JSON holds the complete revision, package, component, specification and source IDs. Historical prices and clauses require review before reuse.

| Content | Registry field / record |
| --- | --- |
| Customer | Projects.Customer · PRJ-OP012109 |
| Pricing revision | Revisions.RevisionID · REV-OP012109-N095aa2c54be4-PRICE |
| Equipment and amounts | Packages.PackageID / SourceSellTotal · see pricing_packages |
| Component quantities and costs | Estimate_Lines.LineID / Quantity / SourceLineCost · see components |
| Specifications and responsibilities | Requirements.RequirementID / SourceEvidenceStatus · see requirements |
| Original files | Documents.DocumentID / SHA256 · see source_documents |

[Project data](../data/projects/OP012109/project.json) · [Field bindings](../data/projects/OP012109/quotation-bindings.json) · [Workbook](../workbooks/OP012109_Rumbalara_Estimation_Normalised_r02.xlsm)
