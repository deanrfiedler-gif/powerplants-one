---
schema: ppo.mapped-historical-quotation.r02
normalisation_revision: r02
project_id: OP011661
quotation_id: PQ004560
source_revision: "Second revision, confirmed by Dean Fiedler"
source_date: 2026-01-30
acceptance_status: not_accepted
acceptance_basis: "Dean Fiedler confirmation in this conversation"
acceptance_date: null
currency: AUD
price_basis: "Current workbook pricing; earlier issued quotation pricing retained separately"
quotation_pricing_status: awaiting_update
current_workbook_total_ex_gst: 163550.00
issued_quotation_total_ex_gst: 154222.50
historical_estimating_authority: SRC-WB
source_document: SRC-Q2
refresh_batch_id: REFRESH-20260913-R01
registry_project_id: PRJ-OP011661
registry_price_revision_id: REV-OP011661-Nc3df9e14787a-PRICE
registry_data_file: ../data/projects/OP011661/project.json
field_bindings_file: ../data/projects/OP011661/quotation-bindings.json
normalised_workbook_sha256: 45ad7b88a7b27ba71068e474ed01021216c1a5df610003bf427c124af9a956e7
current_prices_approved: false
native_excel_verified: false
---

# Sohi Farms normalised quotation

This is a normalised working quotation record, with current workbook pricing and the scope of the second issued quotation. **The customer has not accepted the quotation. The formal quotation awaits a pricing update.** It retains project scope, technical schedules, responsibilities and commercial terms while removing promotional material and signature-page layout. It does not replace the original issued quotation. The estimation workbook remains authoritative for current estimating prices and selected licences and I/O.

## 1. Document and customer details

| Field | Value |
| --- | --- |
| Opportunity | OP011661 |
| Quotation | PQ004560 |
| Quotation date | 30 January 2026 |
| Expiry | 28 February 2026, subject to the exchange-rate condition below |
| Customer | Sohi Farms |
| Customer account | C000000892 |
| Contact | Harman Sohi |
| Site / customer address | 290 Englands Road, North Boambee, NSW 2450, Australia |
| Customer phone | 0401 389 621 |
| Customer email | harmansohi@aqualunabeachresort.com.au |
| Account manager | Dean Fiedler |
| Supplier | Powerplants Australia Pty Ltd |
| Supplier ABN | 75 150 955 310 |

Source: SRC-Q2 pp.1,10. Earlier quotation uses Sohi Family Trust. No legal-entity equivalence beyond the user-confirmed project association is inferred.

## 2. Project requirements and selected scope

Supply and commission Compact CC controls, one NutriJet 300 Inline and one NutriJet 600 Bypass, WSC11 weather monitoring, a wireless GroScale configuration for blueberries and selected network accessories. The software schedule includes blueberry and strawberry irrigation. Installation and site preparation are customer responsibilities.

The GroScale and network accessory rows are checked on SRC-Q2 p.1 and included in its displayed subtotal. They remain identifiable as selected options rather than universal mandatory accessories. Priva One is an optional separate subscription. Site area, irrigation block areas and an independently checked hydraulic design are not stated in Q2.

## 3. Pricing — current workbook and earlier issued quotation

All amounts below are AUD excluding GST. **Current price authority: the V3 estimation workbook.** The earlier PDF prices are retained only as an issued-document reference. The NutriJet row is **one priced bundle containing two systems**; do not multiply its amount by two. Source: SRC-Q2 p.1.

| Package ID | Description | Current workbook sell AUD | Source cell |
| --- | --- | --- | --- |
| P01 | Compact CC | 35,800.00 | Pricing!F4 |
| P02 | NutriJet 300 Inline + 600 Bypass | 88,420.00 | Pricing!F5 |
| P03 | Weather Station WSC11 | 8,760.00 | Pricing!F6 |
| P04 | Main system commissioning | 9,680.00 | Pricing!F7 |
| P05 | Wireless base station | 4,000.00 | Pricing!F14 |
| P06 | Wireless GroScale for blueberries | 11,120.00 | Pricing!F15 |
| P07 | GroScale commissioning | 2,360.00 | Pricing!F16 |
| P08 | Dedicated workstation (PC) | 1,810.00 | Pricing!F23 |
| P09 | Alarm dialler | 1,250.00 | Pricing!F24 |
| P10 | UPS | 350.00 | Pricing!F25 |

**Current workbook total: AUD 163,550.00 ex GST.** Calculated GST at 10%: AUD 16,355.00; total including GST: AUD 179,905.00. These derived totals are for this normalised working record; an updated formal quotation has not yet been issued. Do not reapply the older quotation discounts to the current workbook amounts.

### Earlier issued quotation pricing — awaiting update

| Package ID | Description | Qty | Unit price | Discount | Net amount | Selection |
| --- | --- | --- | --- | --- | --- | --- |
| P01 | Compact CC | 1 | 35,730.00 | 5% | 33,943.50 | Base |
| P02 | NutriJet 300 Inline + 600 Bypass | 1 | 85,770.00 | 5% | 81,481.50 | Base |
| P03 | Weather Station WSC11 | 1 | 8,730.00 | 5% | 8,293.50 | Base |
| P04 | Main system commissioning | 1 | 9,680.00 | 0% | 9,680.00 | Base |
| P05 | Wireless base station | 1 | 4,150.00 | 5% | 3,942.50 | Selected option |
| P06 | Wireless GroScale for blueberries | 1 | 11,370.00 | 5% | 10,801.50 | Selected option |
| P07 | GroScale commissioning | 1 | 2,360.00 | 0% | 2,360.00 | Selected option |
| P08 | Dedicated workstation (PC) | 1 | 2,180.00 | 0% | 2,180.00 | Selected option |
| P09 | Alarm dialler | 1 | 1,090.00 | 0% | 1,090.00 | Selected option |
| P10 | UPS | 1 | 450.00 | 0% | 450.00 | Selected option |

| Total | AUD |
| --- | --- |
| Before discounts | 161,510.00 |
| Discount applied | 7,287.50 |
| Subtotal ex GST | 154,222.50 |
| GST 10% | 15,422.25 |
| Total including GST | 169,644.75 |

## 4. Compact CC software and hardware

Source: SRC-Q2 p.2. These are the quoted schedules; use the separate live workbook quantities for future estimating. Blank crop-specific cells are recorded as “Not stated”, not zero.

| Software | Blueberry qty | Strawberry qty | Quoted total |
| --- | --- | --- | --- |
| Priva Office Direct | 1 | Not stated | 1 |
| Water systems | 2 | Not stated | 2 |
| Dosing channels | 5 | 5 | 10 |
| Start programs | 2 | 4 | 6 |
| Valve groups | 2 | 4 | 6 |
| Irrigation valve controls | 6 | 36 | 42 |

| Hardware | Quoted qty |
| --- | --- |
| External connection board VP9552 | 2 |
| I/O module AI16/DO32 (AC) | 1 |
| I/O module DO64 (AC) | 1 |
| Basic materials for process controller CPC2.1 | 1 |

Priva Office Direct is included. General product capability descriptions have been omitted.

## 5. NutriJet specifications

Source: SRC-Q2 p.3, with system quantities from p.1.

| Parameter | NutriJet 300 | NutriJet 600 | Unit / basis |
| --- | --- | --- | --- |
| Quantity | 1 | 1 | system |
| Configuration | Inline | Bypass |  |
| Unit controller | Compact CC Substation | Compact CC Substation |  |
| EC dosing channel quantity | 4 | 4 | channel |
| EC dosing channel capacity | 300 | 600 | L/hr per channel |
| Acid dosing channel quantity | 1 | 1 | channel |
| Acid dosing channel capacity | 50 | 50 | L/hr per channel |
| Pump model | Lowara 33SV3/2A | Lowara 33SV3/2AN |  |
| Mainline flow | 28.8 | 108 | m³/h |
| Mainline pressure | 4 | 4 | bar |
| Inlet / outlet diameter | 3 | 3 | inch |
| Connection type | Solvent weld | Solvent weld |  |
| Mixing chambers | 1 | 1 | each |
| Electrical power | 5.5 | 5.5 | kW |
| Electrical current | 10.66 | 10.66 | A |
| Fertiliser tank connection kits | Included | Included |  |
| Thermal protection pump | Excluded | Excluded |  |
| Water meter | Excluded | Excluded |  |
| Filter | Excluded | Excluded |  |

Each dosing unit is stated to include two temperature-compensated EC sensors and two pH sensors. The quotation describes comparison of paired readings and irrigation pause/alarm on a discrepancy. This is retained as a quoted functional description, not independent verification of safety behaviour.

The source label “Thermal Protection Pump” is preserved; its precise component meaning is not inferred. Included pump models are not removed by the installation exclusions.

## 6. Wireless network and GroScale

Source: SRC-Q2 p.5. Network communication is 915 MHz radio; the base station connects by CAT5 to the existing controller network switch.

| Network parameter / component | Value | Unit |
| --- | --- | --- |
| Base station and aerial with 12 VDC power supply | 1 | each |
| Aerial cable | 10 | m |
| GPO maximum distance from base station | 2 | m |
| Radio frequency | 915 | MHz |
| Data settings licence | 1 | each |
| Data settings capacity | 5 | scales |
| Alarm input | 1 | each |
| Base station clear line-of-sight distance limit | 300 | m |

The base-station package includes an aerial bracket and 10 m cable. Drain trays must be within signal range; a range extender is required if coverage is insufficient and is excluded from the quoted supply.

| GroScale parameter / component | Value | Unit |
| --- | --- | --- |
| Base station 915 MHz with Ethernet output module MODBUS/TCP | 1 | each |
| Weighing platform capacity | 100 | kg |
| Weighing platforms | 2 | each |
| Sensor module 915 MHz rugged V2 | 1 | each |
| Drain water system DSS set for wireless 915 MHz | 1 | each |
| Stainless EX drain tray width | 360 | mm |
| EX drain tray | 1 | each |
| Grow Scale Kit 100 kg | 1 | each |
| Priva Wireless Value Connector | 2 | each |
| Moisture Measurement | 1 | each |
| Moisture Balance Module | 1 | each |

The base station appears in both quoted schedules. Keep these as separate source occurrences, not an instruction to supply two stations. The workbook contains one selected base station. Customer-provided flat, level mounting surfaces are required. The Moisture Balance Module uses evaporation, plant water use and substrate water content as described on p.4.

## 7. Weather station and network accessories

Source: SRC-Q2 p.6. WSC11 is included and covers outside temperature and humidity, wind speed and direction, rain detection and radiation.

| Accessory | Quoted specification |
| --- | --- |
| Workstation | Sealed PC; 11th generation i5; 8 GB RAM; 256 GB SSD; Windows 10 Pro; two 100/1000 Mbps network connections; keyboard and mouse; 24-inch or larger monitor. |
| UPS | Power backup and filtering for the Priva system, controller and PC. |
| Alarm dialler | SMS or email alarms. Customer provides a standard-size SIM on a suitable plan. |

A cabled internet connection is required for remote access and support. The source describes wireless broadband as a possible alternative where fixed internet is unavailable, subject to mobile coverage; no modem price or confirmed inclusion is stated. The quoted PC specifications differ from the workbook’s selected items; see OPEN-03.

## 8. Installation, commissioning and training

Installation is excluded. The following commissioning work is included.

### Main system commissioning

Source: SRC-Q2 p.7 section 10.

1. Load and configure all software licences on the Compact CC controller.
2. Programme blueberry and strawberry start programs, valve groups and dosing channels.
3. Programme both NutriJet units and verify dosing accuracy for all channels.
4. Configure the Moisture Balance Module using site-specific parameters agreed with the customer.
5. Commission WSC11 and verify sensor integration with Compact CC.
6. Configure irrigation scheduling for all blocks with the customer.
7. Commission the Priva Office Direct workstation and configure standard dashboards.
8. Conduct a functional test of the integrated system.
9. Train nominated site staff in normal operation.

### GroScale commissioning

Source: SRC-Q2 p.8 section 10.

1. Commission the base station and verify connectivity to all sensor modules.
2. Calibrate and zero weighing platforms with representative substrate and pots in position.
3. Commission the drain sensor and verify drain volume and EC measurement integration.
4. Configure Wireless Value Connector and verify transmission to Compact CC.
5. Verify Moisture Balance Module integration with GroScale and drain sensor inputs.
6. Confirm signal strength and wireless range at all scale locations; flag range extender requirements.

## 9. Customer responsibilities

Source: SRC-Q2 p.8 section 11. These are customer works at the customer’s cost.

| Area | Customer responsibility |
| --- | --- |
| Equipment positioning | Unpack and position Compact CC, both NutriJets, workstation, UPS and Weather Station in accordance with Powerplants drawings and specifications. |
| NutriJet plumbing | Plumb inlet and outlet mainline connections for both units, maintain 4 bar for each unit as quoted, and supply and install water meters and filters. |
| Stock tanks | Install and connect fertiliser and acid/pH stock tanks using supplied tank connection kits. If the kits are not used, fit isolation and check valves at each stock tank to prevent backflow. |
| Electrical supply | Provide 3-phase 400 V, 50 Hz supply to both NutriJets and the Compact CC cabinet, with dedicated circuit breakers and isolators. Source requires a licensed electrician and compliance with AS/NZS 3000. |
| Irrigation valve cable | Run cable from each valve to Compact CC. Leave at least 1 m spare at the panel for termination by the Powerplants technician. This specific provision conflicts with the broader cabling exclusion; see OPEN-02. |
| GroScale installation | Position platforms under representative blueberry pots at the agreed sample location. Provide a flat, level mounting surface for each platform and install operational drain trays and piping. |
| GroScale network | Run one CAT5 cable from the base station to the controller network switch and provide a GPO within 2 m of the base station. |
| Weather Station | Install WSC11 at the agreed outdoor location with an unobstructed view of the sky and prevailing wind; run signal cable to Compact CC. |
| Internet and communications | Provide stable cabled internet at Compact CC and an activated SIM for the alarm dialler before commissioning. |
| Site readiness | Fill stock tanks and make all valves, pipework, drippers and field infrastructure operational before commissioning. |

## 10. Exclusions

Source: SRC-Q2 p.9 section 11; component exclusions also appear in the NutriJet schedule.

- All installation works: positioning, plumbing, electrical connection, cabling and field integration.
- Irrigation valves, drip lines, pipework and other field irrigation infrastructure.
- Water meters and filters for both NutriJets.
- Stock tanks, stirrers and fertiliser accessories.
- All plumbing works: pipework, fittings, isolation valves and backflow prevention devices. Preserve the supplied tank connection-kit inclusion separately.
- All electrical works: supply cabling, switchboards, circuit protection and isolators.
- Concrete pads or level mounting platforms for GroScale equipment.
- Irrigation valve cabling; specific panel-end termination provision requires clarification.
- Internet connection and telecommunications services at the controller location.
- Standard-size SIM card on a suitable mobile data plan for the alarm dialler.
- GroScale range extenders if required by site conditions.

## 11. Freight and delivery

Source: SRC-Q2 p.9 section 12.

| Item | Quoted basis |
| --- | --- |
| Delivery lead time | 24–28 weeks from confirmed receipt of order. |
| Commissioning scheduling | Allow a further 2–4 weeks after delivery and installation for scheduling and completion. |
| International freight | Sea freight from the Netherlands to Australia included. |
| Import charges | Import duty and customs clearance included. |
| Local freight | Powerplants Australia to site included. |

## 12. Payment, validity and currency

Source: SRC-Q2 p.9 section 13.

| Payment milestone | Percentage |
| --- | --- |
| Upon placing order | 0% |
| Prior to manufacturing | 50% |
| Prior to dispatch from Powerplants Australia | 50% |

Quotation currency is AUD. The stated forward exchange rate is **0.60 EUR per 1 AUD**, with a ±2% tolerance. Validity runs to 28 February 2026 while that condition holds; outside the range the source reserves the right to revise pricing. The costing workbook’s exchange-rate input remains separate and is not overwritten by this quoted rate.

Priva One is optional, billed directly by Priva and outside this proposal total. The quotation gives an indicative historical cost of **EUR 25/month**, subject to confirmation with Priva. No current subscription price is inferred. Source: SRC-Q2 p.7 section 9.

## 13. Acceptance and revision record

Dean Fiedler has clarified that the customer has **not accepted** this quotation. The workbook prices have been updated, while this second formal quotation has not yet been updated. This clarification supersedes the earlier acceptance statement. Acceptance date is not applicable. Checked selections on p.1 are retained in section 3. Signature graphics and the acceptance form layout are omitted.

SRC-Q2 p.10 refers to separately provided Powerplants Terms and Conditions. The exact version of that separate document is not established. The earlier V1 Word/PDF documents remain superseded historical sources; their terms, prices and equipment quantities have not been copied into Q2.

## 14. Workbook authority and confirmed corrections

| Item | Treatment |
| --- | --- |
| Project identity | Confirmed OP011661. The original workbook filename contains OP011662; retain it as a source alias. |
| Current estimating authority | The workbook is correct and authoritative at AUD 163,550 ex GST. The older formal quotation awaits a pricing update. |
| Licences and I/O | Selected workbook quantities take precedence for future estimating. |
| Drippers | Dean confirms 2 L/hr. This is a user-confirmed project requirement, not a numeric specification extracted from Q2. |
| NutriJet quantity | One 300 Inline and one 600 Bypass in Q2 and the V3 workbook. The superseded V1 description must not be used. |

Source: Dean Fiedler’s confirmations in this conversation; SRC-WB Pricing and active costing sheets; SRC-Q2 pp.1–3.

The saved V3 workbook has base pricing of AUD 142,660, GroScale pricing of AUD 17,480 and network accessories of AUD 3,410: **AUD 163,550 ex GST combined**. Q2 totals AUD 154,222.50 ex GST, a difference of **AUD 9,327.50**. The AUD 9,327.50 difference is **explained by the user: workbook pricing has been updated and the formal quotation has not**. It is not an unresolved reconciliation error. The current total must be used when preparing the next formal quotation; older issued prices remain as provenance.

## 15. Open interpretation and reuse issues

| Issue ID | Subject | Evidence / difference | Required treatment |
| --- | --- | --- | --- |
| OPEN-01 | Repeated base station | Q2 p.5 lists a base station in both network and GroScale schedules. Pricing p.1 contains one base-station line; workbook MBM row 22 contains one. Preserve both quoted occurrences without adding their quantities together. | Check configuration boundary before deriving a reusable rule. |
| OPEN-02 | Cable termination boundary | Q2 p.8 specifies Powerplants technician termination at the panel, while p.9 excludes all installation/cabling. | Retain both statements; obtain a precise scope clarification before reusing this clause. |
| OPEN-03 | PC specifications differ | Q2 p.6 describes an 11th-generation sealed i5 PC, 8 GB RAM, 256 GB SSD and 24-inch-or-larger monitor. Workbook Control rows 70 and 76 select a Lenovo M70Q G3 i5-12400T and a 27-inch monitor. | Keep the workbook item selections for estimating and the quoted specifications as issued. |
| OPEN-04 | Separate terms version | Dean confirms the quotation has not been accepted and the workbook contains the correct updated prices. The separate Terms and Conditions version is not established. | Status is Not accepted; formal quotation pricing update required. Terms version remains unknown. |
| OPEN-05 | Original calculation dependencies | The source workbook contains existing errors, external references, an embedded MYOB database and legacy upload/report macros. | Retain the original components. Check native Excel recalculation and macro operation before adopting this pilot as a new master template. |
| OPEN-06 | Historical engineering detail | Quoted flow, pressure, sensor behaviour and capacities describe this historical quotation. | Do not promote them to universal sizing, compatibility or safety rules without technical review. |

## 16. Source manifest and extraction coverage

| Source ID | Original filename | Role | Revision | Use | SHA-256 |
| --- | --- | --- | --- | --- | --- |
| SRC-WB | OVERALL-OP011662_Sohi-V3.xlsm | Estimation workbook | V3 | Authoritative current pricing and licences / I/O | 568fa2635637af25395ccbccc28346b739343862b802ef4b96fe6bd8e6b1b9cc |
| SRC-Q2 | OP011661 Sohi Farms PQ004560.pdf | Issued quotation | Second revision, confirmed by Dean | Not accepted; pricing awaiting update to workbook | 956b2f26e5a572b1c0e409d2b17f0e49eb67decb42f7b75b0108e827c97ccc79 |
| SRC-Q1W | OP011661_Sohi Family Trust V1.docx | Earlier quotation | V1 | Superseded quotation dated 29 Jan 2026 | c654c92356f272013a38db3202f4869eab7cd470c437d5916a830c55a4575100 |
| SRC-Q1P | OP011661_Sohi Family Trust_Compact CC, NutriJet, & GroScale_PQ004560.pdf | Earlier quotation | First revision | Superseded PDF; same project and date, not used to populate Q2 | cc98cbdecd74dfafa613eb1016c7df159ef69293a27d7aa13937d9b8676ddf96 |

`SRC-USER` means the explicit confirmations supplied by Dean Fiedler in this conversation. Source filenames identify the retained originals; page references above refer to SRC-Q2.

Coverage: Q2 p.1 pricing, p.2 controls schedules, p.3 NutriJet specifications, p.4 functional context, p.5 wireless schedules, p.6 accessories, p.7 subscription and commissioning, p.8 commissioning and responsibilities, p.9 exclusions and commercial terms, and p.10 contact/acceptance metadata. Removed content consists of promotional descriptions, decorative/product images, repeated headers and footers, and acceptance-form layout. No new engineering rule or standard contractual clause is approved by this normalisation.

## Register field links and refresh status

This is an internal historical extraction document. Its customer-facing sections are reference content, not a newly issued quotation. The linked JSON holds the complete revision, package, component, specification and source IDs. Historical prices and clauses require review before reuse.

| Content | Registry field / record |
| --- | --- |
| Customer | Projects.Customer · PRJ-OP011661 |
| Pricing revision | Revisions.RevisionID · REV-OP011661-Nc3df9e14787a-PRICE |
| Equipment and amounts | Packages.PackageID / SourceSellTotal · see pricing_packages |
| Component quantities and costs | Estimate_Lines.LineID / Quantity / SourceLineCost · see components |
| Specifications and responsibilities | Requirements.RequirementID / SourceEvidenceStatus · see requirements |
| Original files | Documents.DocumentID / SHA256 · see source_documents |

[Project data](../data/projects/OP011661/project.json) · [Field bindings](../data/projects/OP011661/quotation-bindings.json) · [Workbook](../workbooks/OP011661_Sohi_Estimation_Normalised_r02.xlsm)
