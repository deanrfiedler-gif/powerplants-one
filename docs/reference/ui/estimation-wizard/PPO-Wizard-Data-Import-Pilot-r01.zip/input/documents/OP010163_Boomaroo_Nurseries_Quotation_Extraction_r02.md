---
schema: ppo.mapped-historical-quotation.r02
refresh_batch_id: REFRESH-20260913-R01
project_id: OP010163
registry_project_id: PRJ-BR
registry_price_revision_id: REV-BR-PRICE
registry_data_file: ../data/projects/OP010163/project.json
field_bindings_file: ../data/projects/OP010163/quotation-bindings.json
price_authority: workbook
current_prices_approved: false
native_excel_verified: false
---

# Boomaroo Nurseries — historical quotation extraction

Internal extraction record. Workbook pricing is the estimating reference; previous formal quotation amounts remain under their own revision IDs. This is not a newly issued customer quotation.

| Field | Value |
| --- | --- |
| Opportunity | OP010163 |
| Customer | Boomaroo Nurseries |
| Site | Lara |
| Primary category | CAT-MAJOR (review classification) |
| Scope basis | Package and stage reference only; no single total |
| Base / main schedule ex GST | Not combined / unresolved |
| Optional schedule ex GST | Not combined / unresolved |
| Separate schedule ex GST | Not combined / unresolved |
| Costed reference total ex GST | Not combined / unresolved |
| Acceptance evidence | Not established |

## Workbook pricing packages

| Package ID | Equipment / service | Scope | Extended AUD ex GST | Source |
| --- | --- | --- | --- | --- |
| PKG-BR-PRICE-004 | Logitec - B.V - Soil Handling - 1 x Hopper for Bark - 1 x Bale breaker for peat - 1 x Hopper for Vermiculite - 1 x soil mixer (feeding the seeding lines direct) - Soil conveyors to transfer the soil to seeding lines | Base | 486,000.00 | DOC-BR-XLSM · 'Pricing'!B4:H4 |
| PKG-BR-PRICE-005 | Installation and commissioning - Logitec B.V 2 x Senior installer from Powerplants | Base | 56,800.00 | DOC-BR-XLSM · 'Pricing'!B5:H5 |
| PKG-BR-PRICE-006 | Lommers - Trimmer | Base | 85,000.00 | DOC-BR-XLSM · 'Pricing'!B6:H6 |
| PKG-BR-PRICE-007 | Installation and commissioning - Lommers  2 x Senior installer from Powerplants | Base | 6,500.00 | DOC-BR-XLSM · 'Pricing'!B7:H7 |
| PKG-BR-PRICE-008 | Drenching System | Base | 59,030.00 | DOC-BR-XLSM · 'Pricing'!B8:H8 |
| PKG-BR-PRICE-009 | Flier Systems - De-Palletizer | Base | 204,400.00 | DOC-BR-XLSM · 'Pricing'!B9:H9 |
| PKG-BR-PRICE-010 | Flier Systems - Sowing Line | Base | 232,200.00 | DOC-BR-XLSM · 'Pricing'!B10:H10 |
| PKG-BR-PRICE-011 | Additional 2nd Drum | Base | 73,500.00 | DOC-BR-XLSM · 'Pricing'!B11:H11 |
| PKG-BR-PRICE-012 | Flier Systems - Bench Loader | Base | 141,200.00 | DOC-BR-XLSM · 'Pricing'!B12:H12 |
| PKG-BR-PRICE-013 | Flier Systems - Tools - 4 x Sowing drums - 4 x Pin Plates - 4 x Singulators | Base | 8,700.00 | DOC-BR-XLSM · 'Pricing'!B13:H13 |
| PKG-BR-PRICE-014 | Flier Systems - Dispatch - Bench Unloader - Stilage De-staker - Stillage Loader - Stillage Stacker | Base | 715,900.00 | DOC-BR-XLSM · 'Pricing'!B14:H14 |
| PKG-BR-PRICE-015 | Installation and commissioning 1 - Flier Equipment 2 x Techs from Flier  2 x Senior installer from Powerplants | Base | 122,700.00 | DOC-BR-XLSM · 'Pricing'!B15:H15 |
| PKG-BR-PRICE-016 | Benches - Stage 1 | Base | 6,959,560.00 | DOC-BR-XLSM · 'Pricing'!B16:H16 |
| PKG-BR-PRICE-017 | Installation and Commissioning Benches - Bays 1, 11 - 36, 38 inside | Base | 1,318,610.00 | DOC-BR-XLSM · 'Pricing'!B17:H17 |
| PKG-BR-PRICE-018 | Indigo - ISAL - Track and trace software | Base | 252,220.00 | DOC-BR-XLSM · 'Pricing'!B18:H18 |
| PKG-BR-PRICE-019 | Robur - Indoor Booms | Base | 498,190.00 | DOC-BR-XLSM · 'Pricing'!B19:H19 |
| PKG-BR-PRICE-020 | Rails and hooks | Base | 55,580.00 | DOC-BR-XLSM · 'Pricing'!B20:H20 |
| PKG-BR-PRICE-021 | Installation for Irrigation booms - Indoor | Base | 153,730.00 | DOC-BR-XLSM · 'Pricing'!B21:H21 |
| PKG-BR-PRICE-022 | Robur - Outdoor Boom | Base | 743,770.00 | DOC-BR-XLSM · 'Pricing'!B22:H22 |
| PKG-BR-PRICE-023 | Installation for Irrigation booms - Outdoor | Base | 212,550.00 | DOC-BR-XLSM · 'Pricing'!B23:H23 |
| PKG-BR-PRICE-024 | Germination Room and HVAC | Base | 345,940.00 | DOC-BR-XLSM · 'Pricing'!B24:H24 |
| PKG-BR-PRICE-025 | Fog for Germination Room | Base | 78,360.00 | DOC-BR-XLSM · 'Pricing'!B25:H25 |
| PKG-BR-PRICE-026 | Priva Control - Cool Room | Base | 57,220.00 | DOC-BR-XLSM · 'Pricing'!B26:H26 |
| PKG-BR-PRICE-027 | Fertigation and irrigation works | Base | 760,360.00 | DOC-BR-XLSM · 'Pricing'!B27:H27 |
| PKG-BR-PRICE-028 | Priva Control - Fertigation | Base | 57,070.00 | DOC-BR-XLSM · 'Pricing'!B28:H28 |
| PKG-BR-PRICE-029 | Greenhouse gable wall and hatches | Base | 621,670.00 | DOC-BR-XLSM · 'Pricing'!B29:H29 |
| PKG-BR-PRICE-030 | Seeding, germ room and dispatch area doors- Stage 1 | Base | 153,590.00 | DOC-BR-XLSM · 'Pricing'!B30:H30 |
| PKG-BR-PRICE-031 | Electrical works | Base | 373,980.00 | DOC-BR-XLSM · 'Pricing'!B31:H31 |
| PKG-BR-PRICE-032 | Project management, engineering and documentation | Base | 337,540.00 | DOC-BR-XLSM · 'Pricing'!B32:H32 |
| PKG-BR-PRICE-033 | International sea freight- Bench system | Base | 205,140.00 | DOC-BR-XLSM · 'Pricing'!B33:H33 |
| PKG-BR-PRICE-034 | International sea freight- Automation system | Base | 98,590.00 | DOC-BR-XLSM · 'Pricing'!B34:H34 |
| PKG-BR-PRICE-035 | International sea freight- Booms | Base | 88,420.00 | DOC-BR-XLSM · 'Pricing'!B35:H35 |
| PKG-BR-PRICE-036 | C.A.R Insurance | Base | 94,000.00 | DOC-BR-XLSM · 'Pricing'!B36:H36 |
| PKG-BR-PRICE-043 | Logitec - Extra hopper | Option | 154,300.00 | DOC-BR-XLSM · 'Pricing'!B43:H43 |
| PKG-BR-PRICE-044 | Option- speed doors for seeding area | Option | 46,030.00 | DOC-BR-XLSM · 'Pricing'!B44:H44 |
| PKG-BR-PRICE-045 | Seeding line vision system | Option | 47,000.00 | DOC-BR-XLSM · 'Pricing'!B45:H45 |
| PKG-BR-PRICE-046 | Camera check (After Germination, Indoor to Outdoor) | Option | 271,300.00 | DOC-BR-XLSM · 'Pricing'!B46:H46 |
| PKG-BR-PRICE-047 | Option- modified cross bars | Option | 158,070.00 | DOC-BR-XLSM · 'Pricing'!B47:H47 |
| PKG-BR-PRICE-048 | Option- CBL drive wheel instead of belt | Option | 57,560.00 | DOC-BR-XLSM · 'Pricing'!B48:H48 |
| PKG-BR-PRICE-056 | Second De-Palletizer | Base | 190,200.00 | DOC-BR-XLSM · 'Pricing'!B56:H56 |
| PKG-BR-PRICE-057 | Second Sowing line | Base | 226,800.00 | DOC-BR-XLSM · 'Pricing'!B57:H57 |
| PKG-BR-PRICE-058 | Second Bench Loader | Base | 151,000.00 | DOC-BR-XLSM · 'Pricing'!B58:H58 |
| PKG-BR-PRICE-059 | Second Flier system - Dispatch - Bench Unloader - Stilage De-staker - Stillage Loader - Stillage Stacker | Base | 710,500.00 | DOC-BR-XLSM · 'Pricing'!B59:H59 |
| PKG-BR-PRICE-060 | Installation and commissioning 2 - Flier Equipment 2 x Techs from Flier  2 x Senior installer from Powerplants | Base | 104,100.00 | DOC-BR-XLSM · 'Pricing'!B60:H60 |
| PKG-BR-PRICE-061 | Benches Stage 2 | Base | 3,488,010.00 | DOC-BR-XLSM · 'Pricing'!B61:H61 |
| PKG-BR-PRICE-062 | Express lane for benches | Base | 561,970.00 | DOC-BR-XLSM · 'Pricing'!B62:H62 |
| PKG-BR-PRICE-063 | Option- modified cross bars | Base | 86,410.00 | DOC-BR-XLSM · 'Pricing'!B63:H63 |
| PKG-BR-PRICE-064 | Option- CBL drive wheel instead of belt | Base | 40,070.00 | DOC-BR-XLSM · 'Pricing'!B64:H64 |
| PKG-BR-PRICE-065 | Installation and commissioning - Stage 2 benches | Base | 758,200.00 | DOC-BR-XLSM · 'Pricing'!B65:H65 |
| PKG-BR-PRICE-066 | Robur - Indoor Booms | Base | 311,140.00 | DOC-BR-XLSM · 'Pricing'!B66:H66 |
| PKG-BR-PRICE-067 | Rails and hooks | Base | 45,290.00 | DOC-BR-XLSM · 'Pricing'!B67:H67 |
| PKG-BR-PRICE-068 | Installation for Irrigation booms - Indoor | Base | 106,030.00 | DOC-BR-XLSM · 'Pricing'!B68:H68 |
| PKG-BR-PRICE-069 | Robur - Outdoor Boom | Base | 287,460.00 | DOC-BR-XLSM · 'Pricing'!B69:H69 |
| PKG-BR-PRICE-070 | Installation for Irrigation booms - Outdoor | Base | 87,760.00 | DOC-BR-XLSM · 'Pricing'!B70:H70 |
| PKG-BR-PRICE-071 | Germination Room and HVAC (including doors) | Base | 213,790.00 | DOC-BR-XLSM · 'Pricing'!B71:H71 |
| PKG-BR-PRICE-072 | Fog for Germination Room | Base | 29,200.00 | DOC-BR-XLSM · 'Pricing'!B72:H72 |
| PKG-BR-PRICE-073 | Priva Control - Cool Room | Base | 25,220.00 | DOC-BR-XLSM · 'Pricing'!B73:H73 |
| PKG-BR-PRICE-074 | Fertigation and irrigation works | Base | 216,310.00 | DOC-BR-XLSM · 'Pricing'!B74:H74 |
| PKG-BR-PRICE-075 | Greenhouse gable wall and hatches | Base | 460,960.00 | DOC-BR-XLSM · 'Pricing'!B75:H75 |
| PKG-BR-PRICE-076 | Electrical works | Base | 190,100.00 | DOC-BR-XLSM · 'Pricing'!B76:H76 |
| PKG-BR-PRICE-077 | Project management, engineering and documentation | Base | 235,710.00 | DOC-BR-XLSM · 'Pricing'!B77:H77 |
| PKG-BR-PRICE-078 | International sea freight- Bench system | Base | 153,080.00 | DOC-BR-XLSM · 'Pricing'!B78:H78 |
| PKG-BR-PRICE-079 | International sea freight- Automation system | Base | 44,210.00 | DOC-BR-XLSM · 'Pricing'!B79:H79 |
| PKG-BR-PRICE-080 | International sea freight- Booms | Base | 44,210.00 | DOC-BR-XLSM · 'Pricing'!B80:H80 |
| PKG-BR-PRICE-081 | C.A.R Insurance | Base | 53,000.00 | DOC-BR-XLSM · 'Pricing'!B81:H81 |
| PKG-BR-PRICE-088 | Seeding line vision system | Option | 47,000.00 | DOC-BR-XLSM · 'Pricing'!B88:H88 |
| PKG-BR-PRICE-089 | Additional 2nd Drum | Option | 73,500.00 | DOC-BR-XLSM · 'Pricing'!B89:H89 |
| PKG-BR-PRICE-090 | Work area quick lift doors | Option | 76,720.00 | DOC-BR-XLSM · 'Pricing'!B90:H90 |

## Equipment details and specifications

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-BR-0054 | Now keeps 4 x 3 trays on the bench at a time to ensure trays are placed in the correct position to allow for pick-up of 12 trays at dispatch. | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 4 |
| REQ-BR-0055 | Now capable of collecting stacks of stiilages14 high for more efficient transport. | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 5 |
| REQ-BR-0057 | Added in dispatch area quick lift doors (x3) and includes germ room doors (x4) | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 8 |
| REQ-BR-0065 | Now keeps 4 x 3 trays on the bench at a time to ensure trays are placed in the correct position to allow for pick-up of 12 trays at dispatch. | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 20 |
| REQ-BR-0067 | Updated pricing to centre feed booms (previously end fed) | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 25 |

## Inclusions and exclusions

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-BR-0056 | Moved doors from germ room pricing into other section | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 7 |
| REQ-BR-0058 | Split out and consolidated from other area | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 9 |
| REQ-BR-0066 | Inclusion of 2nd Dosatron on outdoor booms (previously in options) | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 23 |
| REQ-BR-0068 | Split out and consolidated from other area | Unreviewed; Wording located in source text | DOC-BR-PDF · pp.1–2; DOCX table 1 row 26 |

## Freight, delivery, payment and commercial evidence

| Fact ID | Extracted wording / value | Evidence / review | Source |
| --- | --- | --- | --- |
| REQ-BR-0070 | 0.56 Euro per $1 AUD. | Unreviewed; Wording located in source text | DOC-BR-PDF · p.7 |
| REQ-BR-0071 | Terms and conditions to be agreed. | Unreviewed; Wording located in source text | DOC-BR-PDF · p.7 |

## Confirmed corrections and reuse limits

| Parameter | Confirmed value / instruction | Basis |
| --- | --- | --- |
| pricing_authority | Estimate workbooks | User confirms that workbook pricing takes precedence for future estimating reference. Preserve quotation prices as issued. This does not approve outdated supplier rates or repair source formula errors. |
| wizard_use | Package reference only; estimator-led large project | User permits generalisation for now due to many revisions. Do not use total-project sizing, price reconciliation or generic codes as an approved configuration. |

Terms and responsibilities above are historical evidence. Any general clause remains a suggestion requiring review. Marketing, the original table of contents, signatures and general terms are not required to populate these fields.

[Complete project data and source IDs](../data/projects/OP010163/project.json) · [Field bindings](../data/projects/OP010163/quotation-bindings.json)
