#!/usr/bin/env python3
"""PPO historical staging import r01. Python 3.10+, standard library only.

This reads refreshed JSON exports, not Excel formulas or a live SharePoint library.
It never writes to a source workbook or issues a quotation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sqlite3
import sys
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

VERSION = 'ppo.staging-import.r01'
TRANSIENT = {'refresh_batch_id', 'RefreshBatchID', 'LastReextractedAt'}
DATE_FIELDS = {'RevisionDate', 'PriceDate', 'ModifiedAt', 'ExtractedAt', 'ReviewedOn',
               'ConfirmedOn', 'ResolvedOn', 'ApprovedOn', 'ValidFrom', 'ValidTo'}


class ImportProblem(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ImportProblem(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def unique_pairs(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f'Duplicate JSON object key: {key}')
        out[key] = value
    return out


def parse(text):
    def bad_constant(value):
        raise ImportProblem(f'Non-finite JSON number: {value}')
    return json.loads(text, object_pairs_hook=unique_pairs, parse_constant=bad_constant)


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def money(value):
    if value is None:
        return None
    require(isinstance(value, (int, float)) and not isinstance(value, bool), 'Amount must be a number or null')
    require(math.isfinite(value), 'Amount is not finite')
    return str(Decimal(str(value)))


def convert_dates(value, path='$', conversions=None):
    """Retain source serial in audit; convert named register dates only, never arbitrary numbers."""
    if conversions is None:
        conversions = []
    if isinstance(value, list):
        return [convert_dates(v, f'{path}[{i}]', conversions) for i, v in enumerate(value)]
    if not isinstance(value, dict):
        return value
    out = {}
    for k, v in value.items():
        if k in DATE_FIELDS and isinstance(v, (int, float)) and not isinstance(v, bool):
            require(math.isfinite(v) and 0 <= v < 2958466, f'Invalid Excel date: {path}.{k}')
            require(int(v) != 60, f'Fictitious Excel 1900 leap day needs review: {path}.{k}')
            base = datetime(1899, 12, 31) if v < 60 else datetime(1899, 12, 30)
            date = base + timedelta(days=v)
            converted = date.date().isoformat() if date.time() == datetime.min.time() else date.isoformat()
            out[k] = converted
            conversions.append({'path': f'{path}.{k}', 'excel_serial': v, 'iso_value': converted,
                                'timezone': 'unspecified in source'})
        else:
            out[k] = convert_dates(v, f'{path}.{k}', conversions)
    return out


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items() if k not in TRANSIENT}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def indexed(rows, key, label):
    result = {}
    for row in rows:
        rid = row.get(key)
        require(isinstance(rid, str) and rid.strip(), f'Missing ID in {label}')
        require(rid not in result, f'Duplicate ID {rid} in {label}')
        result[rid] = row
    return result


class Source:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.manifest = parse((self.root / 'FINAL_MANIFEST.json').read_text(encoding='utf-8'))
        require(self.manifest.get('complete') is True, 'Source delivery is not marked complete')
        self.files = indexed(self.manifest['files'], 'path', 'manifest')
        self.checked = {}

    def text(self, rel):
        path = (self.root / rel).resolve()
        require(not Path(rel).is_absolute() and path.is_relative_to(self.root), f'Unsafe source path: {rel}')
        require(rel in self.files, f'File is not in source manifest: {rel}')
        raw = path.read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        require(actual == self.files[rel]['sha256'], f'Source hash mismatch: {rel}')
        require(len(raw) == self.files[rel]['size_bytes'], f'Source size mismatch: {rel}')
        self.checked[rel] = actual
        return raw.decode('utf-8-sig')

    def json(self, rel):
        return parse(self.text(rel))


def validate_project(p, entry, globals_, classification, bindings):
    op = p['opportunity_ref']
    pid = p['project']['ProjectID']
    require(p['schema'] == 'ppo.historical-project.r02', f'{op}: unsupported project schema')
    require(op == entry['opportunity_ref'] and pid == entry['project_id'], f'{op}: catalog identity mismatch')
    require(p['project'].get('CanonicalProjectID', pid) == pid, f'{op}: alias cannot be a separate project')
    require(p['reference_revision_id'] == entry['reference_revision_id'] == p['project']['ReferencePriceRevisionID'],
            f'{op}: selected revision mismatch')
    require(p['currency'] == 'AUD' and p['tax_basis'] == 'ex GST', f'{op}: unexpected pricing basis')
    require(p['price_authority'] == 'workbook', f'{op}: unknown pricing authority')
    require(p['automatic_estimate_generation_enabled'] is False, f'{op}: automatic generation is unsupported')
    require(not p['approved_configuration_rules'] and not p['approved_clause_selections'],
            f'{op}: approved rules require a separate approval workflow')
    require(bindings['schema'] == 'ppo.quotation-bindings.r02' and bindings['project_id'] == pid
            and bindings['revision_id'] == p['reference_revision_id'], f'{op}: quotation binding mismatch')
    category_ids = {c['id'] for c in classification['quote_categories']}
    discipline_ids = {c['id'] for c in classification['disciplines']}
    families = {c['id']: c for c in classification['families']}
    require(p['project']['PrimaryCategoryID'] in category_ids, f'{op}: unknown quote category')
    hist = p['historical_records']
    records = {
        'Project': {pid: p['project']},
        'Revision': indexed(p['related_revisions'], 'RevisionID', op + ' revisions'),
        'Document': indexed(p['source_documents'], 'DocumentID', op + ' documents'),
        'Package': indexed(hist['packages'], 'PackageID', op + ' packages'),
        'Line': indexed(hist['estimate_lines'], 'LineID', op + ' lines'),
        'Requirement': indexed(hist['requirements'], 'RequirementID', op + ' requirements'),
        'Relationship': indexed(hist['relationships'], 'LinkID', op + ' relationships'),
        'Decision': indexed(p['user_decisions'], 'DecisionID', op + ' decisions'),
        'Review': indexed(p['review_items'], 'ExceptionID', op + ' review items'),
        'Rule': indexed(globals_['rules'], 'RuleID', 'rules'),
        'Clause': indexed(globals_['clauses'], 'ClauseID', 'clauses'),
        'Condition': indexed(globals_['conditions'], 'ConditionID', 'conditions'),
    }
    links = []

    def link(kind, rid, role, target_kind, target):
        if target is None or target == '':
            return
        require(target_kind in records and target in records[target_kind],
                f'{op}: {kind} {rid} has unresolved {role}: {target_kind} {target}')
        links.append((kind, rid, role, target_kind, target))

    link('Project', pid, 'reference_revision', 'Revision', p['reference_revision_id'])
    fk = {'Revision': {'ProjectID': 'Project', 'SupersedesRevisionID': 'Revision'},
          'Document': {'ProjectID': 'Project', 'RevisionID': 'Revision'},
          'Package': {'RevisionID': 'Revision', 'SourceDocumentID': 'Document'},
          'Line': {'PackageID': 'Package', 'SourceDocumentID': 'Document'},
          'Requirement': {'RevisionID': 'Revision', 'PackageID': 'Package', 'SourceDocumentID': 'Document'},
          'Condition': {'RuleID': 'Rule', 'ClauseID': 'Clause'}}
    for kind, fields in fk.items():
        for rid, row in records[kind].items():
            for field, target_kind in fields.items():
                # Original Sohi workbook revision is retained under its known alias.
                target = row.get(field)
                if target_kind == 'Project' and target in globals_['aliases']:
                    target = globals_['aliases'][target]
                link(kind, rid, field, target_kind, target)
    for rid, row in records['Relationship'].items():
        for end in ('From', 'To'):
            link('Relationship', rid, end, row[end + 'Type'], row[end + 'ID'])
        link('Relationship', rid, 'SourceDocumentID', 'Document', row.get('SourceDocumentID'))
    for kind, key, rows in [('Package', 'id', p['pricing_packages']), ('Line', 'LineID', p['components']),
                            ('Requirement', 'RequirementID', p['requirements'])]:
        selected = indexed(rows, key, op + ' selected ' + kind)
        for rid, row in selected.items():
            require(rid in records[kind], f'{op}: selected {kind} {rid} missing from history')
            if kind in ('Line', 'Requirement'):
                for field, target_kind in fk[kind].items():
                    target = row.get(field)
                    require(not target or target in records[target_kind], f'{op}: selected {kind} has missing {field}')
                    require(target == records[kind][rid].get(field), f'{op}: selected {kind} changed its {field} without a new linked record')
            if kind == 'Package':
                require(row['revision_id'] == p['reference_revision_id'], f'{op}: mixed pricing revisions')
                require(row['source_document_id'] in records['Document'], f'{op}: package source missing')
                require(row['source_document_id'] == records[kind][rid]['SourceDocumentID'], f'{op}: package source differs from history')
                require(row['price_semantics'] == 'extended package amount', f'{op}: unsupported amount semantics')
                require(row['current_price_approved'] is False, f'{op}: historical price marked current')
                if row.get('discipline_id'):
                    require(row['discipline_id'] in discipline_ids, f'{op}: unknown discipline')
                if row.get('equipment_family_id'):
                    require(row['equipment_family_id'] in families, f'{op}: unknown equipment family')
                    require(families[row['equipment_family_id']]['discipline_id'] == row['discipline_id'],
                            f'{op}: family and discipline disagree')
                a, b = row.get('historical_extended_sell_ex_gst'), records[kind][rid].get('SourceSellTotal')
                require((a is None and b is None) or (a is not None and b is not None and
                        abs(Decimal(money(a)) - Decimal(money(b))) < Decimal('0.01')),
                        f'{op}: selected package amount disagrees with its historical record: {rid}')
    summary = p['summary']
    # Never invent an aggregate for complex stage data or unconfirmed schedules.
    if p['project']['PrimaryCategoryID'] != 'CAT-MAJOR':
        for scope, field in [('Base', 'BaseExGST'), ('Option', 'OptionsExGST')]:
            rows = [x for x in p['pricing_packages'] if x['scope'] == scope and
                    x.get('pricing_section_id') != 'RDB-WIRELESS']
            if summary.get(field) is not None:
                require(all(x['historical_extended_sell_ex_gst'] is not None for x in rows),
                        f'{op}: unknown price inside known {field}')
                amount = sum((Decimal(money(x['historical_extended_sell_ex_gst'])) for x in rows), Decimal(0))
                require(abs(amount - Decimal(money(summary[field]))) < Decimal('0.01'),
                        f'{op}: {field} does not reconcile to selected packages')
    if op == 'OP012139':
        require(summary['CostedReferenceExGST'] is None, 'RDB combined selection must remain unresolved')
    if p['project']['PrimaryCategoryID'] == 'CAT-MAJOR':
        require(summary['CostedReferenceExGST'] is None, 'Major-project aggregate requires a separate supported model')
    return records, links


def prepare(root):
    source = Source(root)
    catalog = source.json('data/catalog.json')
    require(catalog['schema'] == 'ppo.historical-catalog.r02', 'Unsupported catalog')
    require(catalog['automatic_estimate_generation_enabled'] is False, 'Unexpected automatic generation flag')
    entries = indexed(catalog['projects'], 'project_id', 'catalog')
    require(len(entries) == catalog['project_count'], 'Catalog project count mismatch')
    indexed(catalog['projects'], 'opportunity_ref', 'opportunities')
    register = source.json('data/register-records.json')
    review_queue = source.json('data/review-queue.json')
    require(all(r['OpportunityRef'] in {e['opportunity_ref'] for e in catalog['projects']}
                for r in review_queue), 'Review queue references an unknown opportunity')
    classification = source.json('data/classification.json')
    globals_ = {'rules': register['Wizard_Rules'], 'clauses': register['Standard_Clauses'],
                'conditions': register['Clause_Conditions'], 'aliases': {}, 'alias_records': [],
                'classification': classification}
    for row in register['Projects']:
        pid, canonical_id = row['ProjectID'], row.get('CanonicalProjectID', row['ProjectID'])
        if pid != canonical_id:
            require(canonical_id in entries, f'Alias target missing: {pid}')
            globals_['aliases'][pid] = canonical_id
            globals_['alias_records'].append(row)
    date_log = []
    globals_ = convert_dates(globals_, '$.shared', date_log)
    global_hash = digest(stable(globals_))
    items = []
    for entry in catalog['projects']:
        raw = source.json(entry['data_path'])
        bindings_path = str(Path(entry['data_path']).with_name('quotation-bindings.json')).replace('\\', '/')
        bindings = source.json(bindings_path)
        markdown = source.text(entry['markdown_path'])
        dates = []
        p = convert_dates(raw, '$', dates)
        records, links = validate_project(p, entry, globals_, classification, bindings)
        p['review_queue'] = [r for r in review_queue if r['OpportunityRef'] == p['opportunity_ref']]
        records['ReviewTask'] = {}
        for task in p['review_queue']:
            key = task['RecordType'] + ':' + task['RecordID']
            require(key not in records['ReviewTask'], 'Duplicate review task: ' + key)
            records['ReviewTask'][key] = task
            target_kind = {'Existing exception': 'Review', 'Requirement': 'Requirement'}.get(task['RecordType'])
            require(target_kind and task['RecordID'] in records[target_kind], 'Review task target is missing: ' + key)
            links.append(('ReviewTask',key,'target',target_kind,task['RecordID']))
        identity = {'project': stable(p), 'bindings': bindings, 'shared_content_hash': global_hash,
                    'markdown_sha256': hashlib.sha256(markdown.encode()).hexdigest()}
        content_hash = digest(identity)
        items.append({'snapshot_id': 'SNP-' + content_hash, 'content_hash': content_hash,
                      'project': p, 'raw_project': raw, 'entry': entry, 'records': records,
                      'links': links, 'bindings': bindings, 'markdown': markdown, 'date_log': dates})
    bundle_hash = digest({'shared': global_hash, 'projects': sorted(x['snapshot_id'] for x in items)})
    return {'bundle_id': 'BND-' + bundle_hash, 'items': items, 'shared': globals_, 'date_log': date_log,
            'catalog': catalog, 'verified_files': source.checked, 'source_root': str(source.root)}


DDL = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS snapshots(
 snapshot_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, opportunity_ref TEXT NOT NULL,
 reference_revision_id TEXT NOT NULL, content_hash TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
 project_json TEXT NOT NULL, raw_project_json TEXT NOT NULL, bindings_json TEXT NOT NULL,
 markdown_text TEXT NOT NULL, date_conversion_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS records(
 snapshot_id TEXT NOT NULL REFERENCES snapshots, kind TEXT NOT NULL, record_id TEXT NOT NULL,
 payload_json TEXT NOT NULL, PRIMARY KEY(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS record_links(
 snapshot_id TEXT NOT NULL, owner_kind TEXT NOT NULL, owner_id TEXT NOT NULL, role TEXT NOT NULL,
 target_kind TEXT NOT NULL, target_id TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,owner_kind,owner_id,role,target_kind,target_id),
 FOREIGN KEY(snapshot_id,owner_kind,owner_id) REFERENCES records(snapshot_id,kind,record_id),
 FOREIGN KEY(snapshot_id,target_kind,target_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS package_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Package' CHECK(kind='Package'),
 package_id TEXT NOT NULL, revision_id TEXT NOT NULL, scope TEXT NOT NULL,
 sell_aud_decimal TEXT, cost_aud_decimal TEXT, section_id TEXT, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,package_id),
 FOREIGN KEY(snapshot_id,kind,package_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS component_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Line' CHECK(kind='Line'),
 line_id TEXT NOT NULL, package_id TEXT NOT NULL, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,line_id),
 FOREIGN KEY(snapshot_id,kind,line_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS requirement_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Requirement' CHECK(kind='Requirement'),
 requirement_id TEXT NOT NULL, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,requirement_id),
 FOREIGN KEY(snapshot_id,kind,requirement_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS bundles(
 bundle_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, shared_json TEXT NOT NULL, catalog_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bundle_projects(
 bundle_id TEXT NOT NULL REFERENCES bundles, project_id TEXT NOT NULL,
 snapshot_id TEXT NOT NULL REFERENCES snapshots, PRIMARY KEY(bundle_id,project_id));
CREATE TABLE IF NOT EXISTS import_receipts(
 receipt_id TEXT PRIMARY KEY, imported_at TEXT NOT NULL, bundle_id TEXT NOT NULL REFERENCES bundles,
 source_root TEXT NOT NULL, source_hashes_json TEXT NOT NULL, added_snapshots INTEGER NOT NULL,
 reused_snapshots INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS reference_selection(
 slot INTEGER PRIMARY KEY CHECK(slot=1), bundle_id TEXT NOT NULL REFERENCES bundles);
CREATE TABLE IF NOT EXISTS selection_events(
 event_id TEXT PRIMARY KEY, selected_at TEXT NOT NULL, actor TEXT NOT NULL, reason TEXT NOT NULL,
 previous_bundle_id TEXT, selected_bundle_id TEXT NOT NULL REFERENCES bundles);
CREATE VIEW IF NOT EXISTS selected_projects AS
 SELECT s.* FROM reference_selection c JOIN bundle_projects m ON m.bundle_id=c.bundle_id
 JOIN snapshots s ON s.snapshot_id=m.snapshot_id;
CREATE VIEW IF NOT EXISTS selected_packages AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN package_projection p USING(snapshot_id);
CREATE VIEW IF NOT EXISTS selected_components AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN component_projection p USING(snapshot_id);
CREATE VIEW IF NOT EXISTS selected_requirements AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN requirement_projection p USING(snapshot_id);
'''


def connect(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript(DDL)
    row = db.execute("SELECT value FROM meta WHERE key='schema'").fetchone()
    require(not row or row[0] == VERSION, 'Unsupported database schema; migration required')
    db.execute("INSERT OR IGNORE INTO meta VALUES('schema',?)", (VERSION,))
    db.commit()
    return db


def counts(db):
    return {t: db.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in
            ('bundles', 'snapshots', 'records', 'record_links', 'package_projection',
             'component_projection', 'requirement_projection', 'import_receipts', 'selection_events')}


def active(db):
    row = db.execute('SELECT bundle_id FROM reference_selection WHERE slot=1').fetchone()
    return row[0] if row else None


def import_prepared(db, prepared):
    before = counts(db)
    added = reused = 0
    bundle_id = prepared['bundle_id']
    previous = active(db)
    with db:
        for item in prepared['items']:
            sid, p = item['snapshot_id'], item['project']
            exists = db.execute('SELECT content_hash FROM snapshots WHERE snapshot_id=?', (sid,)).fetchone()
            if exists:
                require(exists[0] == item['content_hash'], 'Snapshot identity collision')
                reused += 1
                continue
            db.execute('INSERT INTO snapshots VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                       (sid,p['project']['ProjectID'],p['opportunity_ref'],p['reference_revision_id'],
                        item['content_hash'],now(),canonical(p),canonical(item['raw_project']),
                        canonical(item['bindings']),item['markdown'],canonical(item['date_log'])))
            rows = [(sid, kind, rid, canonical(row)) for kind, records_ in item['records'].items()
                    for rid, row in records_.items()]
            db.executemany('INSERT INTO records VALUES(?,?,?,?)', rows)
            db.executemany('INSERT INTO record_links VALUES(?,?,?,?,?,?)', [(sid, *link) for link in item['links']])
            # Decimal amounts are text deliberately; never use binary REAL for financial arithmetic.
            db.executemany('INSERT INTO package_projection VALUES(?,?,?,?,?,?,?,?,?)',
                [(sid,'Package',r['id'],r['revision_id'],r['scope'],money(r['historical_extended_sell_ex_gst']),
                  money(r['historical_extended_cost_ex_gst']),r.get('pricing_section_id'),canonical(r))
                 for r in p['pricing_packages']])
            db.executemany('INSERT INTO component_projection VALUES(?,?,?,?,?)',
                [(sid,'Line',r['LineID'],r['PackageID'],canonical(r)) for r in p['components']])
            db.executemany('INSERT INTO requirement_projection VALUES(?,?,?,?)',
                [(sid,'Requirement',r['RequirementID'],canonical(r)) for r in p['requirements']])
            added += 1
        db.execute('INSERT OR IGNORE INTO bundles VALUES(?,?,?,?)',
                   (bundle_id,now(),canonical(prepared['shared']),canonical(prepared['catalog'])))
        for item in prepared['items']:
            db.execute('INSERT OR IGNORE INTO bundle_projects VALUES(?,?,?)',
                       (bundle_id,item['project']['project']['ProjectID'],item['snapshot_id']))
        db.execute('INSERT INTO import_receipts VALUES(?,?,?,?,?,?,?)',
                   (str(uuid.uuid4()),now(),bundle_id,prepared['source_root'],
                    canonical(prepared['verified_files']),added,reused))
        require(not db.execute('PRAGMA foreign_key_check').fetchall(), 'Database foreign-key check failed')
    return {'schema': VERSION, 'bundle_id': bundle_id, 'added_snapshots': added,
            'reused_snapshots': reused, 'before': before, 'after': counts(db),
            'selected_bundle_before': previous, 'selected_bundle_after': active(db),
            'verified_source_files': len(prepared['verified_files']),
            'native_excel_verified': False, 'technical_approval_performed': False}


def select_bundle(db, bundle_id, actor, reason, expected):
    require(actor.strip() and reason.strip(), 'Selection needs a named actor and a reason')
    # Serialize compare-and-select; prevent a stale reviewer from overwriting a newer selection.
    db.execute('BEGIN IMMEDIATE')
    try:
        previous = active(db)
        require(previous == (None if expected == 'none' else expected), 'Reference selection changed; review again')
        require(db.execute('SELECT 1 FROM bundles WHERE bundle_id=?', (bundle_id,)).fetchone(), 'Unknown bundle')
        if previous != bundle_id:
            db.execute('INSERT INTO reference_selection VALUES(1,?) ON CONFLICT(slot) DO UPDATE SET bundle_id=excluded.bundle_id', (bundle_id,))
            db.execute('INSERT INTO selection_events VALUES(?,?,?,?,?,?)',
                       (str(uuid.uuid4()),now(),actor,reason,previous,bundle_id))
        db.commit()
    except Exception:
        db.rollback()
        raise
    return {'previous_bundle': previous, 'selected_bundle': bundle_id,
            'meaning': 'Historical reference selection only; not technical, price or quote approval'}


def bundle_items(db, bundle_id):
    require(db.execute('SELECT 1 FROM bundles WHERE bundle_id=?', (bundle_id,)).fetchone(), 'Unknown bundle')
    return db.execute('SELECT s.* FROM bundle_projects b JOIN snapshots s USING(snapshot_id) WHERE b.bundle_id=? ORDER BY s.opportunity_ref', (bundle_id,)).fetchall()


def diff_bundles(db, old, new):
    before = {r['project_id']: r for r in bundle_items(db, old)} if old else {}
    after = {r['project_id']: r for r in bundle_items(db, new)}
    changes = []
    for pid in sorted(before.keys() | after.keys()):
        a, b = before.get(pid), after.get(pid)
        if a and b and a['snapshot_id'] == b['snapshot_id']:
            continue
        item = {'project_id': pid, 'previous_snapshot': a['snapshot_id'] if a else None,
                'new_snapshot': b['snapshot_id'] if b else None, 'changes': []}
        pa = parse(a['project_json']) if a else {}
        pb = parse(b['project_json']) if b else {}
        for section in ['summary', 'project', 'pricing_packages', 'components', 'requirements',
                        'review_items', 'review_queue', 'user_decisions', 'source_documents', 'normalised_workbook']:
            if stable(pa.get(section)) != stable(pb.get(section)):
                item['changes'].append(section)
        fields = ('BaseExGST','OptionsExGST','AdditionalScheduleExGST','CostedReferenceExGST','ScopeBasis')
        item['summary_changes'] = {k: {'before': pa.get('summary',{}).get(k), 'after': pb.get('summary',{}).get(k)}
                                   for k in fields if pa.get('summary',{}).get(k) != pb.get('summary',{}).get(k)}
        price_fields = ('description','scope','historical_extended_sell_ex_gst','historical_extended_cost_ex_gst',
                        'pricing_quantity','physical_equipment_quantity','model_configuration','stage','area',
                        'pricing_section_id','export_selection')
        def pricing_signature(project):
            return sorted((canonical({k:r.get(k) for k in price_fields}) for r in project.get('pricing_packages',[])))
        item['price_or_scope_changed'] = bool(item['summary_changes']) or pricing_signature(pa) != pricing_signature(pb)
        changes.append(item)
    return {'previous_bundle': old, 'candidate_bundle': new, 'changed_projects': changes,
            'selection_updated': False}


def export_bundle(db, output, bundle_id=None):
    bundle_id = bundle_id or active(db)
    require(bundle_id, 'No historical reference is selected; select one explicitly or provide --bundle')
    row = db.execute('SELECT shared_json FROM bundles WHERE bundle_id=?', (bundle_id,)).fetchone()
    require(row, 'Unknown bundle')
    shared = parse(row[0])
    projects = []
    for row in bundle_items(db, bundle_id):
        p = parse(row['project_json'])
        projects.append({k: v for k, v in p.items() if k not in
                         {'historical_records', 'normalised_tables', 'registry_crosswalk'}} |
                        {'snapshot_id': row['snapshot_id'], 'quotation_bindings': parse(row['bindings_json']),
                         'internal_markdown_reference': row['markdown_text']})
    export = {'schema': 'ppo.wizard-reference-catalog.r01', 'bundle_id': bundle_id,
              'selected_in_database': bundle_id == active(db), 'exported_at': now(),
              'mode': 'Historical reference only', 'shared': shared, 'projects': projects,
              'automatic_estimate_generation_enabled': False,
              'policy': {'current_prices_approved': False, 'candidate_rules_executable': False,
                         'draft_clauses_approved': False, 'native_excel_verified': False,
                         'new_estimate_requires_separate_revision': True}}
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / 'wizard-reference.json', export)
    template = Path(__file__).with_name('viewer.html').read_text(encoding='utf-8')
    embedded = canonical(export).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    (output / 'PPO-Wizard-Data-Review-r01.html').write_text(template.replace('__PPO_DATA__', embedded), encoding='utf-8')
    return {'export': str(output / 'wizard-reference.json'), 'viewer': str(output / 'PPO-Wizard-Data-Review-r01.html'),
            'projects': len(projects), 'bundle_id': bundle_id}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--database', default='ppo-staging.sqlite')
    subs = ap.add_subparsers(dest='command', required=True)
    imp = subs.add_parser('import', help='Validate and stage a source delivery; never change the reference selection')
    imp.add_argument('--source', required=True)
    imp.add_argument('--receipt')
    sel = subs.add_parser('select', help='Deliberately select an imported historical reference bundle')
    sel.add_argument('--bundle', required=True)
    sel.add_argument('--actor', required=True)
    sel.add_argument('--reason', required=True)
    sel.add_argument('--expected-selection', required=True, help='Current full bundle ID, or none')
    dif = subs.add_parser('diff')
    dif.add_argument('--candidate', required=True)
    dif.add_argument('--previous')
    exp = subs.add_parser('export')
    exp.add_argument('--output', required=True)
    exp.add_argument('--bundle')
    subs.add_parser('status')
    args = ap.parse_args()
    try:
        require(args.command == 'import' or Path(args.database).is_file(), 'Database not found; import a source delivery first')
        prepared = prepare(args.source) if args.command == 'import' else None
        with connect(args.database) as db:
            if args.command == 'import':
                result = import_prepared(db, prepared)
                if args.receipt:
                    write_json(args.receipt, result)
            elif args.command == 'select':
                result = select_bundle(db,args.bundle,args.actor,args.reason,args.expected_selection)
            elif args.command == 'diff':
                result = diff_bundles(db,args.previous or active(db),args.candidate)
            elif args.command == 'export':
                result = export_bundle(db,args.output,args.bundle)
            else:
                result = {'schema': VERSION, 'counts': counts(db), 'selected_bundle': active(db),
                          'foreign_key_errors': len(db.execute('PRAGMA foreign_key_check').fetchall())}
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except (ImportProblem, OSError, sqlite3.Error, KeyError, ValueError) as exc:
        print(f'Import stopped: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
