PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS snapshots(
 snapshot_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, opportunity_ref TEXT NOT NULL,
 reference_revision_id TEXT NOT NULL, content_hash TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
 project_json TEXT NOT NULL, raw_project_json TEXT NOT NULL, bindings_json TEXT NOT NULL,
 markdown_text TEXT NOT NULL, date_conversion_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS records(
 snapshot_id TEXT NOT NULL REFERENCES snapshots, kind TEXT NOT NULL, record_id TEXT NOT NULL,
 payload_json TEXT NOT NULL, PRIMARY KEY(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS record_links(
 snapshot_id TEXT NOT NULL, owner_kind TEXT NOT NULL, owner_id TEXT NOT NULL, role TEXT NOT NULL,
 target_kind TEXT NOT NULL, target_id TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,owner_kind,owner_id,role,target_kind,target_id),
 FOREIGN KEY(snapshot_id,owner_kind,owner_id) REFERENCES records(snapshot_id,kind,record_id),
 FOREIGN KEY(snapshot_id,target_kind,target_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS package_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Package' CHECK(kind='Package'),
 package_id TEXT NOT NULL, revision_id TEXT NOT NULL, scope TEXT NOT NULL,
 sell_aud_decimal TEXT, cost_aud_decimal TEXT, section_id TEXT, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,package_id),
 FOREIGN KEY(snapshot_id,kind,package_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS component_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Line' CHECK(kind='Line'),
 line_id TEXT NOT NULL, package_id TEXT NOT NULL, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,line_id),
 FOREIGN KEY(snapshot_id,kind,line_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS requirement_projection(
 snapshot_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'Requirement' CHECK(kind='Requirement'),
 requirement_id TEXT NOT NULL, payload_json TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,requirement_id),
 FOREIGN KEY(snapshot_id,kind,requirement_id) REFERENCES records(snapshot_id,kind,record_id));
CREATE TABLE IF NOT EXISTS bundles(
 bundle_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, shared_json TEXT NOT NULL, catalog_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bundle_projects(
 bundle_id TEXT NOT NULL REFERENCES bundles, project_id TEXT NOT NULL,
 snapshot_id TEXT NOT NULL REFERENCES snapshots, PRIMARY KEY(bundle_id,project_id));
CREATE TABLE IF NOT EXISTS import_receipts(
 receipt_id TEXT PRIMARY KEY, imported_at TEXT NOT NULL, bundle_id TEXT NOT NULL REFERENCES bundles,
 source_root TEXT NOT NULL, source_hashes_json TEXT NOT NULL, added_snapshots INTEGER NOT NULL,
 reused_snapshots INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS reference_selection(
 slot INTEGER PRIMARY KEY CHECK(slot=1), bundle_id TEXT NOT NULL REFERENCES bundles);
CREATE TABLE IF NOT EXISTS selection_events(
 event_id TEXT PRIMARY KEY, selected_at TEXT NOT NULL, actor TEXT NOT NULL, reason TEXT NOT NULL,
 previous_bundle_id TEXT, selected_bundle_id TEXT NOT NULL REFERENCES bundles);
CREATE VIEW IF NOT EXISTS selected_projects AS
 SELECT s.* FROM reference_selection c JOIN bundle_projects m ON m.bundle_id=c.bundle_id
 JOIN snapshots s ON s.snapshot_id=m.snapshot_id;
CREATE VIEW IF NOT EXISTS selected_packages AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN package_projection p USING(snapshot_id);
CREATE VIEW IF NOT EXISTS selected_components AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN component_projection p USING(snapshot_id);
CREATE VIEW IF NOT EXISTS selected_requirements AS
 SELECT s.project_id,s.opportunity_ref,p.* FROM selected_projects s JOIN requirement_projection p USING(snapshot_id);
