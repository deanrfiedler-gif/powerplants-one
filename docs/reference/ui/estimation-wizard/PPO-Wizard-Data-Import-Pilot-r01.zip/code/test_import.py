#!/usr/bin/env python3
"""Meaningful import/revision safety tests; synthetic changes use disposable JSON copies."""
import copy
import hashlib
import json
import shutil
import sqlite3
import tempfile
from pathlib import Path
import ppo_import as ppo

BASE = Path(__file__).resolve().parent.parent
RESULTS = []

def check(name, condition, detail=''):
    assert condition, name + ': ' + detail
    RESULTS.append({'test':name, 'result':'PASS', 'detail':detail})

def rejects(name, call, detail=''):
    try:
        call()
    except (ppo.ImportProblem, sqlite3.IntegrityError) as exc:
        check(name, True, detail or str(exc))
    else:
        raise AssertionError('Expected rejection: ' + name)

def update_json(root, relative, mutate):
    f=root/relative
    obj=json.loads(f.read_text())
    mutate(obj)
    ppo.write_json(f,obj)
    manifest=json.loads((root/'FINAL_MANIFEST.json').read_text())
    entry=next(x for x in manifest['files'] if x['path']==relative)
    entry.update(size_bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
    ppo.write_json(root/'FINAL_MANIFEST.json',manifest)

def main():
    source=BASE/'input'
    prepared=ppo.prepare(source)
    with tempfile.TemporaryDirectory(prefix='ppo-import-test-') as td:
        td=Path(td); db=ppo.connect(td/'test.sqlite')
        first=ppo.import_prepared(db,prepared)
        check('First import stages exactly 12 projects',first['added_snapshots']==12)
        check('Import leaves reference selection unchanged',ppo.active(db) is None)
        check('Every relational link resolves',not db.execute('PRAGMA foreign_key_check').fetchall())
        check('Selected projections retain expected coverage',
              first['after']['package_projection']==140 and first['after']['component_projection']==1848
              and first['after']['requirement_projection']==992)
        check('All 86 exception and clarification tasks retained',
              db.execute("SELECT COUNT(*) FROM records WHERE kind='ReviewTask'").fetchone()[0]==86)
        check('Shared rules remain candidates and clauses remain draft',
              all(x['Status']=='Candidate' for x in prepared['shared']['rules']) and
              all(x['Status']=='Draft' for x in prepared['shared']['clauses']))
        check('OP011662 resolves to Sohi without a thirteenth project',
              prepared['shared']['aliases']['PRJ-OP011662']=='PRJ-OP011661' and
              not db.execute("SELECT 1 FROM snapshots WHERE project_id='PRJ-OP011662'").fetchone())
        ppo.select_bundle(db,prepared['bundle_id'],'Automated test','Select historical baseline','none')
        second=ppo.import_prepared(db,prepared)
        entities=['bundles','snapshots','records','record_links','package_projection','component_projection','requirement_projection']
        check('Identical repeat import creates no duplicate data',second['added_snapshots']==0 and
              all(first['after'][k]==second['after'][k] for k in entities),
              'A separate import receipt records the retry; business records are unchanged.')
        check('Retry preserves the deliberate reference selection',ppo.active(db)==prepared['bundle_id'])
        export=ppo.export_bundle(db,td/'export')
        payload=json.loads((td/'export/wizard-reference.json').read_text())
        projects={p['opportunity_ref']:p for p in payload['projects']}
        check('Sohi current historical reference and unaccepted status preserved',
              projects['OP011661']['summary']['CostedReferenceExGST']==163550 and
              projects['OP011661']['summary']['QuoteAcceptance']=='Not accepted')
        check('Bush to Bowl base and options remain separate',
              projects['OP011896']['summary']['BaseExGST']==42840 and
              projects['OP011896']['summary']['OptionsExGST']==7320 and
              projects['OP011896']['summary']['CostedReferenceExGST']==50160)
        check('RDB unconfirmed combined amount remains null',projects['OP012139']['summary']['CostedReferenceExGST'] is None)
        check('Boomaroo does not get an automatic project total',projects['OP010163']['summary']['CostedReferenceExGST'] is None)
        rum=projects['OP012109']
        check('Rumbalara historical total is preserved',rum['summary']['CostedReferenceExGST']==51910)
        check('Rumbalara old discount remains a historical adjustment',
              any(p['historical_extended_sell_ex_gst']==-5770 for p in rum['pricing_packages']))
        check('Corrected Rumbalara item is traceable',
              any('DAR.00085.RC7-TR5CN-M' in str(r) for r in rum['components']))
        check('Dates converted without claiming a source timezone',
              ppo.convert_dates({'ConfirmedOn':46277})['ConfirmedOn']=='2026-09-12' and
              ppo.convert_dates({'ReviewedOn':None})['ReviewedOn'] is None)
        rejects('Fictitious Excel 1900 leap day is not silently converted',lambda:ppo.convert_dates({'PriceDate':60}))
        check('New-estimate and automation boundaries are explicit',not payload['automatic_estimate_generation_enabled']
              and not payload['policy']['current_prices_approved'] and not payload['policy']['candidate_rules_executable'])
        # Changes below are synthetic import fixtures, not recalculated Excel workbooks.
        changed=td/'changed';shutil.copytree(source,changed)
        rel='data/projects/OP012109/project.json'
        def price_change(p):
            p['summary']['BaseExGST']+=100
            p['summary']['CostedReferenceExGST']+=100
            package=p['pricing_packages'][0]
            package['historical_extended_sell_ex_gst']+=100
            record=next(x for x in p['historical_records']['packages'] if x['PackageID']==package['id'])
            record['SourceSellTotal']+=100
        update_json(changed,rel,price_change)
        candidate=ppo.prepare(changed)
        change_receipt=ppo.import_prepared(db,candidate)
        check('Changed Rumbalara snapshot adds one immutable version',change_receipt['added_snapshots']==1 and change_receipt['reused_snapshots']==11)
        check('Changed import does not silently replace the selected reference',ppo.active(db)==prepared['bundle_id'])
        diff=ppo.diff_bundles(db,prepared['bundle_id'],candidate['bundle_id'])
        check('Change comparison identifies the price/scope projection',len(diff['changed_projects'])==1 and diff['changed_projects'][0]['price_or_scope_changed'])
        rejects('Stale selection attempt is rejected',lambda:ppo.select_bundle(db,candidate['bundle_id'],'Test reviewer','Review changed data','none'))
        ppo.select_bundle(db,candidate['bundle_id'],'Test reviewer','Synthetic price change accepted for import test',prepared['bundle_id'])
        check('Deliberate selection records previous reference',db.execute('SELECT COUNT(*) FROM selection_events').fetchone()[0]==2)
        old_rum=next(x for x in prepared['items'] if x['project']['opportunity_ref']=='OP012109')
        old=json.loads(db.execute('SELECT project_json FROM snapshots WHERE snapshot_id=?',(old_rum['snapshot_id'],)).fetchone()[0])
        check('Previous snapshot still contains original 51,910 total',old['summary']['CostedReferenceExGST']==51910)
        ppo.export_bundle(db,td/'changed_export')
        new=json.loads((td/'changed_export/wizard-reference.json').read_text())
        check('Re-export follows deliberately selected snapshot',next(p for p in new['projects'] if p['opportunity_ref']=='OP012109')['summary']['CostedReferenceExGST']==52010)
        check('Repeating changed snapshot also creates no duplicates',ppo.import_prepared(db,candidate)['added_snapshots']==0)
        metadata=td/'metadata';shutil.copytree(source,metadata)
        update_json(metadata,rel,lambda p:p['normalised_workbook'].update(sha256='e'*64))
        metadata_candidate=ppo.prepare(metadata)
        ppo.import_prepared(db,metadata_candidate)
        meta_diff=ppo.diff_bundles(db,prepared['bundle_id'],metadata_candidate['bundle_id'])
        check('Provenance-only change is not reported as a price change',
              len(meta_diff['changed_projects'])==1 and not meta_diff['changed_projects'][0]['price_or_scope_changed'])
        transient=td/'transient';shutil.copytree(source,transient)
        update_json(transient,rel,lambda p:p.update(refresh_batch_id='RETRY-ONLY'))
        check('Batch label alone does not manufacture a new business snapshot',
              ppo.prepare(transient)['bundle_id']==prepared['bundle_id'])
        # Invalid source hashes, missing links and reconciliation failures stop before any DB write.
        invalid=td/'invalid';shutil.copytree(source,invalid)
        (invalid/rel).write_text((invalid/rel).read_text()+' ')
        rejects('Unmanifested source change is rejected',lambda:ppo.prepare(invalid))
        shutil.copy2(source/rel,invalid/rel)
        update_json(invalid,rel,lambda p:p['pricing_packages'][0].update(source_document_id='DOC-MISSING'))
        before=ppo.counts(db)
        rejects('Broken package source link is rejected',lambda:ppo.prepare(invalid))
        check('Rejected source leaves database records unchanged',ppo.counts(db)==before)
        shutil.copy2(source/rel,invalid/rel)
        update_json(invalid,rel,lambda p:p['components'][0].update(PackageID='PKG-MISSING'))
        rejects('Broken selected component link is rejected',lambda:ppo.prepare(invalid))
        shutil.copy2(source/rel,invalid/rel)
        update_json(invalid,rel,lambda p:p['summary'].update(BaseExGST=99999))
        rejects('Incorrect selected total is rejected',lambda:ppo.prepare(invalid))
        shutil.copy2(source/rel,invalid/rel)
        update_json(invalid,rel,lambda p:p['pricing_packages'].append(copy.deepcopy(p['pricing_packages'][0])))
        rejects('Duplicate package ID is rejected',lambda:ppo.prepare(invalid))
        # Inject an invalid relational write into the prepared internal object to force a late rollback.
        broken=copy.deepcopy(candidate)
        item=next(x for x in broken['items'] if x['project']['opportunity_ref']=='OP012109')
        item['content_hash']='f'*64;item['snapshot_id']='SNP-'+'f'*64
        item['links'].append(('Package',item['project']['pricing_packages'][0]['id'],'test','Document','DOC-MISSING'))
        before=ppo.counts(db)
        rejects('Late foreign-key failure rolls back the whole transaction',lambda:ppo.import_prepared(db,broken))
        check('No partial records remain after rollback',ppo.counts(db)==before)
        check('SQLite integrity check passes',db.execute('PRAGMA integrity_check').fetchone()[0]=='ok')
        check('Every consumed source file was hash verified',len(prepared['verified_files'])==40)
        db.close()
    ppo.write_json(BASE/'verification/import-tests.json',{'all_passed':True,'test_count':len(RESULTS),
        'tests':RESULTS,'fixture_notice':'Price changes are disposable JSON import fixtures; desktop Excel/VBA was not executed.'})
    print(json.dumps({'all_passed':True,'test_count':len(RESULTS)},indent=2))

if __name__=='__main__':
    main()
