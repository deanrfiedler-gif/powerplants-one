# Import verification record — r01

The pilot stages the refreshed extraction for all **12 historical projects** and exports a consistent reference set for review. It builds on the four r02 normalised workbooks and the r04 register in the previous refresh delivery.

## Coverage

| Check | Result |
| --- | --- |
| Consumed input files checked against the source manifest | 40 of 40 matched |
| Canonical project snapshots | 12 |
| Additional Sohi project created from OP011662 alias | 0 |
| Pricing packages in selected source views | 140 |
| Supporting component rows in selected cost views | 1,848 |
| Specification and scope facts in selected views | 992 |
| Unresolved review tasks | 86: 67 exceptions and 19 specification clarifications |
| Shared rules / clauses / clause conditions | 31 Candidate rules; 18 Draft clauses; 28 Candidate conditions |
| Stored source/context entity records | 6,702 |
| Validated relational links | 13,634 |
| Repeat baseline import | 0 additional snapshots or business records |
| Import logic tests | 39 passed |
| Rendering-script checks with DOM stubs | 15 passed |
| Native browser visual/interaction test | Pending: browser launch restricted |
| Desktop Excel/VBA and technical approval | Pending; not performed by this importer |

The selected projections deliberately omit superseded/reference representations where another view has been selected. Those representations remain in the database's immutable snapshot records. The 992 facts are not 992 approved configuration rules.

## Controlled change test

All test changes were made to disposable JSON copies and temporary databases. They did not change the delivered baseline, workbook formulas or customer quotations.

| Action | Observed result |
| --- | --- |
| Import the baseline extraction | 12 snapshots staged; no reference automatically selected. |
| Deliberately select that reference set | Selection recorded with actor and reason. |
| Import exactly the same extraction | Existing 12 snapshots reused; one additional import receipt, no duplicate data. |
| Increase the Rumbalara tray-filler package by $100 in a synthetic pricing-extraction fixture, with its matching control total | One new Rumbalara snapshot staged; 11 project snapshots reused. |
| Inspect selection before review | Original $51,910 reference still selected. |
| Compare the candidate | Rumbalara price/scope change identified. |
| Attempt selection using a stale expected reference | Rejected. |
| Deliberately select the candidate and re-export | Export shows the synthetic $52,010 figure. The earlier $51,910 snapshot remains retrievable. |
| Repeat the changed import | No duplicate data. |
| Change only workbook provenance metadata in a separate fixture | Evidence version recorded; no price change reported. |
| Change only the refresh batch label | No new business snapshot manufactured. |
| Supply a bad source hash, missing source/component link, duplicate package ID or mismatched total | Rejected. |
| Force a late foreign-key failure | Whole transaction rolled back; no partial records. |

**The delivered database and HTML retain the actual Rumbalara historical total of $51,910 ex GST.** The $52,010 value appears only in the test explanation. This is an import-versioning test, not a claim that desktop Excel recalculated a source workbook or that a new customer quotation was generated.

## Review boundaries retained

- Sohi: $163,550 workbook reference; not accepted; issued quotation evidence retained separately.
- Arborglen: selected Compass configuration and $60,570 reference; alternative revision retained as history.
- Bush to Bowl: $42,840 base, $7,320 options, $50,160 costed reference; no turntable selection.
- Rumbalara: corrected item and 650 L description retained; old discount remains historical evidence.
- RDB: main and wireless schedules remain separate; combined selected amount remains null.
- Boomaroo: package/stage reference only; no automatic whole-project amount.
- Native Excel verification, current-price approval, executable candidate rules and approved draft clauses remain disabled in the export policy.

## Limits and outstanding work

The Python tests verify the import contract, links, pricing controls, versioning, rollback and export selection. The script checks execute the actual viewer logic with minimal DOM stubs. They do not test visual layout, browser focus, native downloads or accessibility.

The native browser suite could not launch because this environment disallows the required local socket. A Playwright test file is included for a suitable desktop/developer environment. The screen should be checked in Edge or Chrome before app integration.

This importer consumes refreshed JSON. It does not perform SharePoint extraction, generic workbook mapping, formula recalculation, VBA execution, rule approval or a live app update. The 637 wording/context audit checks remain in the previous refresh delivery for source review.

## Recorded baseline

- Bundle: BND-ff77ed5e2ec8ace2be87de9452f92267239fa28510fc20c935a9173b99200056
- Schema: ppo.staging-import.r01
- Two successful baseline import receipts are supplied, demonstrating repeat-import behaviour.
- One initial historical reference selection is recorded as automated pilot setup under the user's continuation instruction.
- Machine-readable results are in verification/import-tests.json, rendering-script-tests.json, first-import.json, repeat-import.json and reference-selection.json.
