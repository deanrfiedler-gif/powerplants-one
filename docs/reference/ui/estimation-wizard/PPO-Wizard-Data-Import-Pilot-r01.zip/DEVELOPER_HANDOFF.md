# Developer handoff — controlled historical import r01

The runtime uses Python 3.10+ and its standard library. No additional Python packages, credentials or network services are needed. Keep the supplied customer data within authorised private storage. This package is not for the synthetic PPO demonstration repository.

The source contract is `ppo.historical-catalog.r02` with twelve `ppo.historical-project.r02` records. The selected export contract is `ppo.wizard-reference-catalog.r01`. The database is a local staging implementation; it does not migrate or replace the live PostgreSQL schema.

## Run from the extracted pilot folder

On Windows use `py -3`; on macOS/Linux substitute `python3`.

Inspect the supplied database:

```shell
py -3 code/ppo_import.py --database ppo-staging.sqlite status
```

Reimport the supplied extraction. The second and subsequent identical imports add an import receipt, but no duplicate snapshots, records or links:

```shell
py -3 code/ppo_import.py --database ppo-staging.sqlite import --source input --receipt import-receipt.json
```

For a new validated extraction delivery, replace `input` with that extracted delivery folder. The importer checks the source manifest, schema, identity, category/family mappings, revision/package/component/specification/source links, queue targets and comparable pricing controls before writing. A modified file with an old manifest is rejected. Never regenerate a source manifest to conceal an unexplained mismatch.

The receipt returns a full `bundle_id`. Use it to inspect a candidate against the currently selected reference:

```shell
py -3 code/ppo_import.py --database ppo-staging.sqlite diff --candidate CANDIDATE_BUNDLE_ID
```

After reviewing the differences, deliberately select the historical reference set:

```shell
py -3 code/ppo_import.py --database ppo-staging.sqlite select --bundle CANDIDATE_BUNDLE_ID --actor "Reviewer name" --reason "Reason for reference selection" --expected-selection CURRENT_BUNDLE_ID
```

Substitute the actual full bundle IDs; they are not filenames. Obtain `CURRENT_BUNDLE_ID` from `status`. Use `none` only when the database has no selection. A stale expected selection is rejected. The actor is a locally entered audit label, not an authenticated production identity. This selection is not technical approval, price approval or customer acceptance.

Regenerate the JSON and offline review screen from the selected bundle:

```shell
py -3 code/ppo_import.py --database ppo-staging.sqlite export --output review
```

To preview a candidate without selecting it, add `--bundle CANDIDATE_BUNDLE_ID` and use a different output folder. The JSON records `selected_in_database: false`. Both candidate and selected exports remain historical references.

## Database structure

| Table / view | Contract |
| --- | --- |
| `snapshots` | Immutable application-level project versions identified by SHA-256 of their extraction content, field bindings, Markdown reference and shared context. Raw source JSON and converted JSON are both preserved. |
| `records` | Source entities keyed by `(snapshot_id, kind, record_id)`, including original/supporting revisions and global rule/clause context. Shared rule definitions are scoped into snapshots for evidence links; their canonical shared library remains in `bundles.shared_json`. |
| `record_links` | Composite foreign keys validate both endpoints of every stored link. These are evidence/lineage links, not executable equipment dependencies. |
| `package_projection` | Selected source pricing revision, extended amounts and scope; money stored as decimal text. |
| `component_projection` | Selected supporting cost-view rows. Component prices must not be added to package prices. |
| `requirement_projection` | Selected source facts, including unresolved or conflicting wording. |
| `bundles`, `bundle_projects` | Versioned reference sets. Original stable entity IDs are preserved under their snapshot context. |
| `import_receipts` | Every import attempt that commits successfully, verified input hashes, added/reused counts and source path. |
| `reference_selection`, `selection_events` | One deliberate reference set and its previous selections. Import does not change this selection. |
| `selected_projects`, `selected_packages`, `selected_components`, `selected_requirements` | Read projections for the selected historical reference set. Package scopes still need explicit handling. |

The importer inserts snapshot records and never updates an earlier snapshot. This is application behaviour, not tamper-resistant storage: a database administrator can alter a local SQLite file. Use server-side permissions, immutable issued revisions and authenticated audit identities when implementing the live system.

Example reference queries:

```sql
SELECT opportunity_ref, reference_revision_id, snapshot_id
FROM selected_projects
ORDER BY opportunity_ref;

SELECT package_id, scope, sell_aud_decimal, section_id, payload_json
FROM selected_packages
WHERE opportunity_ref = 'OP012109';
```

Do not use an unqualified SQL sum across scopes, stages, revisions or cost/detail views. Use a decimal arithmetic implementation, preserve null values, and reconcile against the project's scoped source controls.

## Import decisions and limits

- Canonical Sohi identity is `PRJ-OP011661`; `PRJ-OP011662` remains an alias. It is not counted as another project.
- Category, equipment family and supplier are separate dimensions. Major Projects is a project-level classification; component packages retain their discipline.
- Package amounts are already extended. For example, a bundle containing two physical systems is not multiplied by two again.
- RDB's main, wireless and option schedules remain separate. Boomaroo has no automatic whole-project total.
- Null means unknown, not zero. Historical monetary values are preserved at source precision and displayed to two decimals.
- Named Excel 1900-system date fields become ISO dates/timestamps. The original serials and conversion locations are retained. Source timestamps without a timezone do not acquire one. The fictitious serial-60 leap day is rejected.
- Source-file and content hashes establish byte identity, not authenticity or engineering correctness. This importer verifies the 40 files it consumes, not the absent original workbooks/PDFs.
- Shared rule/clause context contributes to snapshot identity. Changing that context can create new snapshots for otherwise unchanged projects. Batch labels and refresh timestamps alone do not create new business snapshots.
- A workbook provenance/hash change can create an evidence version without a price change. The comparison reports actual pricing/scope differences separately.
- Formal quotations and source Markdown remain historical evidence. Import does not rewrite their issued prices. The viewer's price panel reads the selected workbook extraction.
- `review_queue` adds all 86 exception/clarification tasks to the selected export. The 637 wording/context audit checks remain in the preceding refresh delivery's `data/wording-review.csv`; they are not converted into approved specifications by this import.
- Database imports are atomic. Failed validation stops before insertion; late foreign-key failures roll back the complete transaction.

## Connect to the wizard

1. Load the selected export through a private backend or application data adapter. Do not put this dataset in a public/static production bundle.
2. Search by canonical project, quote category, equipment family, supplier and scoped equipment requirements. Show review and source evidence alongside each suggestion.
3. Persist a new estimate revision with its own IDs. Reference the historical `snapshot_id` and selected source package IDs for traceability.
4. Establish fresh pricing inputs and applicable technical rules. Keep option selection, service allowances, responsibilities and exclusions in that same saved revision.
5. Generate the customer quotation from the saved new estimate revision. Do not generate a new customer quote directly from this historical reference export or carry forward a historical discount automatically.
6. When reference data changes, compare snapshots and offer explicit draft updates. Keep issued quote revisions and earlier estimate revisions unchanged.

This r01 provides the import and reference-review boundary. It contains no live app endpoint, production permissions, generic workbook extractor, native Excel recalculation or multi-family estimate-pricing engine.

## Repeat verification

```shell
py -3 code/test_import.py
```

The test suite uses temporary databases and disposable JSON changes; it does not change the supplied staging database or source workbooks. A rendering-script test runs under Node with DOM stubs:

```shell
node code/test_rendering_script.mjs
```

The separate `code/test_viewer.mjs` is an optional Playwright browser suite. It requires a local Playwright installation and its supported Chromium browser. Its native execution is pending; it could not launch in the build environment. DOM-stub tests do not certify visual layout, keyboard/focus behaviour, native downloads or accessibility.
