# Use the Wizard Data Import Pilot r01

This pilot takes the refreshed historical extraction into a versioned staging database and provides an offline screen for reviewing the data the wizard will use.

**Start by opening `review/PPO-Wizard-Data-Review-r01.html` in Edge or Chrome.** It is self-contained and needs no installation or connection. The supplied review copy contains all 12 project references. Rumbalara opens first.

1. Choose a project, or filter by quote category and equipment family. Searching `OP011662` finds the canonical Sohi opportunity, `OP011661`.
2. Inspect **Packages**. Base, Option, Alternative, Excluded and Unknown remain distinct. The amounts are historical extended package amounts.
3. Inspect **Components** and **Specifications & scope**. Open a source locator to see its document identity and recorded evidence. Supporting cost rows are not an independently approved bill of materials.
4. Use **Review items** to see the open exceptions, specification clarifications and your earlier confirmations. The full set contains 86 unresolved records. Reading a record does not mark it resolved.
5. Inspect **Clauses & rules**. These are 18 shared draft clauses and 31 candidate rules, available for review. They are not automatically selected for the displayed project.
6. Use **Download selected reference JSON** to give your developer one project's linked historical reference, including its pricing policy and snapshot identity.

For example, Rumbalara shows the corrected tray filler component and 650 L description, its historical $51,910 ex GST total and the old discount as reference evidence. Bush to Bowl shows $42,840 base plus $7,320 in optional accessories, with the $50,160 costed set retained. Sohi remains unaccepted at a workbook reference of $163,550. RDB's combined amount and Boomaroo's whole-project amount remain unresolved.

## What each deliverable does

| File or folder | Purpose |
| --- | --- |
| `review/PPO-Wizard-Data-Review-r01.html` | Offline reference review screen; not connected to the live app. |
| `review/wizard-reference.json` | Machine-readable selected reference set for the wizard's future data adapter. |
| `ppo-staging.sqlite` | Populated local database with immutable import snapshots, source records, validated links and reference-selection history. |
| `code/ppo_import.py` | Repeatable import, comparison, deliberate reference selection and export commands. |
| `input/` | Exact copies of the 40 refreshed source files consumed by this importer, plus their original delivery manifest. |
| `IMPORT_REPORT.md` | Coverage, test results, version-change demonstration and outstanding checks. |
| `DEVELOPER_HANDOFF.md` | Data contract, commands and integration boundaries. |

The input folder contains the extraction JSON and internal Markdown records. Original workbooks, source PDF/Word files and the register remain in the preceding **PPO_Historical_Extraction_Refresh_r01** delivery. The source manifest also lists those original delivery files; this pilot verifies the files it actually consumes.

## When you correct or change a workbook

Continue estimating in its original calculation worksheets. Recalculate and save it in desktop Excel, then run the validated extraction profile for that workbook family to produce a new extraction delivery. Retain the old files and snapshots.

Your developer then runs **import → compare → select reference → export** using the commands in `DEVELOPER_HANDOFF.md`. Import alone does not change the selected reference. Opening an old HTML review copy will continue to show its old snapshot; regenerate the review copy after deliberately selecting the new set.

The existing Rumbalara extraction routine is a project-specific pilot. The import code here starts from its refreshed JSON contract; it does not read arbitrary Excel workbooks, calculate formulas, execute VBA or refresh SharePoint.

## Next use in Powerplants One

The developer can now connect the wizard's historical-reference search to `review/wizard-reference.json` or the database's selected-reference views. For a new enquiry, the wizard must create a separate estimate revision, with its own supplier price basis, scope, quantities and commercial terms. The quotation should be generated from that saved new revision.

Desktop Excel/VBA checks, technical review, native browser visual checks and the live app connection remain outstanding. The automated checks completed in this pilot are recorded in `IMPORT_REPORT.md`.
