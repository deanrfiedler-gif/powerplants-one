# Sales to Estimating Intake Design r01

Prepared for Dean Fiedler on 13 September 2026. This package defines the potting-line pilot and provides an interactive local demonstration. It does not modify the Powerplants One application or publish customer information.

## Start here

1. Open **sales-estimating-intake-preview-r01.html** in Chrome or Edge. It is self-contained and requires no installation or internet connection. Use the three screen tabs and the Worked example selector. All changes reset on reload; Save draft is explicitly a preview simulation.
2. Read **sales-estimating-intake-design-r01.html** for the workflow, roles, readiness, exceptions, examples, measures and implementation boundary. The Markdown version contains the same design content.
3. Consult **sales-estimating-intake-field-map-r01.md** or its JSON counterpart for all 476 numbered source items and ten supplementary structures from the four drafts. Source documents are identified by exact filename and SHA256; their original bytes are not bundled.
4. Read **sales-estimating-intake-verification-r01.md** for passed checks and the browser-testing limitation.

## Try the three journeys

| Example | Actions | What to observe |
|---|---|---|
| Single machine | As Sales, edit/save if wanted and Submit. Switch to Estimating, select the estimating owner and accept. | An exact submitted revision becomes the accepted basis. No estimate or quote is created. |
| Integrated line | Switch to Estimating, open Handover review and Request clarification. Switch to Sales, open Sales intake and Record reply. Submit the revision. Switch to Estimating, Review and resolve the reply, select the owner and accept. | A customer reply needs reviewer resolution. r01 remains in history; acceptance references r02. |
| Changed brief | Select example 3 and Sales. Create revision and apply the robotic-placing example. Save and submit. Switch to Estimating and review the comparison. Resolve the fictional technical assessment, select the owner and accept. | Accepted r01 remains the basis until r02 is accepted. Original scope and acceptance remain intact. |

Use Phone preview to inspect a 390px frame, or resize your browser. Reset examples restores the starting scenarios after confirmation. The top actor selector illustrates roles and does not provide authentication.

## What to review

- Is the short initial brief sufficient for sales to capture a useful request?
- Does estimating receive the scope, responsibilities and evidence it needs?
- Are questions, ownership and requested/agreed dates clear?
- Is the distinction between accepted scope and a pending change clear?
- Are the proposed per-purpose readiness rules suitable for a first pilot?

The next bounded step is to reconcile the intake contract with current E2 work and implement the synthetic capture-to-accepted-successor journey. Automated equipment selection and pricing remain later work.

## Reproducible check

With Node available, run `node check-intake-preview-r01.cjs` from this folder. It checks the synthetic model only. Passing it does not prove PPO permissions, persistence, browser behaviour or business acceptance.

The original source forms, real customer records and brand guideline PDF are not included. No external script, web font request, analytics or network call is required by the preview.
