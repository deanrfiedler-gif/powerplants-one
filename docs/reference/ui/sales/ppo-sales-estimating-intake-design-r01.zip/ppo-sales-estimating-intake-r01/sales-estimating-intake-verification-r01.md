# Sales to Estimating Intake Verification

**Revision:** r01 · **Date:** 13 September 2026 · **Scope:** design package and synthetic preview

## Evidence checked

- GitHub main commit `a02ea22f4514757983f0b8d3bc8cd8fe80f8a787`, merge of PR #142. AGENTS, README, STATUS, E2 design/contract and UI guidance read. Relevant BP-04, E1, wizard, pipeline and routing documents were also inspected in the preceding advisory review at the same head.
- All four local DOCX sources were extracted and mapped. Original filename, SHA256, byte length and source status are retained in the JSON mapping. Originals were not edited.
- Source counts: Potting v3 117; Greenhouse 162; Berry 107; Javo 90. All 476 numbered items accounted for, plus ten explicit local anchors for unnumbered structures. Every active target resolves to a canonical field group; specialist deferred targets remain in their source namespace.
- Supplied transparent logo inspected. Brand PDF colour page 18 rendered and inspected; navy #242a37, green #62bb46 and white confirmed. Roboto typography confirmed from the PDF text. The preview is a module workspace with a text product identity; it does not invent or alter a logo.

## Passed local model checks

Nine executable cases pass in `check-intake-preview-r01.cjs`:

1. Sales capture/save/submit and duplicate-submission refusal.
2. Synthetic role guards for editing and acceptance.
3. Invalid dimensions refused; blank quantities retained as unknown.
4. Acceptance requires owner/target and binds an immutable submission.
5. Integrated-line clarification, reply, successor submission, reviewer resolution and acceptance.
6. A reply cannot resolve missing interface/responsibility facts by itself.
7. Accepted original preserved through a robotic-placing successor.
8. Technical review is bound to the reviewed submission, not inherited by later revisions.
9. Independent request drafts survive switching within the preview; a fresh session resets them.

The HTML’s JavaScript was syntax checked. Template output was generated locally for sales intake, queue, changed-brief review and a phone frame. Links and mapping references were checked. The delivered HTML embeds its font data and interaction model and has no external runtime dependency.

## Visual review and browser limitation

Static document renders of the authored intake, queue, changed-brief and phone templates were inspected. The document renderer differs from a browser, particularly for native form controls and some CSS. A form-layout incompatibility in that render prompted a simpler flex layout. These renders are QA intermediates, not screenshots of the live HTML or proof of browser fidelity.

Live browser testing was **not completed**. The local Playwright Chromium installation failed with download timeouts and an HTTP 502. The available cloud browser rejected navigation to the local preview under its URL security policy. That rejection was not bypassed through an alternate URL or browser. The package therefore does not claim browser-click, keyboard-focus, actual 320px/390px browser layout or screenshot acceptance.

The Phone preview control supplies a proposed 390px frame; native browser responsiveness still requires review. Dialog focus-return code and labels are present but have not been verified through real browser interaction in this environment.

## Not tested or implemented

- No PPO application code, migration, repository branch, pull request, deployment or live integration changed.
- No actual server permissions, company isolation, concurrency, operation receipts, persistence/restart, file-byte integrity or offline capability tested by this preview.
- No attachment uploaded from the preview; evidence entries are named fictional examples with source-note dialogs.
- No real estimating workload, commercial approval, technical suitability, supplier rating, costing, quotation or operational improvement verified.
- Foundation/prototype/naming repository checks were not run: this task created a standalone review package and made no repository changes. They remain applicable to a subsequent repository contribution.

## Implementation gate

Before runtime work, verify current main, reconcile overlapping E2 contracts and agree the scoped actor/grant mapping. Execute IN01–IN13 from the design against the actual application where applicable. Record browser and owner acceptance separately from code checks. The nine passing model cases are design evidence only.
