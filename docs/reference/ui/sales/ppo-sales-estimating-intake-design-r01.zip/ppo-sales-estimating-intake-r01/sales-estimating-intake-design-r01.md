---
document_id: PPO-010-INTAKE-DESIGN
revision: r01
date: 2026-09-13
owner: Dean Fiedler
status: Design delivered for review; runtime implementation not invoked
repository_baseline: a02ea22f4514757983f0b8d3bc8cd8fe80f8a787
parent_work_package: PPO-010 / BP-04
---

# Sales to Estimating Intake Design

This design gives Powerplants sales staff a practical way to capture a customer requirement and obtain an explicit estimating handover. The first pilot combines the two unreleased potting-line forms into one progressive questionnaire. It covers capture, save, submit, clarify, accept and revise, with a short initial brief and technical detail shown when relevant.

Dean authorised this design package on 13 September 2026. The deliverables are the three-screen interactive preview, a complete source field map, three worked examples and a bounded implementation contract. New workflow rules in this document are proposals for review. The preview is a local simulation with fictional records; it does not implement PPO server persistence, permissions, file storage, notifications or estimates.

## 1. Recommended product decision

Add **Scope & Intake** to the canonical deal detail and an **Intake queue** within Estimating. Both open the same request and exact brief revisions. Sales retains the customer relationship and its sales next action; the estimating owner accepts responsibility for an agreed estimating output. Acceptance of an intake does not approve a design, move a deal, create a quote, confirm a delivery route or authorise work.

Keep one editable brief per request, with immutable submitted revisions and explicit review decisions. A customer change after acceptance creates a successor for review while the former accepted basis remains visible. Each clarification has a question, owner and due date or explicit due-date-needed reason.

Use the first pilot for potting equipment, connected lines and retrofit/staging intent. General greenhouse and berry questions stay mapped for later modules. Do not ask a machine enquiry to complete an entire greenhouse questionnaire. Do not require every answer before sales can record and submit the enquiry for triage.

## 2. Evidence and current PPO alignment

Repository access was checked against `main` commit `a02ea22f4514757983f0b8d3bc8cd8fe80f8a787`, merge of PR #142, dated 13 September 2026. AGENTS, README, STATUS, the shared UI specification and E2 design/contract were read at that commit. The previous advisory review also inspected BP-04, ADR-0017, the guided estimating design and the adopted pipeline and derived-routing decisions at the same head. Current repository documents are the product evidence; earlier session memory is not used as proof of implementation.

| Evidence | Consequence for this package |
|---|---|
| BP-04 owns estimating requests, scope/answer revisions, options, estimates and quotes | Intake extends Estimating and reuses CRM/shared context; it is not a new business domain. |
| E1 implements bounded manual estimates and exact draft quotations | Intake does not mutate E1 versions or pretend its current API already accepts questionnaire snapshots. |
| E2 scope and questionnaire contracts are proposed designs | Reuse their identity, snapshot and conflict disciplines. Do not claim their rules have all been adopted. |
| Derived-routing decision, 12 September | Estimating effort class is distinct from eventual delivery route. Intake captures needs; no Project/Sales Order/Service Order binding occurs here. |
| Accepted five-stage CRM direction | Discovery and Scoping carry intake work; Quoting carries estimating and offer work. No stage changes are inferred from submission, acceptance or completion of an Activity. The five-stage runtime remains a separate increment. |
| User says all four forms were unreleased | Treat them as draft source evidence, not mandatory company procedure or technical authority. |
| Brand PDF p18 and current shared UI guidance | Navy #242a37, green #62bb46, white, Roboto/Verdana; readable controls, visible focus and responsive content. |

There is a repository inconsistency to avoid carrying forward: STATUS broadly labels E2 routing adopted, while the newer detailed routing decision says E2-D01 was first decided in a different direction and E2-D02/D03 remain proposed. This package follows the detailed later decision and does not adopt the older declared delivery-route engine. No repository content was changed during this design task.

Sources: [BP-04](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/blueprints/BP-04-estimating-quotation.md), [E1 ADR](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/decisions/ADR-0017-estimating-e1.md), [E2 contract](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/contracts/estimating-e2-design.md), [derived routing](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/decisions/estimating-derived-routing.md), [pipeline](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/decisions/crm-pipeline-stage-model.md), [UI specification](https://github.com/deanrfiedler-gif/powerplants-one/blob/a02ea22f4514757983f0b8d3bc8cd8fe80f8a787/docs/standards/ui-style-specification.md).

## 3. Consolidation of the four drafts

The separate [field map](sales-estimating-intake-field-map-r01.md) and [machine-readable mapping](sales-estimating-intake-field-map-r01.json) account for 476 numbered source items and ten supplemental anchors. There are 107 canonical field groups across the complete mapping, including future shared extensions. This is a question bank, not 107 compulsory controls in the pilot.

| Source | Role in the design | Source reconciliation |
|---|---|---|
| Potting line v3 | Short ten-item opening, throughput distinctions, media and integration detail | Internal ID PP-INTK-AUTO-CUST-001; June 2026. Minimum snapshot repeats detail questions; map both to one answer. |
| Javo draft | Responsibility matrix, process and robotics detail, installation and support | Filename PPA-TPL-004; internal PPA-COM-FRM-014, v0.1, 3 July 2026. Keep both identities in provenance. |
| Greenhouse v1.2 | Shared customer, scope, timing, responsibility and evidence concepts; specialist expansion bank | Full structure/climate/system detail remains deferred. No structural or equipment selection rules are imported. |
| Berry filename v1.2 | Shared context plus water/fertigation/control expansion bank | Body says Version 1.0; checklist has duplicated/placeholder entries. No automatic release precedence from filename. |

Preserve source bytes and hashes. Questionnaire publication will use a new PPO definition with stable question and choice IDs. Changing that definition creates a new version and requires deliberate comparison before applying it to a working request. Do not alter historical accepted answers when a reusable question changes.

Unreleased return addresses, privacy wording, signatures and acknowledgements are not automatically adopted operational clauses. Capture who provided information and any project-specific permission to contact advisers; sending a message remains a separate explicit action. The pilot is staff-operated. Customer self-service and public forms are later work.

## 4. Scope and terminology

| Concept | Meaning |
|---|---|
| Deal | Existing permitted Opportunity in CRM; the commercial pursuit and sales owner. |
| Intake request | One identifiable piece of estimating work requested against the deal. Proposed first-slice limit: one active potting intake per deal, with successors for changes; separate requests for genuinely separate later scopes require a later policy. |
| Working brief | Editable answers and proposed scope. May be incomplete. Saving is not submission. |
| Submitted revision | Immutable, attributable snapshot supplied to estimating for triage. |
| Accepted basis | The exact submitted revision the estimating owner accepted for a stated output and target. It is not a technical release. |
| Clarification | An owned question about a field, evidence item or scope boundary. A reply is not automatically reviewer resolution. |
| Estimate basis | An explicit future link from a newly authored estimate version to the accepted intake revision. No automatic E1 mutation. |
| Revision r01 / r02 | Revision of the intake brief. Separate from this design’s r01, questionnaire definition revision and estimate/quote versions. |

The business label “project intake” does not force every enquiry to become a Project record. Customer/site/equipment selection uses the shared masters and current permissions. A missing master record follows its own authorised creation/resolution flow; intake text must not create a second customer master.

## 5. Capture and progressive disclosure

The initial brief presents existing customer/site/contact context, the problem and desired result, build scope, installation context, operations requested, main container range, media, timing and requested commercial output. Budget is optional, with Not disclosed distinct from Unknown. The response type is Budget estimate, Formal quotation preparation, or Technical scoping advice. A formal-output request does not mean that the later quotation is issue-ready.

The first runtime slice should have approximately 30 active field groups: shared customer/site/contact, sales owner, problem/outcome, build scope, installation context, operations, containers, media types/supply, average/peak/sustained rates, existing equipment/interfaces, footprint, robotics intent, handling constraints, electrical supply, requested operational/estimating dates, timing constraints, response type, fulfilment responsibilities, exclusions, assumptions, evidence and change reason. Logical repeatable rows preserve atomic details. Remaining bank questions can appear as optional prompts in scoped notes/evidence until their typed controls are deliberately added. No generated equipment or cost output is needed to prove the intake journey.

| Condition | Reveal | Readiness effect |
|---|---|---|
| Every potting enquiry | Containers, media, production objective, scope boundaries, delivery/installation intent | Essential to describe the requested work; unknowns can be submitted for triage. |
| Existing equipment / combination | Equipment, disposition, interface heights/hand-offs/controls, operating-during-install constraints | Reviewer decides which interface evidence blocks the requested estimating output. |
| Connected or staged line | Sustained output, layout, buffering, downstream hand-off, phases | Do not equate potting-head peak with sustained line performance. |
| Robotics included or requested as option | Placement destination, container/plant handling, layout, controls, safeguarding review | Technical assessment required; no auto-selection or assertion of safety. |
| Supply and installation/commissioning | Responsibilities, services, access, unloading, timing | Unknown party/scope stays an open question. |
| Additive dosing selected | Material, recipe source, dosing intent | Detailed chemical/dosing design stays with a competent technical reviewer. |
| Specialist greenhouse/berry system added | Capture the additional scope and flag specialist assessment | Do not turn on unreviewed specialist calculation or silently broaden pilot completeness. |

An answer can be NotAnswered, Deferred, Answered or Confirmed. Applicability is separate: Applicable, NotApplicable with reason, or Unknown. The UI may show plain labels such as Not sure, Customer advised and Confirmed for this brief. Confirmation identifies who confirmed what, when and from which evidence; it never implies Engineering approved suitability. All values retain source attribution. Every unresolved item required for the agreed output has an owner and due date or a due-date-needed reason.

Numeric inputs retain units and basis. Throughput distinguishes pots/hour from trays/hour and average from peak and sustained rate. Container diameter and height use mm, volume uses L; original cm values and conversion are retained. Dates distinguish a requested operational date, a customer quotation deadline and the estimator’s agreed completion target. None is a supplier lead-time commitment.

When a condition becomes false, preserve the old answer as inactive history and show its effect in the comparison. Never silently delete it or continue to include an inactive feature in scope. Re-enabling it proposes the old value for reconfirmation, with its source date.

## 6. Readiness at each step

Saving a draft requires valid values for the fields that are supplied, an allowed definition and permitted parent context. It does not require a complete technical brief.

Submission requires a permitted deal/customer, named sales owner, a meaningful need/scope summary, response type, site/contact or an explicit unresolved reason, and a requested estimating date or date-needed reason. Each material unknown must be visible with an owner/action. Conditional technical gaps can accompany the submission so estimating can triage them. Submission freezes the answers and creates one review-queue entry, with one operation receipt.

Acceptance requires an eligible estimating owner, an agreed target or explicit scheduling-pending reason, the exact submitted revision, reviewed scope boundaries, and a disposition for every question relevant to that output. A blocking question must be resolved or expressly reclassified by the authorised reviewer with a reason and an appropriate output/assumption change. It cannot disappear because a salesperson marked it complete.

**Budget assessment:** reviewed assumptions may be sufficient for bounded budget work; uncertain items remain visible and no issue-ready quote is implied. **Formal quotation preparation:** the reviewer establishes which technical facts must be available to start costing and which further checks must be satisfied before issue. **Technical scoping advice:** the output may be a site survey or engineering assessment rather than a price. The pilot supports requesting these outputs without inventing their approval authority.

Show exact blockers and next actions, not a misleading percentage. In the synthetic preview, a supplied customer need and output enable submission; missing conveyor interface evidence or requested robotics assessment blocks acceptance until reviewed. Those fixture rules are illustrative, not adopted supplier criteria.

## 7. Request and revision lifecycle

| Action | Starting state | Actor and guard | Result |
|---|---|---|---|
| Save draft | Draft / Clarification required / successor Draft | Sales editor or assigned contributor; expected working version | Saved working version; no submission or acceptance. |
| Submit | Draft or resolved response draft | Sales submitter; submission checks; expected request/working versions | Immutable revision, Submitted state, single queue item. |
| Request clarification | Submitted | Estimating reviewer; one or more specific owned questions | Clarification required; submission preserved; due/action recorded. |
| Record reply | Clarification required | Assigned responder or sales owner with rights | Attributed response and proposed changed answers; question becomes Answered, not Resolved. |
| Resubmit | Clarification required | Sales submitter; response context and change reason | New Submitted revision linked to predecessor; previous questions and responses retained. |
| Resolve clarification | Submitted revision containing response | Estimating reviewer checks evidence | Resolved question or renewed clarification with reason; never self-approved by reply alone. |
| Accept for estimating | Submitted | Authorised estimating reviewer; exact revision; no blocking open questions; owner/target | Append acceptance; accepted-basis pointer advances; state Accepted for estimating. |
| Create revision | Accepted for estimating | Sales editor; mandatory change reason and expected accepted version | New working successor; accepted predecessor remains the active basis pending review. |
| Accept successor | Submitted successor | Estimating reviewer; comparison and impact disposition | New accepted basis; historical acceptance immutable; affected estimate/quote marked for review through a later explicit interface. |
| Withdraw | Draft / Submitted / Clarification required | Sales owner; reason; concurrent reviewer guard | Withdrawn, history retained; no record deletion. |
| Request cancellation | Accepted for estimating | Sales owner requests; estimating owner confirms work disposition | Future controlled exception; first slice shows an owned cancellation request and retains accepted history. No silent deletion of work. |

The request’s visible state describes the latest proposal. The accepted basis is a separate pointer. For example: “r02 submitted · accepted basis r01 · change review needed”. There is no ambiguous replacement of an Accepted label with Draft that hides ongoing estimating work.

The estimator records whether a pending change pauses affected work or allows unaffected preparation to continue. Submission alone does not authorise costing changed scope. The first preview holds a single current simulated submission and an immutable history array; runtime must support the concurrency and authority guards below.

## 8. Roles and visibility

| Role | Intended actions | Limits |
|---|---|---|
| Sales owner / permitted editor | Capture, save, submit, reply, propose changes, withdraw unaccepted request | Cannot accept on behalf of estimating or approve technical suitability. |
| Estimating intake reviewer | Review, classify questions, accept/request clarification, assign eligible estimating owner and target | Assignment requires actual grant eligibility; ownership alone is not permission. |
| Assigned estimator | View accepted basis; prepare estimate; raise further questions; assess change impact | Exact basis link and current E1 permissions govern estimate work. |
| Engineering contributor | Supply attributed technical response and evidence | Does not acquire commercial acceptance rights; released design remains in Engineering. |
| Read-only permitted user | View authorised brief, status and history | No edit, acceptance, file visibility beyond existing grants or internal cost access. |

Reuse current company/workspace/record visibility. Proposed intake capabilities require an implementation permission matrix mapped to real grants; no capability names or corporate delegates are invented here. Server checks cover selectors, counters, queue results, every related target, commands, historical revisions, attachment downloads and receipt replay. A denied source must not leak its filename or prior captured label.

The preview actor selector is a demonstration control only. It disables inappropriate buttons but provides no authentication or security.

## 9. The three screens

### Sales intake

Open from the deal’s Scope & Intake tab. Header shows deal, organisation/site, sales owner, latest request state, current revision and saved status. A short brief is the initial view. Expand relevant system detail and evidence as needed; preserve entered data when switching sections. Display blockers/action owners beside the work, with a right-hand readiness panel on desktop and stacked content on phone.

Actions: Save draft, Submit to estimating, respond to questions, create a revision with reason, view accepted predecessor. Validation points to fields and preserves input. Shared context is selected from authorised records. Master contact/address changes use the shared record workflow. Reuse existing activities for explicit follow-up links; do not silently complete CRM activities or move the deal.

### Estimating intake queue

Rows show request/deal, customer/site, request state, requested output, sales owner, requested date, blockers and latest change. Search and filter act on the same permitted records; counts reflect the filtered result. Open the exact request for review. No bulk acceptance: the reviewer must see scope and blockers.

Submitted age starts at the original submission. Resubmission must not reset its age or hide a slow request. A separate latest-submission timestamp supports the reviewer’s current queue. Suggested sort is oldest submitted first, with explicit due-date sort available. Due dates are requested until an estimator agrees a target. Customer urgency does not imply an authorised priority threshold.

### Handover review

Read the exact submitted revision, requested output, responsibility summary, evidence availability, assumptions and questions. A successor opens with a field-level comparison to the accepted basis: Added, Changed, Removed and Unchanged; show before/after and affected work. Reviewers resolve responses explicitly, then assign an eligible owner and target before acceptance.

Actions: Request clarification, resolve a response, accept for estimating, inspect history. Acceptance records purpose and scope, not a broad technical approval. After acceptance show the new accepted revision and any downstream impact needing review. Later estimate creation is explicit and binds that revision.

The standalone HTML illustrates these screens and the three cases. It uses in-memory saved drafts and snapshots, labelled throughout. It does not implement the entire source bank, external attachments, persistent records, real workload assignment, advanced queue sorting or estimate creation.

## 10. Evidence and responsibilities

Evidence records distinguish Requested, Can provide, Unavailable, Not applicable, and Available. Available means actual stored bytes/link resolution with current access, exact version and hash in runtime. It is separate from Reviewed. Physical pot samples use requested/received/custodian states and never masquerade as uploaded files.

Suggested evidence categories: layout, equipment list/photos, media specification, container/tray schedule, production targets, electrical/services, site access, controls and supplier correspondence. A file can support several answers through references; do not create a duplicate upload per question. An unavailable attachment can be replaced by an explicit reviewed measurement/statement when suitable, with attribution and purpose. A checkbox alone is not evidence.

Responsibility rows separate what is included from who will perform it: supply, freight, unloading, mechanical installation, electrical connection, civil works, compressed air, water/drainage, safeguarding review, commissioning, training and support. Each row supports Included, Excluded, Option or Unknown and PPA, Customer, Named other or Unknown. Customer-advised responsibility is not a signed contract term. Draft quotation narrative must be reviewed against the final accepted scope.

## 11. Logical data and implementation behaviour

These are logical proposals, not reserved SQL names, migrations or new parent requirements.

| Record | Required content |
|---|---|
| IntakeRequest | UUID; company/workspace; opportunity UUID; sales owner; latest working/submitted pointers; accepted revision UUID if any; requested output/date; request state; version; synthetic flag. |
| IntakeWorkingVersion | Versioned editable answer proposal; exact definition ID/revision/hash; source refs; conditional applicability; current change reason. |
| IntakeRevision | UUID; request; predecessor; immutable answers/scope/evidence refs; canonical hash; submitted actor/time; definition snapshot; change reason. |
| IntakeReview | UUID; exact revision/hash; reviewer; decision; estimating owner; agreed target/date-needed reason; output; assumption dispositions; affected-work decision. Append-only. |
| Clarification | UUID; revision/field/evidence reference; question; severity for requested output; owner; due/date-needed reason; append-only responses; resolution actor/time/reason. |
| EvidenceReference | Shared document ID; exact version/hash; category; scope/answer links; availability and review metadata. File content follows the document adapter and intended SharePoint boundary. |
| EstimateBasisLink | Future append-only link from a new estimate version to exact accepted intake, definition, scope and answer snapshots. Existing E1 versions remain unchanged. |

Commands use expected versions, operation UUID and canonical payload hash. Saving validates without coercing unknowns. Submission atomically freezes the revision and creates the queue event. Acceptance atomically checks the current submission, questions, target/owner eligibility and review record, then changes the accepted pointer. Original-operation retry returns one effect after reauthorisation. Same operation ID with different payload conflicts. A timeout reconciles the original receipt before any retry with a new intent.

Concurrent sales edit and estimating acceptance must not cause a reviewer to accept unseen answers. Return VersionConflict with a safe comparison, retaining the permitted draft for recovery. Two acceptance attempts cannot create competing active bases. A withdrawn request cannot be accepted by a stale reviewer. Immutable submitted and accepted revisions cannot be patched in place. Changing the reusable questionnaire never rewrites history.

If a new accepted basis affects an existing estimate or quote, show an owned review-needed exception. Do not update prices, quantities, generated text, approvals or customer acknowledgement automatically. The implementation must explicitly reconcile the intake extension with E1 and any intervening E2 work before reserving a migration. This design adds no database schema, API or runtime dependency.

## 12. Failure and accessibility states

| State | Required behaviour |
|---|---|
| Loading / unavailable | Retain context; retry; never display a failed query as zero requests. |
| Unsaved / saving / saved | Saved appears only after durable accepted receipt in runtime. Preview says saved in this preview and resets on reload. |
| Validation | Explain field problem, focus/link to it, preserve input. Blank and unknown remain distinguishable. |
| No matches | Show filters and Clear filters; no suggestion that the whole queue is empty. |
| Permission changed | Reauthorise, clear sensitive data and previews; do not expose prior cached content under the new identity. |
| File unavailable | Keep the evidence record and owned follow-up; never display Available/Reviewed success. |
| Outcome uncertain | Keep original operation identity and reconcile; do not offer duplicate creation. |
| Stale revision | Show exact reviewed/current revisions and differences; require renewed review. |
| Offline | Say unavailable for saving; do not imply an offline queue or persist business data locally without a separate contract. |

Use native labelled inputs, keyboard navigation, visible focus, descriptive button names, text plus colour for state, and 44px phone targets. On narrow screens, fields and side panels stack. The queue may use contained horizontal scrolling with preserved request identity, never outer-page overflow. Essential details and actions cannot rely on hover. Dialogs support Escape and restore focus. Long text wraps without hiding critical status or scope.

## 13. Worked example one

**Single machine at Synthetic Example Nursery.** Fictional request SYN-PPO-INT-000101. Sales owner Casey Hart captures a replacement potting machine enquiry: 140–200 mm containers, bark/coir media, 900 pots/hour average and 1,200 pots/hour peak customer targets. Requested output is formal quotation preparation; supply and commissioning are requested, customer electrical works are proposed as excluded from PPA scope. The customer wants the machine operational by 30 November 2026; sales requests an estimate by 18 September.

Sales captures the objective, saves the draft, and submits r01. The reviewer sees the customer’s production targets as inputs, not a machine rating. In the fixture, the necessary machine/interface evidence is recorded as reviewed and no further question blocks beginning estimating. Estimator Morgan Lee accepts r01 for the stated output and target. Further supplier suitability and issue checks still belong downstream.

**Proof:** one saved draft, one immutable submission, one estimating acceptance with owner/target; no price, quote, deal-stage change, customer message or Project record created.

## 14. Worked example two

**Connected line at Synthetic Riverbank Nursery.** Fictional request SYN-PPO-INT-000102. Sales captures a retrofit connecting pot filling, labelling and manual take-off. The customer requests 1,500 pots/hour average, 2,000 peak and 1,400 sustained through the complete line. Existing conveyor interface and responsibility for electrical connection are unresolved; a layout and container schedule are available in the scenario.

Sales can submit the brief for triage with owned unknowns. The estimating reviewer returns a question to Casey: confirm conveyor transfer height/interface and identify who supplies the electrical connection. A due date is recorded. Sales obtains a 780 mm customer measurement and a customer-electrician responsibility statement, records their sources and replies. Resubmission creates r02 with that response; r01 remains intact. The reviewer checks the response, resolves the blocking question and accepts r02. Supplier validation remains a separate technical step.

**Proof:** a returned request stays visible in the same queue; a reply alone cannot count as reviewer resolution; original submission age remains; the eventual acceptance references r02, not whichever answers are latest later.

## 15. Worked example three

**Change after acceptance at Synthetic Hillview Nursery.** Fictional request SYN-PPO-INT-000103. Accepted r01 includes manual take-off. The customer then asks for robotic placing onto trolleys.

Sales chooses Create revision, enters “Customer requests robotic placing instead of manual take-off”, selects robotics and captures the new scope. The review compares r02 to accepted r01. Robotics is Added; outfeed and scope wording are Changed; the former manual-only assumption is Removed or revised explicitly. New handling/layout/safeguarding questions appear. The estimating owner records whether affected work pauses and assigns a technical follow-up.

The preview lets the reviewer resolve the fictional technical question with an attributed review note, then accept r02. The old r01 acceptance stays visible in history. Runtime must keep the old estimate/quote unchanged and create an owned impact review; it cannot inherit approval or customer acknowledgement onto new scope.

**Proof:** changed scope cannot be accepted silently, inactive old answers remain historical, and new acceptance changes only the agreed intake basis.

## 16. Measures for the pilot

Measure before setting performance targets. Use the same potting-request cohort and distinguish first submissions from successors; exclude withdrawn cases from accepted-cycle calculations but report their count and reason. Timestamps are server-derived UTC; the interface displays Australia/Brisbane time. Business-hours adjustments require an agreed calendar later.

| Measure | Definition | Interpretation |
|---|---|---|
| Missing-information return rate | Distinct first-submitted requests returned for missing information / distinct first-submitted requests, in a defined cohort | Report denominator, output type and complexity; customer scope changes are a separate return reason. |
| Clarification rounds | Count of reviewer return events before first acceptance, per request | A batch of questions returned together is one round; replies are not additional rounds. |
| Time to accepted brief | First acceptance time minus first submission time | Report median and p90 once sample supports it; include pending age so incomplete cases are not hidden. |
| Sales capture effort | Measured active preparation time or explicitly labelled user estimate | Do not equate elapsed time between first edit and submission with working effort. |
| Change after acceptance | Successor submissions after an accepted basis, grouped by customer change, correction or source change | Helps distinguish genuine scope evolution from weak original intake. |

Recommended initial trial: review three synthetic walkthroughs, then a small approved/redacted potting cohort with sales and estimating. Establish a manual baseline, record the same measures in the trial, inspect returned questions and remove prompts that do not improve handover. No percentage saving or turnaround SLA is claimed by this design.

## 17. Bounded first implementation

**Objective:** one permitted deal can capture a potting brief, save and resume after restart, submit an exact revision, receive and answer a clarification, obtain an estimating acceptance, and propose a reviewed successor without altering the accepted original.

| Included | Deferred |
|---|---|
| Approximately 30 active groups plus evidence/notes for relevant specialist prompts | Full typed controls for the whole 107-group bank; greenhouse and berry questionnaires |
| Exact source question mapping and one published synthetic potting definition | General form builder and template publication UI |
| Shared record references, scoped queue, immutable snapshots and explicit permissions | Customer portal forms, public links, automatic customer/adviser messages |
| Readiness for agreed estimating purpose and named owner/date | Corporate approval thresholds or delegated authority not yet supplied |
| Controlled questions, responses, review and accepted-change comparison | Automatic equipment selection, pricing, engineering calculations or supplier capacity claims |
| Existing durable document adapter with synthetic evidence fixtures | Live SharePoint/MYOB integration, operational document migration |
| Explicit downstream basis contract preserving E1 originals | Automatic estimate or quote creation/refresh, delivery routing or stock reservation |

At implementation start, verify current main, changes to E1/E2, active work, migrations and permissions. Use a dedicated issue/branch and normal reviewable PR. Reconcile the overlapping E2 request/snapshot contracts before coding so two competing intake models are not introduced. The user’s current instruction invokes this design package; runtime implementation, publication and business adoption remain distinct next actions.

## 18. Acceptance obligations

| Case | Observable result | Existing parent linkage |
|---|---|---|
| IN01 Capture and restart | Partial brief, repeatable container rows, units and unknown owners survive app/database restart; saved label follows receipt | EST-01/02 |
| IN02 Conditional changes | Retrofit/robotics questions appear; hiding retains inactive answers and prompts impact review | EST-02/06 |
| IN03 Submission | Invalid/missing submission minimum gives field errors; valid submit freezes exact answers once | EST-01/03 |
| IN04 Clarification | Owned question, response and reviewer resolution remain distinct; resubmit is a new revision | EST-01/02/03 |
| IN05 Acceptance | Eligible owner, purpose, target and resolved blockers required; server rechecks exact revision | EST-01/07 |
| IN06 Change | r02 comparison preserves r01 and prior acceptance; estimates/quotes remain unchanged | EST-03/06/08 |
| IN07 Access | Cross-company/related-target denial covers queue, counts, evidence, history and receipt replay | EST-07 |
| IN08 Concurrency | Edit-versus-accept, accept-versus-withdraw and dual accept cannot accept unseen or conflicting bases | EST-03/07 |
| IN09 Retry | Repeated operation has one effect; changed payload conflicts; lost response reconciles original | EST-01/03 |
| IN10 Evidence | Missing bytes do not become Available; review remains separate; sample custody differs from file state | EST-02/08 |
| IN11 E1 preservation | Pre-existing IDs, versions, hashes, reasons, receipts and draft bytes remain unchanged after migration/restart | EST-03/08 |
| IN12 Usability | Desktop/390px/320px, keyboard, long text, empty/error/conflict and permission-change states are usable | EST-02/08 |
| IN13 Measures | Return counts, first-submission age, clarification rounds and acceptance time follow documented denominators | EST-01 |

IN labels are local design cases, not new master requirements or completed runtime tests. Preview checks and visual inspection are recorded separately in [verification](sales-estimating-intake-verification-r01.md). No database or production acceptance is claimed.

## 19. Decisions to review and handover

The concrete review choices are the compact first-pilot field set, per-purpose acceptance rules, one-active-request pilot limit, estimating reviewer/owner allocation, and how much work may continue on an accepted predecessor while a change is pending. The interactive preview makes the normal, returned and changed cases reviewable now.

Recommended next bounded step after design review: reconcile this request/acceptance slice with current E2 contracts, confirm the real actor/grant mapping, and implement the complete synthetic pilot with the acceptance cases above. Retain the other source families for later bounded extensions. No new technical selection or pricing rules are needed to prove that sales and estimating can complete a reliable handover.
