# Sales to Estimating Intake Field Map

**Document:** PPO-010-INTAKE-MAP · **Revision:** r01 · **Date:** 13 September 2026 · **Status:** Proposed for review

This mapping accounts for all 476 numbered question and attachment identifiers in the four supplied drafts, plus 10 local anchors for unnumbered tables and sections. It is a semantic design map, not an importer or production database schema. Source keys are namespaced by document.

The two potting forms share one answer set. Greenhouse and berry specialist questions remain individually traceable for later work. Reusable shared concepts do not automatically make their specialist questionnaires part of the pilot.

## Source reconciliation

| Source | Numbered items | SHA256 |
|---|---:|---|
| POTTING_V3 — PP-INTK-AUTO-Potting-Line-Customer-Intake-Form_v3-0.docx | 117 | 63d324b8f5ebbe76e459eff2149bbd44ad4d9280293b353626722fb949045855 |
| GREENHOUSE_V12 — PPA-COM-FRM-002_Commercial-Greenhouse-Project-Intake-Form_v1_2_Professional-Visual-Polish.docx | 162 | 3d1e7b6b4dc5fb7c563fb8c8cab1547ef18668798c328f9faf0afd0a061101f3 |
| BERRY_FILENAME_V12 — PPA-COM-FRM-003_Commercial-Berry-Systems_v1_2.docx | 107 | 3facccef32a969d240412cadda7cf96a43b666224d3d44caf5e1496efef8f2f9 |
| JAVO_DRAFT — PPA-TPL-004_Form-Javo.docx | 90 | f829eeb06601726617d808b31e3b3e8c5ff9bd98f8fe5636f8857fe75b584878 |

The Javo file is named PPA-TPL-004 but identifies itself as PPA-COM-FRM-014, version 0.1, dated 3 July 2026. Potting v3 identifies itself as PP-INTK-AUTO-CUST-001, June 2026. Berry filename v1_2 contains Version 1.0 and stray checklist placeholders; Greenhouse identifies Version 1.2. None is treated as issued or as overriding the user’s current instruction. Contact placeholders and boilerplate are not adopted operational policy.

## Canonical field groups

A field group can contain multiple atomic values. The repeatable structures below preserve dimensions, units, responsibilities and provenance; they must not be reduced to a single unstructured answer during implementation. Unknown is never zero, No or confirmed.

| Key | Type | Owner | Placement / structure |
|---|---|---|
| `access_dimensions` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `additional_notes` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `additives` | ChoiceSet | Estimating intake; sales capture | Relevant detail on expansion.  |
| `adviser_contact_permission` | AttributedStatement | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `advisers` | RepeatableRecord | Estimating intake; sales capture | Later shared extension; retain source mapping. row_id; role; person_id or attributed unlinked contact proposal; company; involvement; contact_permission Yes/No/ConfirmFirst/NotRecorded; purpose; recorded_by; recorded_at. |
| `agreed_target_date` | TextOrAttributedUnknown | Estimating reviewer | Relevant detail on expansion.  |
| `alarm_contacts` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `approvals_context` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `assumptions` | RepeatableRecord | Estimating intake; sales capture | Initial brief. row_id; statement; affected_scope; basis; owner_id; due_date_or_reason; disposition Proposed/ReviewedForPurpose/Rejected/Resolved; reviewer; purpose; source_refs. |
| `average_rate` | QuantityWithUnitAndBasis | Estimating intake; sales capture | Conditional readiness detail.  |
| `backup_power` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `bare_root` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `brand_exclusions` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `brand_preference` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `budget_context` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `buffering` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `build_scope` | Choice | Estimating intake; sales capture | Initial brief.  |
| `change_reason` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `changeover` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `compaction` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `completed_at` | AttributedStatement | Estimating intake; sales capture | Relevant detail on expansion.  |
| `completed_by` | AttributedStatement | Estimating intake; sales capture | Relevant detail on expansion.  |
| `compressed_air` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `contact_id` | SharedRecordReference | Shared platform | Initial brief.  |
| `contact_method` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `contact_timing` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `containers` | RepeatableRecord | Estimating intake; sales capture | Initial brief. row_id; type; diameter_min_mm; diameter_max_mm; height_mm; volume_min_l; volume_max_l; material; rigidity; rim_profile; nesting; size_band; evidence_refs. Unknown attributes stay unset. Convert declared cm to mm with original retained. |
| `controls_intent` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `customer_id` | SharedRecordReference | Shared platform | Initial brief.  |
| `customer_questions` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `dibble` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `dosing_requirements` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `electrical_capacity` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `electrical_supply` | TextOrAttributedUnknown | Estimating intake; sales capture | Conditional readiness detail.  |
| `environment` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `estimating_owner_id` | TextOrAttributedUnknown | Estimating reviewer | Relevant detail on expansion.  |
| `evidence` | EvidenceRegister | Estimating intake; sales capture | Relevant detail on expansion.  |
| `exclusions` | TextOrAttributedUnknown | Estimating intake; sales capture | Initial brief.  |
| `existing_equipment` | RepeatableRecord | Estimating intake; sales capture | Conditional readiness detail. row_id; existing_equipment_id if known; brand; model; age_or_year; condition; function; disposition Reuse/Replace/Interface/Remove/Unknown; interface_notes; evidence_refs. |
| `fill_quality` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `finishing` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `floor_constraints` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `footprint` | TextOrAttributedUnknown | Estimating intake; sales capture | Conditional readiness detail.  |
| `fulfilment_scope` | ChoiceSet | Estimating intake; sales capture | Initial brief.  |
| `funding_status` | Choice | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `handling_constraints` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `infeed` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `information_acknowledgement` | AttributedStatement | Estimating intake; sales capture | Relevant detail on expansion.  |
| `information_authority` | AttributedStatement | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `installation_context` | Choice | Estimating intake; sales capture | Initial brief.  |
| `integration_intent` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `interface_requirements` | TextOrAttributedUnknown | Estimating intake; sales capture | Conditional readiness detail.  |
| `internal_transport` | ChoiceSet | Estimating intake; sales capture | Relevant detail on expansion.  |
| `internet` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `labour_baseline` | RepeatableRecord | Estimating intake; sales capture | Relevant detail on expansion. row_id; station; people; hours_per_day; shifts; season; target_people; source. No ROI or savings promise calculated. |
| `loading_method` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `machine_preference` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `maintenance_access` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_behaviour` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_daily_volume` | QuantityWithUnitAndBasis | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_density` | QuantityWithUnitAndBasis | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_feed` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_moisture` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_sensitivity` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_storage` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `media_supply` | ChoiceSet | Estimating intake; sales capture | Initial brief.  |
| `media_types` | ChoiceSet | Estimating intake; sales capture | Initial brief.  |
| `metering` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `mobility` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `operating_pattern` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `operational_date` | DateWithCertainty | Estimating intake; sales capture | Initial brief.  |
| `operational_during_install` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `operations` | ChoiceSet | Estimating intake; sales capture | Initial brief.  |
| `operator_context` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `options_requested` | RepeatableRecord | Estimating intake; sales capture | Later shared extension; retain source mapping. row_id; request_note; relationship Alternative/Additive/Unknown; scope_refs; decision_owner. Capture intent; no commercial-option engine in the first slice. |
| `outcome_summary` | TextOrAttributedUnknown | Estimating intake; sales capture | Initial brief.  |
| `outfeed` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `peak_rate` | QuantityWithUnitAndBasis | Estimating intake; sales capture | Conditional readiness detail.  |
| `phases` | RepeatableRecord | Estimating intake; sales capture | Relevant detail on expansion. row_id; label; required_work; future_work; dependency_note; target_date; date_certainty. Pilot records staging intent only; separate priced alternatives deferred. |
| `physical_samples` | RepeatableRecord | Estimating intake; sales capture | Relevant detail on expansion. row_id; container_ref; status Available/CanProvide/Requested/Received/Unavailable/NotApplicable; custodian; requested_date; received_date; evidence_ref. A sample is not a file upload. |
| `placing_pattern` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `priority` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `problem_summary` | TextOrAttributedUnknown | Estimating intake; sales capture | Initial brief.  |
| `products` | RepeatableRecord | Estimating intake; sales capture | Conditional readiness detail. row_id; crop; production_stage; container_row_id; media; annual_or_seasonal_volume; volume_unit; time_basis; target_rate; rate_unit; season_notes. |
| `protected_process` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `remote_access` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `reporting` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `requested_by_date` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `requested_output_note` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `response_type` | Choice | Estimating intake; sales capture | Initial brief.  |
| `responsibilities` | RepeatableRecord | Estimating intake; sales capture | Initial brief. row_id; work_item; scope Included/Excluded/Option/Unknown; proposed_responsible_party PPA/Customer/NamedOther/Unknown; named_other_ref; confirmation_state; evidence_refs. Rows for freight, unloading, mechanical installation, electrical, civil, air, water, drainage, guarding, commissioning, training and support. |
| `robotics_intent` | Choice | Estimating intake; sales capture | Relevant detail on expansion.  |
| `safety_requirements` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `sales_owner_id` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `site_access` | TextOrAttributedUnknown | Estimating intake; sales capture | Conditional readiness detail.  |
| `site_access_requirements` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `site_hazards` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `site_id` | SharedRecordReference | Shared platform | Initial brief.  |
| `site_services` | TextOrAttributedUnknown | Estimating intake; sales capture | Later shared extension; retain source mapping.  |
| `support_expectations` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `sustained_rate` | QuantityWithUnitAndBasis | Estimating intake; sales capture | Conditional readiness detail.  |
| `timing_constraints` | TextOrAttributedUnknown | Estimating intake; sales capture | Initial brief.  |
| `traceability` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `trays` | RepeatableRecord | Estimating intake; sales capture | Relevant detail on expansion. row_id; type; length_mm; width_mm; cells; layout; evidence_refs. |
| `unloading` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `waste_handling` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |
| `water_drainage` | TextOrAttributedUnknown | Estimating intake; sales capture | Relevant detail on expansion.  |

## POTTING_V3

| Source question | Original label | PPO target | Disposition |
|---|---|---|---|
| MV01 | Business / trading name | `customer_id` | Pilot consolidation |
| MV02 | Project / site location | `site_id` | Pilot consolidation |
| MV03 | Main site contact | `contact_id` | Pilot consolidation |
| MV04 | What would you like Powerplants to quote? | `build_scope` | Pilot consolidation |
| MV05 | Is this greenfield or integration with existing equipment? | `installation_context` | Pilot consolidation |
| MV06 | Operations in scope | `operations` | Pilot consolidation |
| MV07 | Average and peak throughput target | `average_rate`, `peak_rate` | Pilot consolidation |
| MV08 | Main containers / pot sizes | `containers` | Pilot consolidation |
| MV09 | Media / substrate type and supply format | `media_types`, `media_supply` | Pilot consolidation |
| MV10 | Timing requirement | `operational_date`, `timing_constraints` | Pilot consolidation |
| ATT01 | Line layout / floor plan / aerial | `evidence.layout` | Pilot consolidation |
| ATT02 | Existing machine list and brands | `evidence.equipment` | Pilot consolidation |
| ATT03 | Media / substrate specification | `evidence.media` | Pilot consolidation |
| ATT04 | Representative pot/container list | `evidence.containers` | Pilot consolidation |
| ATT05 | Tray standards, if applicable | `evidence.trays` | Pilot consolidation |
| ATT06 | Electrical supply details / single-line | `evidence.electrical` | Pilot consolidation |
| ATT07 | Throughput / production targets | `evidence.production` | Pilot consolidation |
| ATT08 | Photos/video of existing line/site | `evidence.photos` | Pilot consolidation |
| ATT09 | Container/pot samples | `physical_samples` | Pilot consolidation |
| ATT10 | Site access/unloading photos | `evidence.access` | Pilot consolidation |
| A01 | Business / trading name | `customer_id` | Pilot consolidation |
| A02 | Project / site name | `site_id` | Pilot consolidation |
| A03 | Site address / region | `site_id` | Pilot consolidation |
| A04 | Site contact name | `contact_id` | Pilot consolidation |
| A05 | Contact role / position | `contact_id` | Pilot consolidation |
| A06 | Contact phone | `contact_id` | Pilot consolidation |
| A07 | Contact email | `contact_id` | Pilot consolidation |
| A08 | Preferred contact method | `contact_method` | Pilot consolidation |
| A09 | When do you need the line operational? | `operational_date` | Pilot consolidation |
| A10 | Any critical operational, season, grant or stage-one date? | `timing_constraints` | Pilot consolidation |
| B01 | What would you like Powerplants to quote? | `fulfilment_scope`, `response_type` | Pilot consolidation |
| B02 | Preferred delivery model | `fulfilment_scope`, `phases` | Pilot consolidation |
| B03 | Build scope | `build_scope` | Pilot consolidation |
| B04 | Project stage | `response_type`, `funding_status` | Pilot consolidation |
| B05 | Approved budget range or investment band | `budget_context` | Pilot consolidation |
| B06 | Priority trade-off | `priority` | Pilot consolidation |
| B07 | Who is expected to complete electrical works? | `responsibilities.electrical` | Pilot consolidation |
| B08 | Who is expected to complete civil works? | `responsibilities.civil` | Pilot consolidation |
| B09 | Required warranty / after-sales service level | `support_expectations` | Pilot consolidation |
| C01 | Greenfield line or integrating with existing equipment? | `installation_context` | Pilot consolidation |
| C02 | If integrating: existing machines / brands to interface with | `existing_equipment` | Pilot consolidation |
| C03 | Are any existing conveyors, robots, buffers or controls to be reused? | `existing_equipment` | Pilot consolidation |
| C04 | Does the existing line need to remain operational during installation? | `operational_during_install` | Pilot consolidation |
| C05 | Known interface or retrofit concerns | `interface_requirements` | Pilot consolidation |
| D01 | Which operations are in scope on this line? | `operations` | Pilot consolidation |
| D02 | Which step is the current bottleneck or highest labour cost? | `problem_summary` | Pilot consolidation |
| D03 | Current number of operators by station | `labour_baseline` | Pilot consolidation |
| D04 | Main automation outcome required | `outcome_summary` | Pilot consolidation |
| E01 | Throughput at the potting head - average | `average_rate` | Pilot consolidation |
| E02 | Throughput at the potting head - peak | `peak_rate` | Pilot consolidation |
| E03 | Required sustained throughput after downstream bottlenecks are considered | `sustained_rate` | Pilot consolidation |
| E04 | Operating pattern | `operating_pattern` | Pilot consolidation |
| E05 | Primary products | `products` | Pilot consolidation |
| E06 | Main products to be potted | `products` | Pilot consolidation |
| F01 | Container types in scope | `containers` | Pilot consolidation |
| F02 | Pot diameter range - smallest to largest | `containers` | Pilot consolidation |
| F03 | Pot volume range, if known | `containers` | Pilot consolidation |
| F04 | Distinct size bands that must run on this line | `containers` | Pilot consolidation |
| F05 | Pot shape / taper / rim-lip profile | `containers` | Pilot consolidation |
| F06 | Pot material and rigidity | `containers` | Pilot consolidation |
| F07 | Nesting / stacking behaviour and supply format | `containers` | Pilot consolidation |
| F08 | Pot / tray de-stacker or dispenser wanted? | `operations` | Pilot consolidation |
| F09 | Container samples available for testing? | `physical_samples` | Pilot consolidation |
| F10 | Changeover frequency and acceptable changeover time | `changeover` | Pilot consolidation |
| G01 | Media type(s) / blend in use | `media_types` | Pilot consolidation |
| G02 | Media supply format | `media_supply` | Pilot consolidation |
| G03 | Media storage / buffering present or needed? | `media_storage` | Pilot consolidation |
| G04 | Feed method to the potting hopper | `media_feed` | Pilot consolidation |
| G05 | Bulk-density range, if known | `media_density` | Pilot consolidation |
| G06 | How structure-sensitive is the media? | `media_sensitivity` | Pilot consolidation |
| G07 | Target moisture at potting; any pre-wetting / conditioning? | `media_moisture` | Pilot consolidation |
| G08 | Any bridging, clods or fibre issues at the hopper? | `media_behaviour` | Pilot consolidation |
| G09 | On-line additive dosing required? | `additives` | Pilot consolidation |
| G10 | Dosing accuracy needed and number of recipes | `dosing_requirements` | Pilot consolidation |
| G11 | Daily media volume - average and peak, if known | `media_daily_volume` | Pilot consolidation |
| H01 | Operations at the potting head | `operations` | Pilot consolidation |
| H02 | Required fill level / accuracy | `fill_quality` | Pilot consolidation |
| H03 | Firming / compaction - any crop limits? | `compaction` | Pilot consolidation |
| H04 | Drill / dibble - depth, diameter and centring tolerance | `dibble` | Pilot consolidation |
| H05 | Bare-root handling - any form / size constraints? | `bare_root` | Pilot consolidation |
| H06 | Is per-pot soil metering precision needed? | `metering` | Pilot consolidation |
| H07 | Topping / cover layer required? | `finishing` | Pilot consolidation |
| H08 | In-line labelling / barcoding / traceability at potting? | `traceability` | Pilot consolidation |
| I01 | Infeed - pot / tray supply and media point | `infeed` | Pilot consolidation |
| I02 | Outfeed targets | `outfeed` | Pilot consolidation |
| I03 | Placing / take-off automation wanted? | `robotics_intent` | Pilot consolidation |
| I04 | Plant height / fragility limits for pick-and-place | `handling_constraints` | Pilot consolidation |
| I05 | Spacing pattern / density to be achieved by placing robots | `placing_pattern` | Pilot consolidation |
| I06 | Existing transport / robots / benching to interface with (+ brands) | `existing_equipment`, `interface_requirements` | Pilot consolidation |
| I07 | Buffering required between steps? | `buffering` | Pilot consolidation |
| I08 | Available footprint for the line and clear height | `footprint` | Pilot consolidation |
| I09 | Internal transport equipment used | `internal_transport` | Pilot consolidation |
| J01 | Power available at the line | `electrical_supply` | Pilot consolidation |
| J02 | Electrical capacity near proposed line location | `electrical_capacity` | Pilot consolidation |
| J03 | Compressed air available / required? | `compressed_air` | Pilot consolidation |
| J04 | Water and drainage at the line | `water_drainage` | Pilot consolidation |
| J05 | Dust / media-spill and respirable-silica controls | `site_hazards` | Pilot consolidation |
| J06 | Ambient conditions at the line | `environment` | Pilot consolidation |
| J07 | Waste / reject handling | `waste_handling` | Pilot consolidation |
| J08 | Machine mobility / relocatability required? | `mobility` | Pilot consolidation |
| J09 | Known site-access constraints? | `site_access` | Pilot consolidation |
| J10 | Narrowest door, gate or aisle on the delivery route | `access_dimensions` | Pilot consolidation |
| J11 | Unloading equipment available on site | `unloading` | Pilot consolidation |
| J12 | Floor load rating where heavy fillers / bunkers sit, if known | `floor_constraints` | Pilot consolidation |
| K01 | Do you want PLC-equipped machine(s)? | `controls_intent` | Pilot consolidation |
| K02 | Live beats / OEE monitoring wanted? | `reporting` | Pilot consolidation |
| K03 | Remote portal / mobile-app access wanted? | `remote_access` | Pilot consolidation |
| K04 | Single-HMI line control and ERP / order-system integration? | `integration_intent` | Pilot consolidation |
| K05 | Machine-safety expectations | `safety_requirements` | Pilot consolidation |
| K06 | Commissioning, training, spares holding and service response | `support_expectations` | Pilot consolidation |
| K07 | Potting-machine class preference | `machine_preference` | Pilot consolidation |
| K08 | Preferred or previously used equipment brands | `brand_preference` | Pilot consolidation |
| K09 | Any brand specifically ruled out, and why? | `brand_exclusions` | Pilot consolidation |
| L01 | Additional information | `additional_notes` | Pilot consolidation |
| L02 | Completed by | `completed_by` | Pilot consolidation |
| L03 | Role | `completed_by` | Pilot consolidation |
| L04 | Date completed | `completed_at` | Pilot consolidation |
| TABLE-operators | Current operators by process station | `labour_baseline` | Supplementary structure |
| TABLE-products | Main products to be potted | `products` | Supplementary structure |

## GREENHOUSE_V12

| Source question | Original label | PPO target | Disposition |
|---|---|---|---|
| A-01 | Business / trading name. | `customer_id` | Reusable shared concept |
| A-02 | Project / site name. | `site_id` | Reusable shared concept |
| A-03 | Project site address / location. | `site_id` | Reusable shared concept |
| A-04 | Site contact name. | `contact_id` | Reusable shared concept |
| A-05 | Contact role / position. | `contact_id` | Reusable shared concept |
| A-06 | Contact phone. | `contact_id` | Reusable shared concept |
| A-07 | Contact email. | `contact_id` | Reusable shared concept |
| A-08 | Preferred contact method. | `contact_method` | Reusable shared concept |
| A-09 | When do you need the greenhouse system operational? | `operational_date` | Reusable shared concept |
| A-10 | Is there a critical operational date or stage-one date? | `timing_constraints` | Reusable shared concept |
| A-11 | Is a site visit, Teams call or scoping workshop available if required? | `contact_timing` | Reusable shared concept |
| B-01 | Is this a new build, extension, upgrade, replacement or repair? | `installation_context` | Reusable shared concept |
| B-02 | What type of commercial response are you seeking? | `response_type` | Reusable shared concept |
| B-03 | What is the current project status? | `funding_status` | Reusable shared concept |
| B-04 | What is the highest project priority? | `priority` | Reusable shared concept |
| B-05 | Should the quote include good / better / best options? | `options_requested` | Reusable shared concept |
| B-06 | Are there any features that must be included in the first stage? | `phases` | Reusable shared concept |
| B-07 | Are there any features that can be priced as options or future upgrades? | `options_requested` | Reusable shared concept |
| B-08 | What would you like Powerplants to quote? | `fulfilment_scope` | Reusable shared concept |
| B-09 | Who is expected to provide civil works, earthworks, trenching, drainage, power upgrades and concrete works? | `responsibilities` | Reusable shared concept |
| B-10 | Can construction occur while the site remains operational? | `operational_during_install` | Reusable shared concept |
| B-11 | Are there seasonal restrictions, crop-cycle restrictions or blackout dates for installation? | `timing_constraints` | Reusable shared concept |
| C-01 | Is a greenhouse structure supplier or greenhouse designer engaged? | `advisers` | Reusable shared concept |
| C-02 | Structure supplier / designer contact details, if available. | `advisers` | Reusable shared concept |
| C-03 | Is an irrigation, fertigation or water-treatment designer engaged? | `advisers` | Reusable shared concept |
| C-04 | Irrigation / fertigation / water adviser contact details, if available. | `advisers` | Reusable shared concept |
| C-05 | Is an agronomist or crop consultant involved? | `advisers` | Reusable shared concept |
| C-06 | Agronomist / crop consultant contact details, if available. | `advisers` | Reusable shared concept |
| C-07 | Is a builder, civil contractor, certifier, planner, engineer or electrician involved? | `advisers` | Reusable shared concept |
| C-08 | Other adviser details and consent notes. | `advisers` | Reusable shared concept |
| C-09 | Does Powerplants have authority to contact the advisers listed above for this project? | `adviser_contact_permission` | Reusable shared concept |
| D-01 | Is there an existing greenhouse, tunnel, shadehouse or protected-cropping structure on site? | `greenhouse.d01` | Deferred specialist |
| D-02 | If there is an existing structure, is it being retained, modified, removed or extended? | `greenhouse.d02` | Deferred specialist |
| D-03 | Describe any existing structure, equipment or services that may be reused or integrated. | `existing_equipment` | Reusable shared concept |
| D-04 | Site exposure: surrounding tree lines, buildings, shading sources or wind exposure. | `greenhouse.d04` | Deferred specialist |
| D-05 | Preferred / required orientation, if known. | `greenhouse.d05` | Deferred specialist |
| D-06 | Average annual rainfall and wettest months, if known. | `greenhouse.d06` | Deferred specialist |
| D-07 | Are existing services available nearby? | `site_services` | Reusable shared concept |
| D-08 | Are there known site limitations? | `greenhouse.d08` | Deferred specialist |
| D-09 | Is the land owned or leased? | `greenhouse.d09` | Deferred specialist |
| D-10 | Known site access constraints or delivery limitations. | `site_access` | Reusable shared concept |
| E-01 | Where are you up to with the greenhouse structure choice? | `greenhouse.e01` | Deferred specialist |
| E-02 | If a structure type or supplier is selected, which one? | `greenhouse.e02` | Deferred specialist |
| E-03 | If comparing options, which types or suppliers are being compared? | `greenhouse.e03` | Deferred specialist |
| E-04 | Preferred structure class, or Powerplants to recommend. | `greenhouse.e04` | Deferred specialist |
| E-05 | Primary purpose of the structure. | `greenhouse.e05` | Deferred specialist |
| E-06 | Number of separately controlled compartments / zones. | `greenhouse.e06` | Deferred specialist |
| E-07 | Will different crops or growth stages share the structure? | `greenhouse.e07` | Deferred specialist |
| E-08 | Preferred structure supplier, if any. | `greenhouse.e08` | Deferred specialist |
| E-09 | Have quotes already been received from any supplier? | `evidence.supplier` | Reusable shared concept |
| E-10 | Any supplier or product ruled out, and why? | `brand_exclusions` | Reusable shared concept |
| E-11 | What must the structure protect against or provide? | `greenhouse.e11` | Deferred specialist |
| E-12 | Single most important outcome from the structure. | `outcome_summary` | Reusable shared concept |
| F-01 | Confirm proposed footprint / area. | `greenhouse.f01` | Deferred specialist |
| F-02 | Confirm overall width x length. | `greenhouse.f02` | Deferred specialist |
| F-03 | Confirm proposed gutter / eave height and ridge height. | `greenhouse.f03` | Deferred specialist |
| F-04 | Bay width / span / post spacing preference, or Powerplants to recommend. | `greenhouse.f04` | Deferred specialist |
| F-05 | Number of spans or bays, if known. | `greenhouse.f05` | Deferred specialist |
| F-06 | Required clear internal working height under gutters, screens or services. | `greenhouse.f06` | Deferred specialist |
| F-07 | Roof vent count and preferred roof vent type. | `greenhouse.f07` | Deferred specialist |
| F-08 | Is side ventilation required? | `greenhouse.f08` | Deferred specialist |
| F-09 | Is insect screening required on vents? | `greenhouse.f09` | Deferred specialist |
| F-10 | Is future expansion intended? | `greenhouse.f10` | Deferred specialist |
| F-11 | Covering - glass option. | `greenhouse.f11` | Deferred specialist |
| F-12 | Covering - polycarbonate option. | `greenhouse.f12` | Deferred specialist |
| F-13 | Covering - poly film properties. | `greenhouse.f13` | Deferred specialist |
| F-14 | Covering - shadecloth details. | `greenhouse.f14` | Deferred specialist |
| F-15 | Covering - netting purpose. | `greenhouse.f15` | Deferred specialist |
| F-16 | Must covers be replaceable or upgradeable, or is price sensitivity on recovering important? | `greenhouse.f16` | Deferred specialist |
| F-17 | Should the structure be permanent, relocatable or temporary? | `greenhouse.f17` | Deferred specialist |
| F-18 | Aesthetic, branding or visibility requirements. | `greenhouse.f18` | Deferred specialist |
| G-01 | What will be grown? | `greenhouse.g01` | Deferred specialist |
| G-02 | Production form. | `greenhouse.g02` | Deferred specialist |
| G-03 | Growing method. | `greenhouse.g03` | Deferred specialist |
| G-04 | Growing media used. | `media_types` | Reusable shared concept |
| G-05 | Typical pot, container, tray or plant spacing details. | `greenhouse.g05` | Deferred specialist |
| G-06 | Expected throughput. | `greenhouse.g06` | Deferred specialist |
| G-07 | Crop cycle length and turns per year. | `greenhouse.g07` | Deferred specialist |
| G-08 | Seasonality - peak production or dispatch months. | `timing_constraints` | Reusable shared concept |
| G-09 | Target quality attributes. | `greenhouse.g09` | Deferred specialist |
| G-10 | Problems this greenhouse must solve. | `problem_summary` | Reusable shared concept |
| G-11 | Crops needing special conditions. | `greenhouse.g11` | Deferred specialist |
| G-12 | Is a crop production plan, agronomist plan or recipe available? | `greenhouse.g12` | Deferred specialist |
| H-01 | Target air-temperature ranges by stage. | `greenhouse.h01` | Deferred specialist |
| H-02 | Target RH or VPD strategy, if known. | `greenhouse.h02` | Deferred specialist |
| H-03 | Is active humidity management required? | `greenhouse.h03` | Deferred specialist |
| H-04 | Light strategy. | `greenhouse.h04` | Deferred specialist |
| H-05 | Is CO2 enrichment wanted or required? | `greenhouse.h05` | Deferred specialist |
| H-06 | Crop-steering ambition. | `greenhouse.h06` | Deferred specialist |
| H-07 | Are there conflicting climate needs that justify separate zones? | `greenhouse.h07` | Deferred specialist |
| H-08 | Acceptable climate uniformity / tolerance across the house. | `greenhouse.h08` | Deferred specialist |
| H-09 | Are target setpoints, crop recipes or an agronomist plan available? | `greenhouse.h09` | Deferred specialist |
| I-01 | Is heating required? | `greenhouse.i01` | Deferred specialist |
| I-02 | Preferred heat source. | `greenhouse.i02` | Deferred specialist |
| I-03 | Existing heating plant to reuse or integrate. | `greenhouse.i03` | Deferred specialist |
| I-04 | Heat distribution preference. | `greenhouse.i04` | Deferred specialist |
| I-05 | Is a buffer or storage tank acceptable or wanted? | `greenhouse.i05` | Deferred specialist |
| I-06 | Energy-recovery interest. | `greenhouse.i06` | Deferred specialist |
| I-07 | Is an energy / thermal screen wanted to reduce heating demand? | `greenhouse.i07` | Deferred specialist |
| I-08 | Known tariffs, gas availability or electrical supply limits. | `greenhouse.i08` | Deferred specialist |
| I-09 | Running-cost or carbon goals. | `greenhouse.i09` | Deferred specialist |
| J-01 | Is active cooling required? | `greenhouse.j01` | Deferred specialist |
| J-02 | Preferred cooling or ventilation method. | `greenhouse.j02` | Deferred specialist |
| J-03 | Known summer heat, airflow or humidity problems. | `greenhouse.j03` | Deferred specialist |
| J-04 | Existing cooling, fogging, fan or ventilation equipment to reuse or integrate. | `greenhouse.j04` | Deferred specialist |
| J-05 | Any specific humidity-management requirements? | `greenhouse.j05` | Deferred specialist |
| J-06 | Should cooling and humidity control be staged as base scope and optional upgrade? | `greenhouse.j06` | Deferred specialist |
| K-01 | Are screens, shading or blackout systems required? | `greenhouse.k01` | Deferred specialist |
| K-02 | Screen or shading functions required. | `greenhouse.k02` | Deferred specialist |
| K-03 | Preferred screen arrangement. | `greenhouse.k03` | Deferred specialist |
| K-04 | If blackout is required, describe timing, light-leak tolerance and crop stage. | `greenhouse.k04` | Deferred specialist |
| K-05 | Preferred screen control approach. | `greenhouse.k05` | Deferred specialist |
| L-01 | Should Powerplants include irrigation, fertigation or water-treatment scope in this greenhouse quote? | `greenhouse.l01` | Deferred specialist |
| L-02 | Irrigation method. | `greenhouse.l02` | Deferred specialist |
| L-03 | Water source(s). | `greenhouse.l03` | Deferred specialist |
| L-04 | Water storage, yield, reliability or allocation notes. | `greenhouse.l04` | Deferred specialist |
| L-05 | Recent water analysis available? | `greenhouse.l05` | Deferred specialist |
| L-06 | Existing or planned water treatment / filtration. | `greenhouse.l06` | Deferred specialist |
| L-07 | Run-to-waste, drain capture, recirculation or reuse strategy. | `greenhouse.l07` | Deferred specialist |
| L-08 | Fertigation / dosing required? | `greenhouse.l08` | Deferred specialist |
| L-09 | Existing irrigation, pump, filter, valve, dosing or drain equipment to reuse or integrate. | `greenhouse.l09` | Deferred specialist |
| L-10 | Recipes, stock tanks, acid/base/peroxide dosing or dosing-channel notes. | `greenhouse.l10` | Deferred specialist |
| L-11 | Drain measurement, drain storage, discharge or recycling requirements. | `greenhouse.l11` | Deferred specialist |
| M-01 | Is supplementary lighting required? | `greenhouse.m01` | Deferred specialist |
| M-02 | Lighting type preference. | `greenhouse.m02` | Deferred specialist |
| M-03 | Lighting objective or target. | `greenhouse.m03` | Deferred specialist |
| M-04 | Existing lighting equipment to reuse or integrate. | `greenhouse.m04` | Deferred specialist |
| M-05 | Is CO2 enrichment required as part of the quote? | `greenhouse.m05` | Deferred specialist |
| M-06 | CO2 source or preference, if known. | `greenhouse.m06` | Deferred specialist |
| M-07 | CO2 safety, gas storage, interlock or ventilation considerations. | `greenhouse.m07` | Deferred specialist |
| N-01 | Is benching, growing-table or internal handling scope required? | `greenhouse.n01` | Deferred specialist |
| N-02 | Benching or growing-table type. | `greenhouse.n02` | Deferred specialist |
| N-03 | Flooring or drainage surface. | `greenhouse.n03` | Deferred specialist |
| N-04 | Internal handling, access or aisle requirements. | `greenhouse.n04` | Deferred specialist |
| N-05 | Any spacing, headroom, service clearance or maintenance-access constraints. | `greenhouse.n05` | Deferred specialist |
| O-01 | Level of environmental control sought. | `greenhouse.o01` | Deferred specialist |
| O-02 | Required controlled functions. | `greenhouse.o02` | Deferred specialist |
| O-03 | Existing controller, climate computer, BMS or Priva equipment. | `existing_equipment` | Reusable shared concept |
| O-04 | Preferred control platform, if any. | `greenhouse.o04` | Deferred specialist |
| O-05 | Who will operate the greenhouse system day to day? | `operator_context` | Reusable shared concept |
| O-06 | Operator experience level with greenhouse climate control. | `operator_context` | Reusable shared concept |
| O-07 | Is remote access required for Powerplants support? | `remote_access` | Reusable shared concept |
| O-08 | Who should receive alarms after hours? | `alarm_contacts` | Reusable shared concept |
| O-09 | Is internet connectivity available and reliable at the site? | `internet` | Reusable shared concept |
| O-10 | Monitoring, sensing or reporting expectations. | `reporting` | Reusable shared concept |
| O-11 | Third-party integrations required. | `integration_intent` | Reusable shared concept |
| P-01 | Can construction occur while the site remains operational? | `operational_during_install` | Reusable shared concept |
| P-02 | Seasonal restrictions, crop-cycle restrictions or blackout dates. | `timing_constraints` | Reusable shared concept |
| P-03 | Who is expected to provide civil works, earthworks, trenching, drainage, power upgrades and concrete works? | `responsibilities` | Reusable shared concept |
| P-04 | Truck, crane, forklift, unloading and laydown constraints. | `site_access`, `unloading` | Reusable shared concept |
| P-05 | Site access, inductions, permits or work-hour restrictions. | `site_access_requirements` | Reusable shared concept |
| P-06 | Approvals status. | `approvals_context` | Reusable shared concept |
| P-07 | Fire safety, emergency egress, gas/CO2 storage or chemical-store considerations. | `safety_requirements` | Reusable shared concept |
| P-08 | Market-access, export, biosecurity or quarantine requirements affecting the build. | `site_access_requirements` | Reusable shared concept |
| P-09 | Responsibility boundaries or exclusions that must be recognised in the quotation. | `exclusions`, `responsibilities` | Reusable shared concept |
| Q-01 | Additional information, preferences, constraints or concerns. | `additional_notes` | Reusable shared concept |
| Q-02 | Questions you would like Powerplants to answer during follow-up. | `customer_questions` | Reusable shared concept |
| Z-01 | Completed by. | `completed_by` | Reusable shared concept |
| Z-02 | Role / position. | `completed_by` | Reusable shared concept |
| Z-03 | Date completed. | `completed_at` | Reusable shared concept |
| Z-04 | Do you have authority to provide this information on behalf of the customer / business? | `information_authority` | Reusable shared concept |
| Z-05 | Can Powerplants use the information provided to prepare quotation assumptions and contact listed advisers where authorised? | `information_authority`, `adviser_contact_permission` | Reusable shared concept |
| ATT-checklist | Unnumbered attachment checklist | `evidence` | Supplementary structure |

## BERRY_FILENAME_V12

| Source question | Original label | PPO target | Disposition |
|---|---|---|---|
| A-01 | Business / trading name. | `customer_id` | Reusable shared concept |
| A-02 | Project / site name. | `site_id` | Reusable shared concept |
| A-03 | Site contact name. | `contact_id` | Reusable shared concept |
| A-04 | Contact role / position. | `contact_id` | Reusable shared concept |
| A-05 | Contact phone. | `contact_id` | Reusable shared concept |
| A-06 | Contact email. | `contact_id` | Reusable shared concept |
| A-07 | Preferred contact method. | `contact_method` | Reusable shared concept |
| A-08 | Is this a new build, an expansion, or a retrofit / upgrade? | `installation_context` | Reusable shared concept |
| A-09 | Any existing Priva equipment on site? | `existing_equipment` | Reusable shared concept |
| A-10 | For an expansion / retrofit: which existing irrigation equipment will be kept or integrated? | `existing_equipment` | Reusable shared concept |
| A-11 | When do you need the system operational? | `operational_date` | Reusable shared concept |
| A-12 | Is there a critical operational date or stage-one date? | `timing_constraints` | Reusable shared concept |
| B-01 | What would you like Powerplants to quote? | `fulfilment_scope` | Reusable shared concept |
| B-02 | Who is expected to complete electrical works? | `responsibilities.electrical` | Reusable shared concept |
| B-03 | Who is expected to complete civil works? | `responsibilities.civil` | Reusable shared concept |
| B-04 | Is the project likely to be staged? | `phases` | Reusable shared concept |
| B-05 | Are there known site access constraints? | `site_access` | Reusable shared concept |
| C-01 | Is an irrigation contractor or designer engaged? | `advisers` | Reusable shared concept |
| C-02 | Company / business name. | `advisers` | Reusable shared concept |
| C-03 | Contact name. | `advisers` | Reusable shared concept |
| C-04 | Phone. | `advisers` | Reusable shared concept |
| C-05 | Email. | `advisers` | Reusable shared concept |
| C-06 | Their involvement. | `advisers` | Reusable shared concept |
| C-07 | May we contact them directly about this project? | `adviser_contact_permission` | Reusable shared concept |
| C-08 | Is an agronomist or crop consultant engaged? | `advisers` | Reusable shared concept |
| C-09 | Company / business name. | `advisers` | Reusable shared concept |
| C-10 | Contact name. | `advisers` | Reusable shared concept |
| C-11 | Phone. | `advisers` | Reusable shared concept |
| C-12 | Email. | `advisers` | Reusable shared concept |
| C-13 | Their involvement. | `advisers` | Reusable shared concept |
| C-14 | May we contact them directly about this project? | `adviser_contact_permission` | Reusable shared concept |
| D-01 | Site address / location. | `site_id` | Reusable shared concept |
| D-02 | Region / local council area. | `site_id` | Reusable shared concept |
| D-03 | Total cropping area to be serviced. | `berry.d03` | Deferred specialist |
| D-04 | Number of separate growing structures or areas. | `berry.d04` | Deferred specialist |
| D-05 | Structure type. | `berry.d05` | Deferred specialist |
| D-06 | Is there a dosing room / shed (existing or planned) for the equipment? | `berry.d06` | Deferred specialist |
| D-07 | Approximate distance from dosing room to the furthest irrigation block. | `berry.d07` | Deferred specialist |
| D-08 | Reliable internet or mobile (4G / 5G) coverage at the dosing room? | `internet` | Reusable shared concept |
| D-09 | Electrical supply available at the dosing room. | `electrical_supply` | Reusable shared concept |
| D-10 | Backup power / generator available? | `backup_power` | Reusable shared concept |
| D-11 | Frost risk at the site. | `berry.d11` | Deferred specialist |
| E-01 | Will drain (run-off) water be run to waste, or captured and recirculated / reused? | `berry.e01` | Deferred specialist |
| E-02 | Target feed EC range, if known. | `berry.e02` | Deferred specialist |
| E-03 | Target feed pH range, if known. | `berry.e03` | Deferred specialist |
| E-04 | Target drain percentage, if known. | `berry.e04` | Deferred specialist |
| E-05 | Crop stage at commissioning, if known. | `berry.e05` | Deferred specialist |
| E-06 | Is a nutrition plan or agronomist recipe available? | `evidence.agronomy` | Reusable shared concept |
| F-01 | Which water source(s) will feed the system? | `berry.f01` | Deferred specialist |
| F-02 | Water storage type. | `berry.f02` | Deferred specialist |
| F-03 | Usable storage volume. | `berry.f03` | Deferred specialist |
| F-04 | Source supply rate / yield, if known. | `berry.f04` | Deferred specialist |
| F-05 | Any seasonal source reliability limitations? | `berry.f05` | Deferred specialist |
| F-06 | Licensed water allocation (annual), if applicable. | `berry.f06` | Deferred specialist |
| F-07 | Approximate source water temperature, if known. | `berry.f07` | Deferred specialist |
| F-08 | Do you have a recent water analysis / lab test? | `evidence.water_analysis` | Reusable shared concept |
| F-09 | Date of most recent water analysis, if known. | `evidence.water_analysis` | Reusable shared concept |
| F-10 | Water-analysis lab / source, if known. | `evidence.water_analysis` | Reusable shared concept |
| G-01 | Do you disinfect your water now, or plan to? | `berry.g01` | Deferred specialist |
| G-02 | Existing disinfection method or equipment, if any. | `berry.g02` | Deferred specialist |
| G-03 | Is reverse osmosis (RO) in use, planned or advised? | `berry.g03` | Deferred specialist |
| G-04 | Existing or planned pre-filtration. | `berry.g04` | Deferred specialist |
| G-05 | Number of filters that need automatic backwash control, if known. | `berry.g05` | Deferred specialist |
| H-01 | Irrigation method. | `berry.h01` | Deferred specialist |
| H-02 | Number of irrigation blocks / zones. | `berry.h02` | Deferred specialist |
| H-03 | Typical block size. | `berry.h03` | Deferred specialist |
| H-04 | Approximate total number of irrigation valves. | `berry.h04` | Deferred specialist |
| H-05 | Peak mainline flow required, if known. | `berry.h05` | Deferred specialist |
| H-06 | How many irrigation zones run at the same time (peak)? | `berry.h06` | Deferred specialist |
| H-07 | Available irrigation window per day. | `berry.h07` | Deferred specialist |
| H-08 | Peak mainline pressure required, if known. | `berry.h08` | Deferred specialist |
| H-09 | Available supply pressure, if known. | `berry.h09` | Deferred specialist |
| H-10 | Elevation rise to the highest block, if known. | `berry.h10` | Deferred specialist |
| H-11 | Dripper / emitter type. | `berry.h11` | Deferred specialist |
| H-12 | Dripper flow rate. | `berry.h12` | Deferred specialist |
| H-13 | Drippers per plant (or per m²). | `berry.h13` | Deferred specialist |
| H-14 | Plant density, approximate. | `berry.h14` | Deferred specialist |
| I-01 | Mixing principle. | `berry.i01` | Deferred specialist |
| I-02 | Number of fertiliser stock solutions / tanks. | `berry.i02` | Deferred specialist |
| I-03 | Number of distinct nutrient recipes / feeds required. | `berry.i03` | Deferred specialist |
| I-04 | Is acid dosing required? | `berry.i04` | Deferred specialist |
| I-05 | If acid is used, which type? | `berry.i05` | Deferred specialist |
| I-06 | Is base / alkali dosing required, if advised? | `berry.i06` | Deferred specialist |
| I-07 | Any peroxide / anti-block dosing? | `berry.i07` | Deferred specialist |
| I-08 | Existing fertigation equipment to be kept or integrated, if relevant. | `existing_equipment` | Reusable shared concept |
| J-01 | How should irrigation be started or triggered? | `berry.j01` | Deferred specialist |
| J-02 | How many separate irrigation programs (start strategies) will you run, roughly? | `berry.j02` | Deferred specialist |
| J-03 | Do you want the system to automatically adjust irrigation using substrate moisture data? | `berry.j03` | Deferred specialist |
| J-04 | Do you want the system to automatically adjust irrigation using plant and/or substrate weight data? | `berry.j04` | Deferred specialist |
| J-05 | Do you want remote monitoring or operation, subject to internet connection and Priva configuration requirements? | `remote_access` | Reusable shared concept |
| J-06 | Will the system span multiple separate locations or control points? | `berry.j06` | Deferred specialist |
| J-07 | Integrate with an existing climate computer or BMS? | `integration_intent` | Reusable shared concept |
| J-08 | Reporting / data needs. | `reporting` | Reusable shared concept |
| J-09 | Controller preference, or shall we recommend? | `berry.j09` | Deferred specialist |
| K-01 | How will drain (run-off) be captured? | `berry.k01` | Deferred specialist |
| K-02 | Do you want to measure the drain water? | `berry.k02` | Deferred specialist |
| K-03 | Number of drain measurement points, if known. | `berry.k03` | Deferred specialist |
| K-04 | Drain measurement connection - wired or wireless? | `berry.k04` | Deferred specialist |
| K-05 | If you recirculate: approximate drain storage volume. | `berry.k05` | Deferred specialist |
| L-01 | Do you require a Priva weather station? | `berry.l01` | Deferred specialist |
| L-02 | If yes, which parameters would you like to monitor? | `berry.l02` | Deferred specialist |
| L-03 | Are you interested in wireless sensing (Priva  /  Aranet)? | `berry.l03` | Deferred specialist |
| L-04 | If yes, is sensor data for monitoring only, or to actively drive irrigation / control? | `berry.l04` | Deferred specialist |
| L-05 | What would you like to monitor? | `berry.l05` | Deferred specialist |
| Z-01 | Completed by (name). | `completed_by` | Reusable shared concept |
| Z-02 | Role. | `completed_by` | Reusable shared concept |
| Z-03 | Date. | `completed_at` | Reusable shared concept |
| ATT-checklist | Unnumbered attachment checklist | `evidence` | Supplementary structure |
| TABLE-crops | Crop / Area (ha) / Growing medium / Container type | `berry.crop_schedule` | Deferred specialist |
| SECTION-M | Unnumbered additional information | `additional_notes` | Supplementary structure |

## JAVO_DRAFT

| Source question | Original label | PPO target | Disposition |
|---|---|---|---|
| ATT-01 | Site layout / floor plan / aerial markup | `evidence.layout` | Pilot consolidation |
| ATT-02 | Existing equipment list — brands, models, photos | `evidence.equipment` | Pilot consolidation |
| ATT-03 | Photos / video of current potting or containerising process | `evidence.photos` | Pilot consolidation |
| ATT-04 | Media / substrate specification or supplier data sheet | `evidence.media` | Pilot consolidation |
| ATT-05 | Pot / container / tray schedule | `evidence.containers` | Pilot consolidation |
| ATT-06 | Representative pot / container / tray samples | `physical_samples` | Pilot consolidation |
| ATT-07 | Throughput targets, labour baseline or production schedule | `evidence.production` | Pilot consolidation |
| ATT-08 | Electrical supply details / single-line diagram | `evidence.electrical` | Pilot consolidation |
| ATT-09 | Compressed-air and water / drainage service information | `evidence.services` | Pilot consolidation |
| ATT-10 | Site access / unloading route photos or notes | `evidence.access` | Pilot consolidation |
| ATT-11 | Existing controls / PLC / HMI / remote-access standards | `evidence.controls` | Pilot consolidation |
| ATT-12 | Prior quotes, layouts or supplier correspondence | `evidence.supplier` | Pilot consolidation |
| A-01 | Business / customer legal or trading name | `customer_id` | Pilot consolidation |
| A-02 | Site name and physical site address | `site_id` | Pilot consolidation |
| A-03 | Primary project contact — name, role, phone and email | `contact_id` | Pilot consolidation |
| A-04 | Preferred site-visit or call timing | `contact_timing` | Pilot consolidation |
| A-05 | Critical operational dates or seasonal windows | `timing_constraints` | Pilot consolidation |
| B-01 | What type of project is this? | `installation_context` | Pilot consolidation |
| B-02 | What would you like Powerplants to quote? | `operations`, `fulfilment_scope` | Pilot consolidation |
| B-03 | Is the requested solution a single machine, a connected line, or a staged full line? | `build_scope` | Pilot consolidation |
| B-04 | What responsibilities should Powerplants include? | `responsibilities` | Pilot consolidation |
| B-05 | Are electrical, civil, compressed-air, water or drainage works to be included in scope? | `responsibilities` | Pilot consolidation |
| B-06 | Is there a target budget range or budget-approval process? | `budget_context` | Pilot consolidation |
| B-07 | Are staged or phased options required? | `phases` | Pilot consolidation |
| C-01 | Is this a greenfield line, retrofit, upgrade or replacement? | `installation_context` | Pilot consolidation |
| C-02 | Existing machines or equipment to interface with | `existing_equipment` | Pilot consolidation |
| C-03 | Existing conveyors, robots, benching or take-off systems | `existing_equipment` | Pilot consolidation |
| C-04 | What is the main bottleneck or labour-cost driver today? | `problem_summary` | Pilot consolidation |
| C-05 | Photos, video or manuals for existing equipment | `evidence.equipment` | Pilot consolidation |
| D-01 | Which operations should the line automate? | `operations` | Pilot consolidation |
| D-02 | Which operation is most important to improve first? | `priority` | Pilot consolidation |
| D-03 | Will products be manually loaded, automatically fed, or both? | `loading_method` | Pilot consolidation |
| D-04 | Will the line need buffering or accumulation? | `buffering` | Pilot consolidation |
| D-05 | Describe any process steps that must not change. | `protected_process` | Pilot consolidation |
| E-01 | Average throughput target | `average_rate` | Pilot consolidation |
| E-02 | Peak throughput target | `peak_rate` | Pilot consolidation |
| E-03 | Sustained operating pattern | `operating_pattern` | Pilot consolidation |
| E-04 | Operating hours, shifts and seasonal peaks | `operating_pattern` | Pilot consolidation |
| E-05 | Current labour used on the process | `labour_baseline` | Pilot consolidation |
| E-06 | Product / throughput assumptions | `products` | Pilot consolidation |
| F-01 | Main crops / products to be potted or containerised | `products` | Pilot consolidation |
| F-02 | Container types in scope | `containers` | Pilot consolidation |
| F-03 | Pot / container diameter or volume range | `containers` | Pilot consolidation |
| F-04 | Container material, nesting and stacking behaviour | `containers` | Pilot consolidation |
| F-05 | Tray or carrier standards | `trays` | Pilot consolidation |
| F-06 | Changeover frequency and size-mix complexity | `changeover` | Pilot consolidation |
| F-07 | Representative pot / container / tray samples available? | `physical_samples` | Pilot consolidation |
| G-01 | Primary substrate / growing media type | `media_types` | Pilot consolidation |
| G-02 | Media supply format | `media_supply` | Pilot consolidation |
| G-03 | Media handling behaviour | `media_behaviour` | Pilot consolidation |
| G-04 | Moisture condition at filling | `media_moisture` | Pilot consolidation |
| G-05 | Additives, fertilisers or dosing materials required | `additives` | Pilot consolidation |
| G-06 | Are dosing accuracy or recipe requirements known? | `dosing_requirements` | Pilot consolidation |
| G-07 | Media storage, loading and feed method | `media_storage`, `media_feed` | Pilot consolidation |
| H-01 | Potting-head operations required | `operations` | Pilot consolidation |
| H-02 | Target fill level or fill appearance | `fill_quality` | Pilot consolidation |
| H-03 | Compaction or root-zone sensitivity | `compaction` | Pilot consolidation |
| H-04 | Drilling, dibbling or transplant-hole requirements | `dibble` | Pilot consolidation |
| H-05 | Topping, watering, labelling or finishing requirements | `finishing` | Pilot consolidation |
| H-06 | Fill-quality issues to avoid | `fill_quality` | Pilot consolidation |
| I-01 | Preferred infeed point | `infeed` | Pilot consolidation |
| I-02 | Preferred outfeed destination | `outfeed` | Pilot consolidation |
| I-03 | Available footprint and clear height | `footprint` | Pilot consolidation |
| I-04 | Required access around the line for operators and maintenance | `maintenance_access` | Pilot consolidation |
| I-05 | Buffering, handoff or accumulation needs | `buffering` | Pilot consolidation |
| I-06 | Marked layout or sketch of the available area? | `evidence.layout` | Pilot consolidation |
| J-01 | Is robotic placing or take-off being considered? | `robotics_intent` | Pilot consolidation |
| J-02 | Where should pots or plants be placed or taken off? | `outfeed` | Pilot consolidation |
| J-03 | Plant stability, height or fragility concerns | `handling_constraints` | Pilot consolidation |
| K-01 | Available electrical supply | `electrical_supply` | Pilot consolidation |
| K-02 | Compressed-air availability | `compressed_air` | Pilot consolidation |
| K-03 | Water and drainage availability | `water_drainage` | Pilot consolidation |
| K-04 | Dust, washdown, hygiene or environmental constraints | `environment`, `site_hazards` | Pilot consolidation |
| K-05 | Are floor, slab, levelness or load constraints known? | `floor_constraints` | Pilot consolidation |
| K-06 | Delivery, unloading and access constraints | `site_access`, `unloading` | Pilot consolidation |
| K-07 | Site induction, permits or contractor-access requirements | `site_access_requirements` | Pilot consolidation |
| L-01 | Controls preference | `controls_intent` | Pilot consolidation |
| L-02 | HMI, OEE, reporting or remote-access expectations | `reporting`, `remote_access` | Pilot consolidation |
| L-03 | ERP or production-system integration required? | `integration_intent` | Pilot consolidation |
| L-04 | Commissioning, operator training and spare-parts expectations | `support_expectations` | Pilot consolidation |
| M-01 | Do you have a preferred equipment supplier or brand? | `brand_preference` | Pilot consolidation |
| M-02 | Is Javo preferred, required, or one option only? | `brand_preference` | Pilot consolidation |
| M-03 | Are any brands or machine types excluded? | `brand_exclusions` | Pilot consolidation |
| M-04 | Do you want Powerplants to recommend the machine class? | `machine_preference` | Pilot consolidation |
| N-01 | Additional project information, constraints or preferences | `additional_notes` | Pilot consolidation |
| N-02 | Questions you would like Powerplants to respond to | `customer_questions` | Pilot consolidation |
| S-01 | Completed by — name and role | `completed_by` | Pilot consolidation |
| S-02 | Completion date | `completed_at` | Pilot consolidation |
| S-03 | Information accuracy and no-final-design acknowledgement | `information_acknowledgement` | Pilot consolidation |
| S-04 | Signature or authorised confirmation | `information_acknowledgement` | Pilot consolidation |
| TABLE-equipment | Existing equipment tables | `existing_equipment` | Supplementary structure |
| TABLE-labour | Current labour used on the process | `labour_baseline` | Supplementary structure |
| TABLE-products | Product throughput and crop tables | `products` | Supplementary structure |
| TABLE-containers | Container dimensions and tray standards | `containers`, `trays` | Supplementary structure |

## Import and interpretation rules

- Mapping is evidence of intent, not a licence to infer completed answers from blank templates.
- Exact original question IDs, source hash and definition revision remain alongside mapped data. All A01/A-01 collisions are resolved by source namespace.
- Mixed commercial response, fulfilment and staging questions must be split and confirmed; do not infer supply-only or budget-output intent from a single ambiguous selection.
- Throughput retains measurement point, time basis and pots/hour or trays/hour. Average, peak and required sustained output are separate. No conversion between pots and trays without a confirmed count.
- Pot dimensions in cm are converted to mm only when a numeric original and unit are explicit; retain both the original and conversion. cm and litres are never interchangeable.
- Yes/No/Unknown choices, N/A applicability and blank response remain distinct. Not sure and Powerplants to recommend create an attributed unresolved input, not a technical selection.
- Brand preference and machine class remain customer preferences; no compatibility or performance guarantee is generated.
- Information acknowledgement and adviser-contact permission do not imply order acceptance, technical approval or actual contact.
- Repeated checklist entries are not duplicate files. Evidence has its own UUID, revision, hash and availability state. Physical samples have a separate custody/status record.
- Validation counts numbered items and supplemental structures separately. Source boilerplate, navigation lists and blank response rows are retained in the originals, not counted as separate questions.
