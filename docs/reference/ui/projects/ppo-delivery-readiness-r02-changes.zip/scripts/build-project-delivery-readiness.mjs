// Rebuild the stable working HTML. Pass --issue=rNN only when freezing that review issue.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=resolve('docs/design/projects-delivery-readiness');
let html=await readFile(resolve(root,'template.html'),'utf8');
for(const [token,file] of [['FONTS','roboto.css'],['CSS','workspace.css'],['MODEL','model.js'],['APP','workspace.js']]){
  const text=await readFile(resolve(root,file),'utf8');
  if(token==='MODEL'||token==='APP')if(/<\/script/i.test(text))throw Error('Inline script contains a closing script tag.');
  html=html.replace('/*__'+token+'__*/',()=>text);
}
const working=resolve('docs/reference/ui/projects/project-delivery-readiness-and-change-control.html');
await writeFile(working,html);
const issue=process.argv.find(a=>a.startsWith('--issue'));
if(issue){
  const revision=issue.split('=')[1]||'';
  if(!/^r\d{2}$/.test(revision))throw Error('Pass --issue=rNN naming the review issue to write; never rewrite a previously received issue.');
  await writeFile(resolve('docs/reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-'+revision+'.html'),html);
}
console.log('Built '+working+' ('+Buffer.byteLength(html)+' bytes)');
