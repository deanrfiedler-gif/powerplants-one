# Projects delivery-readiness source

Stable design source for [Projects — Delivery Readiness & Change Control](../../decisions/project-delivery-readiness-design.md), review r02.

- `template.html`: semantic module frame and metadata.
- `roboto.css`: the three font faces extracted from the supplied r20 board, with only the CSS family alias changed to `PPOFont`.
- `workspace.css`: r20 tokens, module layouts and responsive/print rules.
- `model.js`: isolated synthetic model, source versions, reviews and local receipts.
- `workspace.js`: connected views, forms, source inspection, assistance and local export.

From the repository root:

```sh
node scripts/build-project-delivery-readiness.mjs
node scripts/check-project-delivery-readiness-model.mjs
PPO_DOM_MODULE=/absolute/path/to/an/installed/jsdom/lib/api.js node scripts/check-project-delivery-readiness-dom.mjs
```

The builder updates [the stable working HTML](../../reference/ui/projects/project-delivery-readiness-and-change-control.html). `--issue=rNN` also writes that review issue, for example the [r02 issue](../../reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-r02.html); never pass a revision that has already been received. The [r01 issue](../../reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-r01.html) is preserved byte-for-byte. The DOM checker reads the working HTML by default; set `PPO_REVIEW_HTML` to check a specific issue file. No runtime dependency is introduced; the DOM checker optionally reuses an existing jsdom installation and is explicitly not a browser renderer.

The [verification record](../../testing/project-delivery-readiness-review.md) records exact checks and source hashes for each issue. r02 changes trace to the [r01 audit](../../reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-audit-r01.md) and its [change record](../../reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-r02-change-record.md). The [original plan](../../reference/ui/projects/PPO-Project-Delivery-Readiness-and-Change-Control-Plan-r01.md) is preserved as an issued historical brief; its original proposed status is intentional.
