# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: quality-states.spec.ts >> P11 PT-29 all fifteen screen families show actual loading, failure, recovery and current denial
- Location: tests/browser/quality-states.spec.ts:189:1

# Error details

```
Error: SC-07: from

expect(received).toBe(expected) // Object.is equality

Expected: 1951394400000
Received: 1951653600000
```

# Page snapshot

```yaml
- generic [ref=f24e1]:
  - link "Skip to main content":
    - /url: "#main"
  - generic [ref=f24e2]:
    - navigation "Mobile navigation" [ref=f24e3]:
      - button "More" [ref=f24e4] [cursor=pointer]
    - generic [ref=f24e10]:
      - banner [ref=f24e11]:
        - link "Powerplants One home" [ref=f24e12] [cursor=pointer]:
          - /url: /
          - img "Powerplants Australia" [ref=f24e13]
        - navigation "Breadcrumb" [ref=f24e14]:
          - button "Page hierarchy" [ref=f24e15] [cursor=pointer]
          - list "Service / Schedule" [ref=f24e18]:
            - listitem [ref=f24e19]:
              - generic [ref=f24e20]: Schedule
        - generic [ref=f24e22]:
          - button "Design and build workspace" [ref=f24e23] [cursor=pointer]
          - button "Open global search" [ref=f24e26] [cursor=pointer]
          - button "Page guide" [ref=f24e30] [cursor=pointer]
        - region "Local demonstration identity" [ref=f24e36]:
          - button "Change identity" [ref=f24e38] [cursor=pointer]:
            - generic [aria-hidden] [ref=f24e39]: SS
      - main [ref=f24e40]:
        - generic [ref=f24e41]:
          - heading "Service planner" [level=1] [ref=f24e42]
          - region "Planner controls" [ref=f24e43]:
            - generic [ref=f24e44]:
              - button "Previous period" [ref=f24e45] [cursor=pointer]: ←
              - generic [ref=f24e46]:
                - generic [ref=f24e47]: Starting date
                - textbox "Starting date" [ref=f24e48]: 2031-11-06
              - button "Next period" [ref=f24e49] [cursor=pointer]: →
            - generic "Planner view" [ref=f24e50]:
              - button "Day" [pressed] [ref=f24e51] [cursor=pointer]
              - button "Week" [ref=f24e52] [cursor=pointer]
            - generic [ref=f24e53]:
              - button "Refresh planner" [ref=f24e54] [cursor=pointer]
              - button "Filters" [ref=f24e55] [cursor=pointer]
          - alert [active] [ref=f24e56]:
            - strong [ref=f24e57]: This identity does not have the required shared-data permission.
            - generic [ref=f24e58]: "Support reference: 0cc87566-b594-4b52-aeb7-7e0729bbf851"
          - button "Retry loading" [ref=f24e59] [cursor=pointer]
          - paragraph [ref=f24e60]: Site choices could not be refreshed.
          - paragraph [ref=f24e61]: Availability is unknown. A failed read does not mean resources are free. Refresh before proposing a move.
          - generic [ref=f24e62]:
            - heading "Unassigned demand" [level=2] [ref=f24e63]
            - paragraph [ref=f24e64]: Authorised work without a non-cancelled appointment. Work whose only visits were cancelled can appear again. Draft work is excluded. Demand is independent of calendar dates, resource and status filters; the selected site and your permitted scope apply.
            - status [ref=f24e65]: Unassigned demand is unknown. A failed read does not mean every authorised work order is scheduled.
            - button "Retry loading demand" [ref=f24e66] [cursor=pointer]
  - alert [ref=f24e67]
```

# Test source

```ts
  526 |             status: 200,
  527 |             contentType: "application/json",
  528 |             body: JSON.stringify({ ...original, items: [], total: 0, next_cursor: null }),
  529 |           }),
  530 |         );
  531 |         await page.reload({ waitUntil: "domcontentloaded" });
  532 |         await expect(screenLoading).toHaveCount(0);
  533 |         const emptyResult = page.getByText(/No (permitted|current assigned|Finance handoffs)/).first();
  534 |         await expect(emptyResult).toBeVisible();
  535 |         // Capture the empty result itself, not only a tall filter panel above it.
  536 |         await emptyResult.scrollIntoViewIfNeeded();
  537 |         await expect(emptyResult).toBeInViewport({ ratio: 1 });
  538 |         await capture(page, info, `${s.id}-empty`);
  539 |         await page.unroute(match);
  540 |       } else if (s.id === "SC-13") {
  541 |         await page.route(match, route => route.fulfill({ status: 200, contentType: "application/json",
  542 |           body: JSON.stringify({ ...original, current: null, last_good: null, history: [], account_balance: null, unapplied_cash: null, balance_status: "Unavailable" }),
  543 |         }));
  544 |         await page.reload({ waitUntil: "domcontentloaded" });
  545 |         await expect(page.getByText("No extraction recorded. Account total unavailable.", { exact: true })).toBeVisible();
  546 |         await expect(page.getByText("Supplied account balance", { exact: true }).locator("..").locator("strong")).toHaveText("Unavailable");
  547 |         await expect(page.locator("tbody tr")).toHaveCount(0);
  548 |         await capture(page, info, `${s.id}-no-extraction`);
  549 |         await page.unroute(match);
  550 |       } else {
  551 |         let unavailableRequested = false;
  552 |         let releaseUnavailable: () => void = () => {};
  553 |         const unavailableReady = new Promise<void>((resolve) => {
  554 |           releaseUnavailable = resolve;
  555 |         });
  556 |         await page.route(match, async (route) => {
  557 |           unavailableRequested = true;
  558 |           await unavailableReady;
  559 |           await route.fulfill({
  560 |             status: 404,
  561 |             contentType: "application/json",
  562 |             body: JSON.stringify({
  563 |               code: "RecordUnavailable",
  564 |               message: "The requested record is unavailable to this identity.",
  565 |               retryable: false,
  566 |             }),
  567 |           });
  568 |         });
  569 |         // The unavailable-record assertion starts after the actual selected
  570 |         // read, not while the independent identity prerequisite is loading.
  571 |         try {
  572 |           await page.reload({ waitUntil: "domcontentloaded" });
  573 |           await expect(page.getByRole("region", { name: "Local demonstration identity", exact: true }))
  574 |             .toHaveAttribute("aria-busy", "false");
  575 |           await expect.poll(() => unavailableRequested, {
  576 |             timeout: 15000, message: `${s.id}: selected record read requested`,
  577 |           }).toBe(true);
  578 |           const unavailableResponse = page.waitForResponse((response) =>
  579 |             new URL(response.url()).pathname === `/api/v1/${s.api}` &&
  580 |             response.request().method() === "GET" && response.status() === 404,
  581 |             { timeout: 15000 });
  582 |           releaseUnavailable();
  583 |           await unavailableResponse;
  584 |         } finally {
  585 |           releaseUnavailable();
  586 |         }
  587 |         await expect(
  588 |           page
  589 |             .getByRole("alert")
  590 |             .filter({ hasText: "requested record is unavailable" }),
  591 |         ).toBeVisible();
  592 |         await capture(page, info, `${s.id}-unavailable-record`);
  593 |         await page.unroute(match);
  594 |       }
  595 |       // Assert the screen's real server-derived Systems denial. Observing the
  596 |       // selected read avoids introducing a second auxiliary request beside the
  597 |       // UI request whose response and rendered error form this contract.
  598 |       // Only requests started after the accepted identity change may satisfy it.
  599 |       let identityAccepted = false;
  600 |       const currentReads = new WeakSet<Request>();
  601 |       const acceptedIdentity = (response: Response) => {
  602 |         if (new URL(response.url()).pathname === "/api/v1/local-session" &&
  603 |             response.request().method() === "POST" && response.status() === 200)
  604 |           identityAccepted = true;
  605 |       };
  606 |       const currentRead = (request: Request) => {
  607 |         if (identityAccepted && request.method() === "GET" &&
  608 |             new URL(request.url()).pathname === `/api/v1/${s.api}`)
  609 |           currentReads.add(request);
  610 |       };
  611 |       page.on("response", acceptedIdentity).on("request", currentRead);
  612 |       let denied: Response;
  613 |       try {
  614 |         [denied] = await Promise.all([
  615 |           page.waitForResponse(response => currentReads.has(response.request())),
  616 |           identity(page, "systems"),
  617 |         ]);
  618 |       } finally {
  619 |         page.off("response", acceptedIdentity).off("request", currentRead);
  620 |       }
  621 |       const deniedQuery = new URL(denied.url()).searchParams;
  622 |       for (const [key, value] of new URLSearchParams(query)) {
  623 |         const actual = deniedQuery.get(key);
  624 |         expect(actual, `${s.id}: ${key}`).not.toBeNull();
  625 |         if (key === "from" || key === "to")
> 626 |           expect(Date.parse(actual!), `${s.id}: ${key}`).toBe(Date.parse(value));
      |                                                          ^ Error: SC-07: from
  627 |         else expect(actual, `${s.id}: ${key}`).toBe(value);
  628 |       }
  629 |       expect([403, 404], s.id).toContain(denied.status());
  630 |       expect(denied.headers()["cache-control"]).toBe("private, no-store");
  631 |       const deniedBody = await denied.json();
  632 |       await expect(
  633 |         page
  634 |           .locator('.business-error[role="alert"]')
  635 |           .filter({ hasText: deniedBody.message })
  636 |           .first(),
  637 |       ).toBeVisible();
  638 |       await expect(screenLoading).toHaveCount(0);
  639 |       await expect(
  640 |         page.getByRole("heading", {
  641 |           name: "SYN Greenhouse Demonstration",
  642 |           exact: true,
  643 |         }),
  644 |       ).toHaveCount(0);
  645 |       expect(JSON.stringify(deniedBody)).not.toContain(source.report_id);
  646 |       await expect(
  647 |         page.getByRole("heading", { name: "Current page summary", exact: true }),
  648 |       ).toHaveCount(0);
  649 |       await capture(page, info, `${s.id}-denied`);
  650 |       proof.push({
  651 |         screen: s.id,
  652 |         route: s.url,
  653 |         read: s.api,
  654 |         profile: s.profile,
  655 |         populated_label: populatedLabel,
  656 |         populated_source: "Actual browser GET 200; visible record asserted",
  657 |         query,
  658 |         denied_status: denied.status(),
  659 |         denial_source: "Browser GET after accepted identity POST",
  660 |         states: [
  661 |           "populated",
  662 |           "loading",
  663 |           "failed",
  664 |           "recovered",
  665 |           s.list ? "empty permitted result" : s.id === "SC-13" ? "no extraction; total unavailable" : "unavailable detail record",
  666 |           "actual Systems denial",
  667 |         ],
  668 |         empty_detail_basis: s.list || s.id === "SC-13"
  669 |           ? null
  670 |           : "Detail APIs return unavailable for no permitted record; an empty success object is not fabricated.",
  671 |         limits:
  672 |           "Injected read failures prove UI states. Existing domain suites prove actual server failure/rollback. No screen-reader or whole-product conformance claim.",
  673 |       });
  674 |     });
  675 |   }
  676 |   await writeFile(
  677 |     info.outputPath("P11-screen-state-matrix.json"),
  678 |     JSON.stringify(proof, null, 2),
  679 |   );
  680 | });
  681 | 
```